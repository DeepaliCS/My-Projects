IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_process_consignment_expired]')  AND type = N'P')
     DROP PROCEDURE [dbo].[st_process_consignment_expired]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


	-- =============================================
	-- Author:		Deepali
	-- Create date: 07/06/2019
	-- Description:	Prepare data before email is sent to user about wine consigment expiry
	-- =============================================


CREATE PROCEDURE [dbo].st_process_consignment_expired

	 
	@user_id int,
	@settings as varchar(500) ='',	
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT
      
as    
begin

--Event Made as:
--Event Key: CONSIGNMENT_EXPIRY_EMAIL
--Event Type: CONSIGNMENT_EXPIRY

--	   Calls
--	   : [fnGetListOfConsignmentExpiry]
--	   : [dm_wine_consignment_expiry]


/*


	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WEC~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WEC'
	declare @user_id int = 213
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''
	
	exec [st_process_consignment_expired] @user_id, @settings, @sql_logging, null --, @organisation_id

	EXEC st_event
	  @user_id
	, @settings
	, @sql_logging
	, @output_message OUTPUT
		, 'CONSIGNMENT_EXPIRY' 
		, @user_id
		, 'N'
		, null
		, null
		, null
		, null
		, null
		, '@organisation_id'
		, 52592
		,'wine_consignment_expiry'
		,'dm_wine_consignment_expiry' 

		--exec [dm_wine_consignment_expiry] @settings, @user_id , @sql_logging, null, @organisation_id

*/
	declare @brand varchar(10) = dbo.fnGetPiece(@settings,3,'~','WO')

	-- Loops the to run each individual owner id from #distinct_order_by_owner
	DECLARE @organisation_id int
	DECLARE ITEM_CURSOR CURSOR
		
	-- get the distinct organisation id (seller id) - given the expiry conditions (last 7 days)
	FOR	SELECT distinct o.organisation_id from wine_entry we
		join wine_consignment wc on we.wine_entry_id = wc.wine_entry_id
		join cellar c on we.cellar_id = c.cellar_id
		join organisation o on c.owner_id = o.organisation_id
	where consignment_status like 'A' and isnull(wc.disabled,0) = 0
		and (wc.[expiry_date] = cast(getdate()+7 as date) or wc.[expiry_date] = cast(getdate()+1 as date))
	and o.brand_ref = @brand

	OPEN ITEM_CURSOR
 
		FETCH NEXT FROM ITEM_CURSOR INTO @organisation_id -- We fetch the first result
 
		WHILE @@FETCH_STATUS = 0
		BEGIN	/* Start Iteration is done here */
			
			-- Show ids for all that the email will be sent to
			-- print @organisation_id

			EXEC st_event
				@user_id
				, @settings
				, @sql_logging
				, @output_message OUTPUT
				, 'CONSIGNMENT_EXPIRY' 
				, @user_id
				, 'N'
				, null
				, null
				, null
				, null
				, null
				, 'organisation_id'
				, @organisation_id
				,'wine_consignment_expiry' 
				,'dm_wine_consignment_expiry' 

			FETCH NEXT FROM ITEM_CURSOR INTO @organisation_id
		END

	CLOSE ITEM_CURSOR
	DEALLOCATE ITEM_CURSOR

end





IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_email_bottles_below_fifty]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_email_bottles_below_fifty]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

	-- =============================================
	-- Author:		Deepali
	-- Create date: 17/06/2019
	-- Description:	Send email when number of bottles is less than 50
	-- =============================================


CREATE PROCEDURE [dbo].[dm_email_bottles_below_fifty]

	@settings as varchar(500) ='',
	@user_id int,						
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT,
	@user_id2 int
	--@organisation_id int
	

	/*

	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @user_id int = 38
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''
	declare @organisation_id int = 51222
	declare @user_id2 int = @user_id

	--exec [dm_email_bottles_below_fifty] @settings, @user_id , @sql_logging, null, @user_id2
	
		EXEC st_event
		  @user_id
		, @settings
		, @sql_logging
		, @output_message OUTPUT
			, 'BOTTLES_OVER_FIFTY'
			, @user_id
			, 'N'
			, null
			, null
			, null
			, null
			, null
			, 'user_id2'
			, @user_id
			,'email_bottles_below_fifty'
			,'dm_email_bottles_below_fifty'

	*/

as
begin

	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='email_bottles_below_fifty'
	declare @object_name as varchar(50) = 'email_bottles_below_fifty'
	declare @audit_exception varchar(500) = ''
	--declare @trading_currency_symbol varchar(10) = dbo.fnGetPiece(@settings,13,'~',char(163))
	
	
	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
		+ ' User_id: ' + ISNULL(cast(@user_id as varchar(10)),'')

	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

	declare @forename varchar(50)= ''
	declare @message varchar (max) = ''
	declare @email varchar (50) = ''
	--declare @user_email_Id int = dbo.fnGetOrganisationUser(@organisation_id)

	-- main select
	select 
		'deepali.kerai@wineowners.com' as email_to -- email -- Winevault@westerncarriers.com
		--, isnull(forename, '') as 'forename'
		--, isnull(surname, '') as 'surname'
		, isnull(alias, '') as alias
		, isnull(try_cast((dbo.fnCountUserBottles(@user_id2, null,null)) as varchar(10)), 0) as 'no_of_bottles'

	from [user] u
	where u.[user_id] = @user_id2


end


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_market_vs_cost_67]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_market_vs_cost_67]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[dm_report_market_vs_cost_67]

	@user_id Int,
	@settings varchar(500),
	@sql_logging varchar(1) = 'X',
	@output_message varchar(1000) = null OUTPUT,
	
    @filter varchar(100) = '',
	@sort_by varchar(50) = '',
	@sort_direction varchar(10) = '',
	@records int = 1000

as	

begin
	-- =============================================
	-- Author:		Deepali
	-- Create date: 2019-05-03
	-- Description: Report to show which wine prices have differences in market and cost prices
	-- =============================================
	
/*

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_market_vs_cost_67 @user_id,@settings,'',@out_msg, ''
	print @out_msg
	
declare @id int
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_market_vs_cost_67', '67', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Market vs Cost price" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
-- select * from lookup where category = 'StoredProcedure'
-- report documentation

*/

-- Doc source:
--https://docs.google.com/document/d/1EWcs3afDKB3lOJue8mLkibNA_uTg3vAC2qItg7DCSRw/edit?ts=5ccc0847#heading=h.x5isu4hz9rp8

	-- return to
	declare @return_to varchar(100) = dbo.fnBase64Code('/report.aspx?rp=dm_report_market_vs_cost_67&reset=Y')

	declare @less_than decimal(10,2)=0
	declare @more_than decimal(10,2)=0

	-- Filters for uplift percentage
	if @filter like 'less-than-10'
			select @more_than = 0, @less_than = 9
	else if @filter like '10-19'
			select @more_than = 10, @less_than = 19
	else if @filter like '20-29'
		select @more_than = 20, @less_than = 29
	else if @filter like '30-39'
		select @more_than = 30, @less_than = 39
	else if @filter like '40-49'
		select @more_than = 40, @less_than = 49
	else if @filter like 'more-than-50'
		select @more_than = 50, @less_than = 800
	
	-- set based on price calc valuations in the doc
	if (isnull(@filter, '') = '')
		select @more_than = 15, @less_than = 800
	
	-- main select
	select top (@records)
	  '<a href="wine-udf.aspx?wei='+isnull(cast(we.[wine_entry_id] as varchar(10)),'')+'&m=U&rt=' + @return_to + '">'+isnull(w.[name],'')+'</a>' as 'Wine'
	, wvp.[vintage] 'Vintage'
	, we.[bottle_size_ref] + 'cl' as 'Size'

	, '<a href="report.aspx?rp=dm_report_market_vs_cost_67&filter=' + twlr.[country] +'&reset=Y' + @return_to +'">'+twlr.[country] as 'Country'
	--, twlr.[region] as 'Region'
	, '<a href="report.aspx?rp=dm_report_market_vs_cost_67&filter=' + twlr.[region] +'&reset=Y' + @return_to +'">'+twlr.[region]
	+'</a><br><small><a href="report.aspx?rp=dm_report_market_vs_cost_67&filter=' + twlr.[sub_region] +'&reset=Y' + @return_to + '">'+twlr.[sub_region]+'</a></small>' as 'Region'
	--, twlr.[sub_region] as 'Sub-Region'
	, try_cast(udf.[value_12] as decimal(10,3)) as 'Qty'
	, udf.[value_7] as 'SKU'--+ CHAR(13) + CHAR(10) +  ' UPC: ' + udf.value_9 as 'SKU & UPC Details'
	, format(try_cast(udf.[value_2] as decimal(10,3)), 'C', 'en-GB') as 'Retail Price'
	, format(try_cast(udf.[value_11] as decimal), 'C', 'en-GB') as 'Cost Price'
	, format(try_cast((try_cast(udf.[value_2] as decimal(10,3))/1.2 - try_cast(udf.[value_11] as decimal(10, 4))) / (try_cast(udf.[value_2] as int)/1.2) as decimal (10,3)), 'P') as 'Cur. Margin' 	
	, format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int), 'C', 'en-GB') as 'Market Value'
	, case when (((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int))
		 - (try_cast(udf.[value_11] as decimal(10, 4))) > 0)
	 or (((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
		 - (try_cast(udf.[value_11] as decimal(10, 4))) <> 0)))
	  then try_cast(format(try_cast(((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
		- (try_cast(udf.[value_11] as decimal(10, 4))))
		/ (try_cast(udf.[value_11] as decimal(10, 4))) as decimal (10,3)), 'P') as varchar(10)) else ''  end as '% Uplift'
	
	 --make sure the threshold (40) is presented as varchar if you're going to format to pounds which automatically casts to varchar
	 --, case when ((
	,  case when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 16) then '�40'
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 20) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 16 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 2.5 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 25) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 20 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 2.3 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 35) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 25 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 2.2 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 45) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 35 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 2.1 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 100) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 45 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 2.0 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 200) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 100 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.9 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 300) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 200 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.8 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 400) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 300 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.7 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 500) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 400 
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.6 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 800) 
				and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 500
					then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.5 as decimal), 'C', 'en-GB')
			when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) >= 801 
				then format(try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)* 1.4 as decimal), 'C', 'en-GB')
			end as 'Suggested'
		--	)  < try_cast(udf.value_2 as decimal)) then format(try_cast('0' as decimal), 'C', 'en-GB') end as 'Suggested'


	from wine_entry we with (nolock)
	join wine w with (nolock) on we.[wine_id] = w.[wine_id]

	join wine_vintage_price wvp with (nolock) on we.[wine_id] = wvp.[wine_id]
	and we.[vintage] = wvp.[vintage]
	and isnull(wvp.[disabled],0) = 0
	and wvp.[currency_ref] = 'GBP'
	and wvp.[region_ref] = 'Europe'
	
	join user_defined_field udf with (nolock) on we.[wine_entry_id] = udf.[record_id]
	and udf.[brand_ref] = '67'
	and udf.[table_name] = 'wine-entry'
	
	-- This table doesn't include all info from 67
	join temp_wine_list_result twlr with (nolock) on we.wine_entry_id = twlr.wine_entry_id

	where
	-- prevent any values occuring an error that is not divisible by 0
		--isnull(try_cast(udf.[value_2] as int),0) <> 0

		isnull(try_cast(udf.[value_2] as decimal(10, 4)),0) <> 0
		and isnull(try_cast(udf.[value_11] as decimal(10, 4)),0) <> 0

		-- (don't show any wines that are not for sale)
		and isnull(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null),0) > 0
		and isnull(we.[disabled], 0) = 0

		-- Active and disable filters
		and we.[status]= 'Active'
		--Positive quantity
		and isnull(try_cast(udf.[value_12] as decimal(10,3)),0) > 0.025

		-- Setting filter thresholds
		and
			(try_cast((((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
			- (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_11] as decimal(10, 4)))) as decimal (10,2))*100 < @less_than
			and
			try_cast((((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
			- (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_11] as decimal(10, 4)))) as decimal (10,2))*100 > @more_than)

		--jf 2019-05-10 - exclude those where current retail price is higher than suggested selling price
		--				commented out for now as I am not sure we are getting the right ammount of results, ones tested, this should be applied
		
		and case when try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 16 then 40
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 20) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 16 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 2.5 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 25) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 20 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 2.3 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 35) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 25 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 2.2 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 45) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 35 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 2.1 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 100) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 45 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 2.0 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 200) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 100 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.9 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 300) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 200 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.8 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 400) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 300 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.7 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 500) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 400 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.6 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal) <= 800) 
			and (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) > 500 
				then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.5 as decimal)
		when (try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as decimal)) >= 801 
			then try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) * 1.4 as decimal)
		end > try_cast(udf.value_2 as decimal)

	-- for order clause
	group by
		 we.[wine_entry_id]
		, we.[bottle_size_ref]
		, we.[bonded_type]
		, w.[wine_id]
		, w.[name]
		, wvp.[vintage]
		, udf.[value_12]
		, udf.[value_7]
		, udf.[value_9]
		, udf.[value_2]
		, udf.[value_11]
		, dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)
		, twlr.[country]
		, twlr.[region]
		, twlr.[sub_region]

	order by
		case @sort_direction when 'asc' then
			case @sort_by
				when 'Wine' then w.[name]
				when 'Vintage' then wvp.[vintage]
				when 'Country' then twlr.[country]
				when 'Region' then twlr.[region]
				when 'Sub-Region' then twlr.[sub_region]
				when 'Size' then cast(100000 + cast(we.[bottle_size_ref] as decimal(18,4))as varchar(50))
				when 'Qty' then convert(varchar(20), udf.[value_12])
				when 'Retail Price' then udf.[value_2]
				when 'Cost Price' then udf.[value_11]
				when 'Market Value' then dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)
				when 'Cur. Margin' then try_cast((((try_cast(udf.[value_2] as int))/1.2 - (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_2] as int))/1.2) as decimal (10,2))
				when '% Uplift' then try_cast((((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
				- (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_11] as decimal(10, 4))) *100) as decimal (10,2))
			end
	end asc,
	
		case @sort_direction when 'desc' then
			case @sort_by
				when 'Wine' then w.[name]
				when 'Vintage' then wvp.[vintage]
				when 'Country' then twlr.[country]
				when 'Region' then twlr.[region]
				when 'Sub-Region' then twlr.[sub_region]
				when 'Size' then cast(100000 + cast(we.[bottle_size_ref] as decimal(18,4))as varchar(50))
				when 'Qty' then convert(varchar(20), udf.[value_12])
				when 'Retail Price' then udf.[value_2]
				when 'Cost Price' then udf.[value_11]
				when 'Market Value' then dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null)
				when 'Cur. Margin' then try_cast((((try_cast(udf.[value_2] as int))/1.2 - (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_2] as int))/1.2) as decimal (10,2))
				when '% Uplift' then try_cast((((try_cast(dbo.fnGetPriceAdjusted(wvp.current_price, null, 75, 1, we.bonded_type, we.bottle_size_ref, 1, null) as int)) 
				- (try_cast(udf.[value_11] as decimal(10, 4)))) / (try_cast(udf.[value_11] as decimal(10, 4))) *100) as decimal (10,2))
			end
		end	desc
end

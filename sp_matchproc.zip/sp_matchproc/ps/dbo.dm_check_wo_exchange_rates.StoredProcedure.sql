IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_check_wo_exchange_rates]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_check_wo_exchange_rates]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[dm_check_wo_exchange_rates]

	@settings as varchar(500) ='',	
	@user_id int,						
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT,
	@unused_parameter int = 1

	/*

	-- Deepali 2019-05-22
	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @user_id int = 34470
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''

	EXEC st_event 
	  @user_id
	, @settings
	, @sql_logging
	, @output_message OUTPUT
		, 'WO_EXCHANGE_RATES'
		, @user_id
		, 'N'
		, null
		, null
		, null
		, null
		, null
		, 'unused_parameter'
		, 1
		,'exchange_rates_info'
		,'dm_check_wo_exchange_rates'

	*/


as	
Begin


	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='check_wo_exchange_rates'
	declare @object_name as varchar(50) = 'check_wo_exchange_rates'
	declare @audit_exception varchar(500) = ''

	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
		+ ' User_id: ' + ISNULL(cast(@user_id as varchar(10)),'')

	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

		declare @organisation_id int = 0
		declare @username varchar(100) = ''
		declare @forename varchar(50)= ''
		declare @message varchar (max) = ''
		declare @email varchar (50) = ''
		declare @output_msg varchar (max) = ''
		declare @user_brand varchar(20)
		declare @user_access varchar(10)

		declare @exchange_rates_info varchar(max) = ''

		Set @email = 'deepali.kerai@wineowners.com'
		set @forename = 'Deepali'

		-- Getting the audit lines from [description] from audit_hdr after insert to exchange rates
		select @message = @message + char(30) + char(10) + [description]
		from audit_hdr
		where 
			action like 'exchange_rate_checks'
			and audit_date_time >= getdate()-24
			and [description] is not null

		select @message as 'message', @email as 'emailTo', @forename as 'forename'

		
end





IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_trigger_bottle_count_email_below_fifty]')  AND type = N'P')
     DROP PROCEDURE [dbo].[st_trigger_bottle_count_email_below_fifty]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


	-- =============================================
	-- Author:		Deepali
	-- Create date: 17/06/2019
	-- Description:	Send email when the bottle count is below 50
	-- =============================================


CREATE PROCEDURE [dbo].[st_trigger_bottle_count_email_below_fifty]

	 
	@user_id int,
	@settings as varchar(500) ='',	
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT
	--@no_of_bottles as int

      
as    
begin

/*	

declare @user_id as int = 13
declare @settings varchar(500) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
declare @sql_logging varchar(1) ='X'
declare @output_message as varchar(500) =''

	exec st_trigger_bottle_count_email_below_fifty @user_id,@settings,@sql_logging,@output_message
	print @output_message

*/
	
	DECLARE @owner_id int
	DECLARE ITEM_CURSOR CURSOR

	FOR select organisation_id from [user] where [user_id] = @user_id


		OPEN ITEM_CURSOR -- This charges the results to memory
 
			FETCH NEXT FROM ITEM_CURSOR INTO @owner_id -- We fetch the first result
 
			WHILE @@FETCH_STATUS = 0
			BEGIN	/* Start Iteration is done here */

			PRINT @owner_Id

				EXEC st_event
				  @user_id
				, @settings
				, @sql_logging
				, @output_message OUTPUT
					, 'OPEN_BIDS_CELLAR' -- change this
					, @user_id
					, 'N'
					, null
					, null
					, null
					, null
					, null
					, '@organisation_id'
					, @owner_id
					,'open_bids_cellar_data' -- change this
					,'dm_email_new_bids_to_cellar' -- change this

				FETCH NEXT FROM ITEM_CURSOR INTO @owner_id
			END

	CLOSE ITEM_CURSOR
	DEALLOCATE ITEM_CURSOR
	---------------------

end

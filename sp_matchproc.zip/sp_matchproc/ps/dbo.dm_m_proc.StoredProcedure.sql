IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_m_proc]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_m_proc]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[dm_m_proc] 

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  
	  @xproc varchar(100) = null,
	  @xdata varchar(8000) = null,		-- wv 2019-06-16 increased to 8k for note edits
	  @options varchar(1000) = '',
	  @redirect_page varchar(100) = '' OUTPUT

as    

	-- =============================================
	-- Author:      Wolter
	-- Create date: 2016-02-10
	-- Description: Execute special processing
	-- =============================================
	
	/*
	
		DECLARE @user_id INT = 15018 
		DECLARE @settings VARCHAR(500) = '192.145.12.233~session1234~TWC~Europe~GBP~en'
		DECLARE @sql_logging VARCHAR(1) = 'Y'
		DECLARE @output_message VARCHAR(1000)
		DECLARE @output VARCHAR(1000)
		declare @xdata varchar(500) = '61062~Storage Boxes - Per Unit: $ 10.00~2~~inbound~369~~'
		exec dm_m_proc @user_id, @settings, @sql_logging, @output_message output, 'charge-insert'
			, @xdata, '', @OUTPUT OUTPUT
		print @output_message

		--admin-reset-trade
		DECLARE @user_id INT = 172
		DECLARE @settings VARCHAR(500) = '192.145.12.233~session1234~PCL~Europe~GBP~en'
		DECLARE @sql_logging VARCHAR(1) = 'Y'
		DECLARE @output_message VARCHAR(1000)
		DECLARE @output VARCHAR(1000)
		exec dm_m_proc @user_id, @settings, @sql_logging, @output_message output, 'admin-reset-trade', 'xxxx', '', @OUTPUT OUTPUT
		print isnull(@output,'') + isnull(@output_message,'')
		exec dm_m_proc @user_id, @settings, @sql_logging, @output_message output, 'admin-reset-trade', 123456, '', @OUTPUT OUTPUT
		print isnull(@output,'') + isnull(@output_message,'')
		
	
	*/
		

begin try
	
	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) = 'Process TYPE: '+ isnull(@xproc,'')
	declare @object_name as varchar(50) = 'dm_m_proc'
	declare @audit_exception varchar(500) = ''
	declare @ip_address varchar(50) = dbo.fnGetPiece(@settings, 1, '~', '0.0.0.0')
	declare @authorised varchar(500)
	declare @alert_message varchar(2000) = ''

	-- string of input fields
	declare @input_fields as varchar(4000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: ' + isnull(@settings,'')
        +'  xproc: ' + isnull(@xproc,'')
        +'  xdata-length: ' + cast(len(isnull(@xdata,'')) as varchar(10))
        +'  xdata: ' + left(isnull(@xdata,''),1000)
		+'  Options: ' + isnull(@options,'')

	-- get brand
	declare @brand as varchar(10) = dbo.fnGetPiece(@settings, 3, '~', 'WO')
	declare @region varchar(50) = dbo.fnGetPiece(@settings,4,'~','Europe')
	declare @currency varchar(50) = dbo.fnGetPiece(@settings,5,'~','GBP')

	-- standard vars
	declare @output_msg varchar(1000) = ''
	declare @output_type varchar(10) = ''
	declare @alert_template varchar(100)
	declare @count int = 0
	--
	declare @basket_id int
	declare @basket_status varchar(10)
	declare @basket_org_id int
	declare @basket_type varchar(20)
	declare @basket_count int
	declare @basket_item_id int
	declare @cont_id varchar(10) = ''
	declare @cont_org_id int
	declare @cont_status varchar(50) = ''
	declare @con_id varchar(50) = ''
	declare @con_status varchar(50) = ''
	declare @con_org_brand varchar(50) = ''
	declare @con_text varchar(50) =''
	declare @con_description varchar(100) =''
	declare @con_new_status varchar(10) =''
	declare @status varchar(10)
	declare @lookup_brand varchar(50)
	declare @wine_entry_id int
	declare @wine_id int
	declare @producer_name varchar(100)
	declare @select_name varchar(200)
	declare @new_name varchar(200)
	declare @wine_type varchar(100)
	declare @wine_sub_type varchar(100)
	declare @options_input varchar(100)
	declare @quantity_cases int
	declare @quantity_bottles int
	declare @audit_action varchar(50) = 'info'
	declare @cellar_ref varchar(100)
	declare @record_brand varchar(20)
	declare @cur_suspended_status varchar(20)
	declare @barcode varchar(20)
	declare @loc_key varchar(100)
	declare @tmp_msg varchar(1000) = ''
	declare @wine_stock_take_header_id int

	-- user data
    declare @access varchar(10)
    declare @alias varchar(50)
    declare @user_org_id int
    declare @user_brand varchar(20)
    declare @admin_user varchar(20)
    select top 1 @access= u.user_access,@user_org_id = u.organisation_id
		, @user_brand = o.brand_ref,@alias= u.alias, @admin_user=admin_user
		from [user] u with (nolock)
		left join organisation o with (nolock) on o.organisation_id = u.organisation_id
    where [user_id] = @user_id
	declare @submitted_date datetime = getdate()
	declare @completed_date datetime = getdate()

	-- add user details
	select @input_fields = @input_fields 
        +'  user org id: ' + isnull(cast(@user_org_id as varchar(10)),'')
        +'  access: ' + isnull(@access,'')
        +'  user brand: ' + isnull(@user_brand,'')


	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @Input_fields


	-- process for subscription invoice
	-- also check if datais numeric (passed in as org id
	if @xproc='sub-inv' and ISNUMERIC(@xdata) = 1
		begin
		
			-- get the organsation id
			declare @org_sub_id int = @xdata
			-- and run		
			-- pass in generate PDF so it will regenerate if it already exists
			exec st_create_organisation_invoice @user_id,@settings,'N', @output_message OUTPUT
			,@organisation_id = @org_sub_id
			,@invoice_type = 'subscription'
			,@options = 'GENERATE-PDF'
			
			-- we could check if it worked ?
			if isnull(@output_message,'') = '' 
				select @alert_message = 'Generated invoice for organisation id: ' + isnull(cast(@org_sub_id as varchar(10)),'')
			else
				select @alert_message = 'Failed to generate invoice for id: ' + isnull(cast(@org_sub_id as varchar(10)),'')	+ ' ' + @output_message
			-- and set
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message	
					
		end
		
	-- if money in process for user paying for orders
	else if @xproc='money_in' and ISNUMERIC(@xdata) = 1
		begin
		
			-- get the order id
			declare @order_id varchar(10) = @xdata
			-- check if exit
			declare @buyer_org_id int
			select @buyer_org_id = buyer_id
				from wine_order with (nolock) 
			where order_type='O' and cast(wine_order_id as varchar(10))=@order_id
			
			-- if exit
			if isnull(@buyer_org_id,0) > 0
				begin
					-- create money in record
					declare @out_msg varchar(500) = ''
					declare @pwd as varchar(200) = (select password from [user] with (nolock) where user_id=@user_id)
					-- get total order amount for the seller
					declare @total_order decimal(18,2) = dbo.fnGetOrderTotal(@user_id,@settings,@order_id,'buyer','')
					--transfer id
					declare @transfer_id int
					declare @reference varchar(50) = 'Trd: ' + @order_id
					
					-- check if transfer doesnt exit already
					if (select COUNT(1) from acc_transfer 
							where owner_id = @buyer_org_id 
								and CAST(@total_order as decimal(18,2)) = CAST(amount as decimal(18,2))
								and transfer_direction ='I') > 0
						select @alert_message = 'A tranfer already exist for this amount and organisation.'
					else
						begin

							-- and create
							exec st_acc_transfer_admin @user_id, @settings,'X',@out_msg OUTPUT, 
								@password = @pwd,
								@amount_request = @total_order,
								@organisation_id = @buyer_org_id,
								@acc_transfer_id = @transfer_id OUTPUT,
						
								@reference = @reference,
								@transfer_status = 'R',
								@transfer_direction = 'I',
						
								@online_reference = '',
								@notes = ''
									
							-- we could check if it worked ?
							if isnull(@out_msg,'') <> '' or isnull(@transfer_id,0) = 0
								select @alert_message = 'Failed to generate money transfer'
							else
								begin
									select @alert_message = 'Created money transfer: ' + CAST(@transfer_id as varchar(10))
									-- and set redirect to page  (only return the query string, so page, /transfer-request.aspx is what was called
									select @redirect_page = '?m=U&amp;trid=' + CAST(@transfer_id as varchar(10)) + '&amp;oi=' + CAST(@buyer_org_id as varchar(10)) + '&amp;rt=L3RyYW5zZmVyLXJlcXVlc3QtbGlzdC5hc3B4'
								end
						end
						
					-- and set
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message	
				end
		end
		
		
	-- process for restoring content
	-- double check for admin / merchant access
	-- also check if datais numeric (passed in as audit content id)
	else if @xproc='cres' and ISNUMERIC(@xdata) = 1 and @access in ('A','M')
		begin	
			
			-- so we are restore:
			--   content_type_ref
			--   header
			--	 header_style
			--   content_text
			--   Tool - tip
			--   notes   (but add 'restored on .... ' to this
			--   categories
			--   tags
			declare @content_id int
			declare @content_key varchar(100)
			declare @content_type_ref varchar(50)
			declare @header varchar(max)
			declare @notes varchar(200)
			declare @tooltip varchar(max)
			declare @content_text varchar(max)
			declare @categories varchar(2000)
			declare @tags varchar(2000)
			declare @published varchar(10)
			declare @cache varchar(10)
			declare @user_access_ref varchar(20)
			declare @brand_ref varchar(20)
			-- and retrieve
			select @content_key = content_key, @content_id = content_id, @content_type_ref = content_type_ref, @content_text = content_text
				,@header = header, @notes = notes, @tooltip = tooltip, @categories = categories, @tags = tags
				,@published = published, @cache = cache, @user_access_ref = user_access_ref, @brand_ref = brand_ref
				from audit_content ac with (nolock)
			where ac.audit_content_id = @xdata
			
			-- if we have a content id
			if isnull(@content_id,0) > 0
				begin
					-- if restoring from update just do an update
					if isnull((select count(1) from content with (nolock) where content_id = @content_id),0) > 0
						begin 
							-- update
							select @notes = left(@notes,150) + ' RESTORED: ' + CAST(GETDATE() as varchar(20)) + ' from update, by ' + left(isnull(@alias,''),20)
							-- call standard update (which will create another audit entry)
							EXEC st_update_content @user_id, @settings, 'X', @output_msg OUTPUT,
								@output_type OUTPUT,
								@content_id,
								0,			        --@stamp int,					-- record update stamp  - optional passed in for updates
								'update~RESTORE'	--@options varchar(50),         -- generic purposes
								
								,@content_type_ref = @content_type_ref
								,@content_text = @content_text
								,@header = @header
								,@notes = @notes
								,@tooltip = @tooltip
								,@categories = @categories
								,@tags = @tags
						end
					else
						begin 
							-- do an insert
							select @notes = left(@notes,150) + ' RESTORED: ' + CAST(GETDATE() as varchar(20)) + ' from delete, by ' + left(isnull(@alias,''),20)
							-- call standard update (which will create another audit entry)
							EXEC st_update_content @user_id, @settings, 'X', @output_msg OUTPUT,
								@output_type OUTPUT,
								null,
								0,			        --@stamp int,					-- record update stamp  - optional passed in for updates
								'insert~RESTORE'	--@options varchar(50),         -- generic purposes
								
								,@content_type_ref = @content_type_ref
								,@content_text = @content_text
								,@header = @header
								,@notes = @notes
								,@tooltip = @tooltip
								,@categories = @categories
								,@tags = @tags
								,@content_key= @content_key
								,@brand_ref = @brand_ref
								,@user_access_ref = @user_access_ref
								,@published = @published
								,@cache = @cache
						end
						
					-- Check output message
					if isnull(@output_msg,'') = '' 
						select @alert_message = 'Restored content for: ' + isnull(@content_key,'') + '  (content id: ' +isnull(cast(@content_id as varchar(10)),'') + ')'
					else
						select @alert_message = 'Failed to restore content for: ' + isnull(@content_key,'') + '  (content id: ' +isnull(cast(@content_id as varchar(10)),'') + ') ' + @output_msg
				end
			else
				begin
					-- no content id found
					select @alert_message = 'Restore failed, table audit_content did not contain a record for: ' + isnull(@xdata,'') 
				end

			
			-- and set
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message	
					
		end
	
	-- mb - 2016-12-15 - WEC api calls
	else if @xproc='api-customer' and @access in ('A','M')
		begin	
			exec st_event @user_id, @settings, @sql_logging, @output_message, 'GET_CUSTOMER', @user_id, 'N', null, null, null, null, null, null, null, null, null
		end

	else if @xproc='api-container-received' and ISNUMERIC(@xdata) = 1 and @access in ('A','M')
		begin	
			exec st_event @user_id, @settings, @sql_logging, @output_message, 'GET_RECEIVED', @user_id, 'N', null, null, null, null, null, 'date_ymd', @xdata, 'containers', 'dm_m_container_received_api'
		end
		
	else if @xproc='check-container' and @access in ('A','M')
		begin	
			exec st_m_container_check @user_id, @settings, @sql_logging, @output_message output, @xdata
		end

	else if @xproc='reopen-basket' and ISNUMERIC(@xdata) = 1 and @access in ('A','M')
		begin
			-- check if we have an active basket for the same user and basket type
			select @alert_message = ''
			-- get basket ORG ID and also set basket_id
			select @basket_org_id = u.organisation_id, @basket_type = b.basket_type, @basket_id = b.basket_id
				from basket b with (nolock)
					join [user] u with (nolock) on b.user_id = u.user_id
				where basket_id = cast(@xdata as int)

			-- check if we got already an open basket for anybody for this organisation
			select @basket_count=COUNT(*) 
				from basket b with (nolock)
					join [user] u with (nolock) on u.user_id = b.user_id
			where basket_type=@basket_type and b.[status]='B' and u.organisation_id = @basket_org_id 

			-- check
			if isnull(@basket_count,0) > 0
				begin
					select @alert_message = 'Order cannot be reopened. There is already an active order in use. Please first close or clear the open order and try to re-open again.' 
				end
			else
				begin
					-- open basket processing
					select @basket_id = try_cast(@xdata as int)
					exec st_process_basket 
						@user_id, @settings, @sql_logging, @output_message=@output_message output, 
						@status='B', @basket_type='CALLOFF',
						@address_id=null, 
						@submit_notes= null,
						@incoming_basket_id = @basket_id
					-- if we had an error
					if isnull(@output_message ,'') <> ''
						select @alert_message = @output_message
				end
			-- if errors
			if isnull(@alert_message,'') = ''
				select @alert_message = 'Basket re-opened. Quantities have been set back into The Wine Vault cellar'
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'reopen-basket', @object_name, 'info', null, null, null, @alert_message
				
		end
		
	else if @xproc='ship-basket' and @access in ('A','M')
		begin
			select @alert_message = ''

			-- mark basket as shipped
			declare @ship_basket_count int = 0
			declare @ship_basket_id int = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '0') as int)
			declare @shipping_number varchar(20) = cast(dbo.fnGetPiece(@xdata, 2, '~', '') as varchar(20))

			select @ship_basket_count = count(1)
			from [basket]
			where [basket_id] = @ship_basket_id
			and [status] = 'A'

			if isnull(@ship_basket_count, 0) > 0
			begin
				update [basket]
				set [status] = 'S'
					,[reference] = @shipping_number
					,[updated] = getdate()
					,[updated_by] = @user_id
					,[stamp] = [stamp] + 1
				where [basket_id] = @ship_basket_id
				and [status] = 'A'

				-- and the items
				update basket_item
				set [status] = 'S'
					,updated = getdate()
					,updated_by = @user_id
					,[stamp] = [stamp] + 1
				where basket_id = @ship_basket_id
				and [status] = 'A'

				-- also update status of wine entries
				declare @ship_basket_wine_entry_id int

				Declare ship_basket_cursor cursor for 
					select bi.wine_entry_id
					from basket_item bi
					where basket_id = @ship_basket_id
   
				open ship_basket_cursor
				Fetch next from ship_basket_cursor into @ship_basket_wine_entry_id
				-- loop over entries
				While (@@Fetch_Status = 0 )
					Begin
							
					-- transfer each wine to the shipped cellar BUT WITH status Pending  
					EXEC st_update_wine_entry  @user_id, @settings, 'X', @out_msg OUTPUT, 
						-- type, id, stamp and options   (options is disposed type ~ price~ note)
						@output_type OUTPUT, @ship_basket_wine_entry_id OUTPUT,	0, 'NOALERTMESSAGE~NOTRANSACTION'
						,@status ='Shipped'

					-- If we have an error
					if isnull(@out_msg,'') <> ''
						begin
							select @out_msg = 'ERROR: Failed to set wine record to shipped: ' + @out_msg
							RAISERROR (@out_msg, 16, 1)
						end

					-- and get next one
					Fetch next from ship_basket_cursor into @ship_basket_wine_entry_id
	
				End 

				CLOSE ship_basket_cursor
				Deallocate ship_basket_cursor
				
				select @alert_message = 'Basket is now marked as shipped.'
			end
			else
				select @alert_message = 'This basket could not be marked as shipped. Please ensure that the basket is in state "pending".'
			
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'ship-basket', @object_name, 'info', null, null, null, @alert_message
				
		end

	-- wv 2016-10-03 added 67 wine orders  
	--   comword  = completed wine order
	--   preword  = prepared wine order
	else if @xproc in ('comword','preword') and ISNUMERIC(@xdata) = 1 and @access in ('A','M')
		begin
			declare @process_issue_id int = @xdata 
			-- Get basic data
			declare @issue_ref varchar(50)
			declare @comments varchar(8000)
			declare @issue_wine_entry_id int
			declare @issue_quantity int
			select @issue_ref= issue_ref,@comments=comments,@issue_wine_entry_id=wine_entry_id
				from wine_issue with (nolock)
			where wine_issue_id = @process_issue_id
			
			-- Only process ...
			if (ISNULL(@issue_ref,'') <> '') and (dbo.fnGetPiece(@issue_ref,1,'~','') in ('order','prepare','prepare-date','cellar'))
				begin
					-- Update this issue with ...
					declare @outp_msg varchar(500) = ''
					declare @outp_type varchar(50) = ''
					-- if prepare
					if @xproc = 'preword' and (@issue_ref not like '%completed%')
						begin
							-- update ref and comments
							select @issue_ref = @issue_ref + '~prepared'
							select @comments = @comments 
												+ char(13) + char(10) + 'Request PREPARED on: ' + DATENAME(weekday,getdate()) + ' - ' + dbo.fnDateTimeFormat(@user_id, @settings, getdate(),'','HH:MM','-',' - ') + ' '
												+ char(13) + char(10) + 'Prepared by: ' + dbo.fnGetUserData(@user_id,@settings,'alias','') + ' '
						
							EXEC st_update_wine_issue @user_id, @settings, 'X', @outp_msg OUTPUT,
								@outp_type OUTPUT,
								@process_issue_id,
								0,		--@stamp int,						 -- record update stamp  - optional passed in for updates
								'',		--@options varchar(50),            -- generic purposes
							
								@issue_ref = @issue_ref,
								@comments = @comments

							-- if error then ignore here  - is already log in audit trail			
					
						end
					else if @xproc = 'comword' and (@issue_ref not like '%completed%')
						begin

							-- update ref and comments
							select @issue_ref = @issue_ref + '~completed'
							select @comments = @comments 
												+ char(13) + char(10) + 'Request COMPLETED on: ' + DATENAME(weekday,getdate()) + ' - ' + dbo.fnDateTimeFormat(@user_id, @settings, getdate(),'','HH:MM','-',' - ') + ' '
												+ char(13) + char(10) + 'Completed by: ' + dbo.fnGetUserData(@user_id,@settings,'alias','') + ' '
						
							EXEC st_update_wine_issue @user_id, @settings, 'X', @outp_msg OUTPUT,
								@outp_type OUTPUT,
								@process_issue_id,
								0,		--@stamp int,						 -- record update stamp  - optional passed in for updates
								'',		--@options varchar(50),            -- generic purposes
							
								@issue_ref = @issue_ref,
								@comments = @comments

							-- mb - 2018-04-09 - reduce qty of wine entry if parameter is set (for 67 done via interface call, for oswalds done here)
							if dbo.fnGetParameter(@user_id, @settings, 'M_WINE_REQUEST_COMPLETED_UPDATE_QUANTITY', 'N') = 'Y'
							begin
								declare @moved_date datetime = getdate()
								select @issue_quantity = dbo.fnGetPiece(@issue_ref,2,'~','0')
								exec st_update_wine_entry_move @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT, @issue_wine_entry_id, 0, 'NOTRANSACTION', 'consume', @issue_quantity, @moved_date, null

								if isnull(@output_message,'') <> ''
									select @issue_wine_entry_id = 'Moving wine entry failed'
							end

							-- if error then ignore here  - is already log in audit trail
						end
						
					-- else   could report error ?
			end

	end


	else if @xproc='order-reminder' and @access in ('A','M')
		begin
			-- so xdata is offset and wine order id seperated by -
			-- check if we have an active basket for the same user and basket type
			declare @offset varchar(10)
			declare @wine_order_id varchar(10)
			-- and set
			select @offset = dbo.fnGetPiece(@xdata,1,'-','')
			select @wine_order_id = dbo.fnGetPiece(@xdata,2,'-','')
			-- only process if numeric
			if isnumeric(@offset)=1 and isnumeric(@wine_order_id)=1
				begin
					-- call 
					EXEC st_update_wine_order_reminder 
						@user_id, @settings, 'X', @output_msg OUTPUT,

						@wine_order_id = @wine_order_id,
						@offset = @offset,
						@options = @options

				end

			else
				begin
					-- report error
					select @alert_message = 'Wine order reminder error - values are not numeric:' + isnull(@xdata,'') + ' (nn-xxxx)  nn= offset and xxxx is wine order id.'
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'Wine-order-reminder', @object_name, 'error', null, null, null, @alert_message
				end
		end


	else if @xproc='check-basket'
		begin
			-- check if this user already has a basket, if so give message that wines ordered will be added to the current basket
			declare @count_basket_items int =  dbo.fnCountBasketItems(@user_id,@settings,null,'')
			-- if 1 or more
			if @count_basket_items > 0
				begin
					-- get message content
					select @alert_message = dbo.fnGetContentDescriptionDefault(@user_id,@settings, 
								'CURRENT_BASKET_ITEMS_WARNING',
								N'PLEASE NOTE: You already have {basket_items_text} in your current basket.
Any additional wine orders will be added to this order.')
					-- replace
					select @alert_message = replace(@alert_message,'{basket_items_text}',dbo.fnMultiple(cast(@count_basket_items as varchar(10)),'item','en','ADD-NUMBER'))
					-- set alert with 30 second delay
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000
				end
		end


	else if @xproc='wec-process'
		begin
			-- check if WEC user and merchant -- otherwise do not allow
			if isnull(@user_brand,'') <> 'WEC' or isnull(@access,'') not in ('A','M')
				begin
					select @alert_message = 'You must have admin access and brand WEC to run this process. (' + isnull(@xdata,'')+')'
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'wec-process', @object_name, 'error', null, null, null, @alert_message
					return
				end
			else
				begin
					-- standard vars
					declare @event_record_id int
					declare @process_status varchar(10)
					declare @event_type varchar(50) 
					declare @event_days varchar(10)

					-- load customer
					if @xdata in ('GetCustomers','GetContainersReceived','GetOpenContainers','GetProductsByCust','GetOpenOrders')
						or @xdata like 'GetProductsByCust~%'
						or @xdata like 'GetShippedOrders%'
						or @xdata like 'GetContainersClosed%'
						begin
							-- set event code
							select @event_type=''
							if @xdata = 'GetCustomers' 
								select @event_type = 'GET_CUSTOMER'
							-- Containers
							else if @xdata = 'GetContainersReceived' 
								select @event_type = 'GET_RECEIVED'
							-- Closed Containers
							else if @xdata like 'GetContainersClosed%' 
								select @event_type = 'GET_CONTAINERS_CLOSED'
							-- Open Containers
							else if @xdata = 'GetOpenContainers' 
								select @event_type = 'GET_OPEN_CONTAINERS'
							-- Containers
							else if @xdata = 'GetProductsByCust' 
								select @event_type = 'GET_PRODUCTS'
							-- products by customer
							else if @xdata like 'GetProductsByCust%'
								select @event_type = 'GET_PRODUCTS_BY_CUSTOMER'
							-- Open orders
							else if @xdata = 'GetOpenOrders' 
								select @event_type = 'GET_OPEN_ORDERS'
							-- Shipped orders
							else if @xdata like 'GetShippedOrders%'
								select @event_type = 'GET_SHIPPED_ORDERS'
							-- check if it was created in last ... min
							-- just dont want to run it too often
							-- get data
							select top 1 @event_record_id=event_record_id, @process_status = process_status
								from event_record with (nolock)
							where event_type = @event_type and created > dateadd(MINUTE,-5,getdate()) and process_status IN ('E','P','C')
								order by created desc
							-- if there was one
							-- at the moment just let rerun if it has been completed
							if isnull(@event_record_id,0) > 0 and @process_status not in ('C','E')
								begin
									-- if still running
									if @process_status <> 'C'
										select @alert_message = 'This event, ' + @event_type + ', is still running.'
									else
										select @alert_message = 'This event, ' + @event_type + ', has just completed running (in last few minutes).'
									-- alert message
									exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
									return
								end
							else 
								begin
									-- warning if error
									if @process_status='E' 
										begin
											select @alert_message = 'Warning: This event, ' + @event_type + ', errored in the previous run - you can run it again but please check progress.'
											-- alert message
											exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
										end

									-- create the event
									if @event_type = 'GET_RECEIVED'
										begin
											-- date for received
											declare @date_received varchar(20) = convert(varchar(40),getdate(), 112)
											-- and event
											EXEC st_event @user_id, @settings, 'X', null, 
												-- event, event user id, own transaction Y
												@event_type, @user_id, 'Y', null
												, null, null, null, null
												-- always pass in containers received  -- only 
												,'date_ymd',@date_received,'containers','dm_m_container_received_api'
												, @event_organisation_id = @user_org_id 

										end
										
									-- create the event
									else if @event_type = 'GET_CONTAINERS_CLOSED'
										begin

											-- mb - 2017-11-22 - always go back 14 days instead of expected arrival date

											-- date for received
											declare @date_closed datetime = dateadd(dd, -30, getdate())
											declare @date_closed_formatted varchar(20)

											while @date_closed < getdate()
											begin
												-- create event
												select @date_closed_formatted = convert(varchar(20), @date_closed, 112)
											
												-- and event
												EXEC st_event @user_id, @settings, 'X', null, 
													-- event, event user id, own transaction Y
													@event_type, @user_id, 'Y', null
													, null, null, null, null
													-- always pass in containers received  -- only 
													,'date_ymd',@date_closed_formatted,'containers','dm_m_container_received_api'
													, @event_organisation_id = @user_org_id 

												-- and increase date
												select @date_closed = dateadd(dd, 1, @date_closed)

											end


											/*
											-- date for received
											declare @date_closed datetime
											declare @date_closed_formatted varchar(20)

											select top 1 @date_closed = cast(expected_arrival_date as datetime)
												from container with (nolock)
											where ([status] = 'C' and [status_interface] = 'C')
												or [status] = 'T'
											order by expected_arrival_date asc

											-- if nothing just do for yesterday
											if @date_closed is null
												select @date_closed = dateadd(dd, -1, getdate())

											while @date_closed < getdate()
											begin

												-- only process a date if we have any potential containers with this arrival date
												if (select count(1) from container 
														where cast(@date_closed as date) = cast(expected_arrival_date as date)
															and ([status] = 'C' and [status_interface] = 'C') or [status] = 'T') > 0
													begin

														-- create event
														select @date_closed_formatted = convert(varchar(20), @date_closed, 112)
											
														-- and event
														EXEC st_event @user_id, @settings, 'X', null, 
															-- event, event user id, own transaction Y
															@event_type, @user_id, 'Y', null
															, null, null, null, null
															-- always pass in containers received  -- only 
															,'date_ymd',@date_closed_formatted,'containers','dm_m_container_received_api'
															, @event_organisation_id = @user_org_id 
													end

												-- and increase date
												select @date_closed = dateadd(dd, 1, @date_closed)

											end

											---- date for received
											--declare @date_closed varchar(20) = convert(varchar(40),getdate(), 112)

											---- get add days option
											--select @event_days = dbo.fnGetPiece(@xdata, 2, '~', '0')
											
											--if isnumeric(@event_days) = 1
											--	select @date_closed = convert(varchar(20),dateadd(dd, -cast(@event_days as int), getdate()), 112)

											---- and event
											--EXEC st_event @user_id, @settings, 'X', null, 
											--	-- event, event user id, own transaction Y
											--	@event_type, @user_id, 'Y', null
											--	, null, null, null, null
											--	-- always pass in containers received  -- only 
											--	,'date_ymd',@date_closed,'containers','dm_m_container_received_api'
											--	, @event_organisation_id = @user_org_id 
											*/

										end

									else if @event_type = 'GET_OPEN_CONTAINERS'
										begin
											-- date for received
											declare @date_open varchar(20) = convert(varchar(40),getdate(), 112)
											-- and event
											EXEC st_event @user_id, @settings, 'X', null, 
												-- event, event user id, own transaction Y
												@event_type, @user_id, 'Y', null
												, null, null, null, null
												-- always pass in containers received  -- only 
												,'date_ymd',@date_open,'containers','dm_m_container_received_api'
												, @event_organisation_id = @user_org_id 

										end

									else if @event_type = 'GET_PRODUCTS'
										begin
											-- loop over all WEC customers and create an event for inventory check
											-- only for customer in WEC where we have a customer number
											DECLARE inventory_customers CURSOR FOR
												SELECT organisation_id
													FROM organisation o with (nolock)
													LEFT JOIN user_defined_field udf with (nolock) on udf.table_name='organisation' and udf.brand_ref='WEC' and udf.record_id = o.organisation_id
												WHERE o.brand_ref = 'WEC'
													and isnull(udf.value_1,'') <> ''
													and isnull(o.[disabled],0) = 0
													and isnumeric(isnull(udf.value_1,'')) = 1
    
											-- get customer number
											declare @inventory_org_id int = null
											
											OPEN inventory_customers
											FETCH NEXT FROM inventory_customers INTO @inventory_org_id
											WHILE (@@FETCH_STATUS = 0)
											BEGIN

												-- create event
												EXEC st_event @user_id, @settings, 'X', null, 
													-- event, event user id, own transaction Y
													@event_type, @user_id, 'Y', null
													, null, null, null, null
													-- pass in organisation 
													,'organisation_id',@inventory_org_id, 'products', 'dm_m_products_by_customer_api'
													, @event_organisation_id = @user_org_id 
												
												FETCH NEXT FROM inventory_customers INTO @inventory_org_id
											END
											CLOSE inventory_customers
											DEALLOCATE inventory_customers

										end
									else if @event_type = 'GET_PRODUCTS_BY_CUSTOMER'
										begin
											-- get customer number
											declare @cust_org_id varchar(50) = dbo.fnGetPiece(@xdata,2,'~','')
											-- we could check if numeric ?
											-- We dont need it but customer number is used in interface from here
											-- select @customer_id = value_1 from user_defined_field with (nolock) where table_name ='organisation' and brand_ref='WEC' and record_id = @cust_org_id
											-- and event
											EXEC st_event @user_id, @settings, 'X', null, 
												-- event, event user id, own transaction Y
												@event_type, @user_id, 'Y', null
												, null, null, null, null
												-- pass in organisation 
												,'organisation_id',@cust_org_id, 'products_by_customer', 'dm_m_products_by_customer_api'
												, @event_organisation_id = @user_org_id 

										end
									else if @event_type = 'GET_SHIPPED_ORDERS'
										begin
											-- date for shipped
											declare @date_shipped varchar(20) = convert(varchar(40),getdate(), 112)

											-- get add days option
											select @event_days = dbo.fnGetPiece(@xdata, 2, '~', '0')
											
											if isnumeric(@event_days) = 1
												select @date_shipped = convert(varchar(20),dateadd(dd, -cast(@event_days as int), @date_shipped), 112)

											-- and event
											EXEC st_event @user_id, @settings, 'X', null, 
												-- event, event user id, own transaction Y
												@event_type, @user_id, 'Y', null
												, null, null, null, null
												-- always pass in orders shipped  -- only 
												,'date_ymd',@date_shipped,'orders','dm_m_orders_shipped_api'
												, @event_organisation_id = @user_org_id 

										end
									else
										begin
											EXEC st_event @user_id, @settings, 'X', null, 
												-- event, event user id, own transaction Y
												@event_type, @user_id, 'Y', null
												, null, null, null, null
												, @event_organisation_id = @user_org_id 
										end

									-- and message
									select @alert_message = 'Started event, ' + @event_type + ', this process may take a few minutes to complete.'
									exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000
								end
						end

				end

		end

	else if @xproc='copy-container-case'
		begin
			-- copy the most recent case for this container
			-- DO NOT copy merchant code !!

			select @alert_message = ''

			-- first check container id
			if isnumeric(@xdata) <> 1 or isnull(@xdata,'') in ('','0','-1')
				begin
					-- error
					select @alert_message = 'This container id is not numeric: ' + isnull(@xdata,'')
				end

			else if (select count(1) from container with (nolock) where container_id = @xdata) = 0
				begin
					-- error
					select @alert_message = 'This container id does not exist: ' + isnull(@xdata,'')
				end

			else if (select count(1) from wine_entry with (nolock) 
				where container_id = @xdata and isnull(mixed_case_id,0) > 0 and isnull([disabled],0)=0) = 0
				begin
					-- no mixed case, copy is ONLY for mixed cases
					select @alert_message = 'This container does not contain any mixed cases. Copy is only allowed for mixed cases.'
				end

			else
				begin

					-- get most recent mixed case id
					declare @copy_from_mx_id int
					select top 1 @copy_from_mx_id = mixed_case_id from wine_entry with (nolock) 
						where container_id = @xdata and isnull(mixed_case_id,0) > 0 and isnull([disabled],0) = 0 
					order by created desc

					-- get new mixed case name for this container (container used to get org id, that's used to get next mx nr)
					declare @new_case_name varchar(100) = ''
					exec dm_m_sql @user_id, @settings, @sql_logging, @output_message output, @xdata, 'container-new-mixed-case-id', '', @output = @new_case_name OUTPUT

					-- and call copy
					declare @new_mixed_case_id int
					EXEC st_update_mixed_case_copy  @user_id, @settings, @sql_logging, @output_msg OUTPUT,
							@from_mixed_case_id=@copy_from_mx_id,
							@options='',
							@new_case_name = @new_case_name,
							@new_mixed_case_id= @new_mixed_case_id  OUTPUT

					-- if error
					if isnull(@output_msg,'') <> ''
						select @alert_message = 'Failed to copy mixed case: ' + @output_msg
					else
						select @alert_message = ' Copied mixed case.'

				end


			-- if we have a message
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 10000

		end

	-- wv 2017-05-24 wine-sold-invoice
	-- THIS IS NOT SOLD ON EXCHANGE but sold as part of 67 consigment process
	else if @xproc='wine-sold-invoice'
		begin
			-- 
			select @alert_message =''
			-- must have numeric valid id
			if isnumeric(@xdata) <> 1 or isnull(@xdata,'') in ('','0','-1')
				begin
					-- error
					select @alert_message = 'This invoice id is not numeric (org nr_yyyyww): ' + isnull(@xdata,'')
				end
			else
				begin
					-- call process to generate
					declare @id as bigint = @xdata
					declare @or_id int = left(@id,len(@id)-6)

					-- and event
					EXEC st_event @user_id, @settings, 'X', null, 
						-- event, event user id, own transaction Y
						'67_SOLD_WINE_INVOICE', 172, 'Y', null
						, null, null, null, null
						-- pass in id 
						,'org_id_year_week',@id, 'invoice','dm_report_67_sold_wines_invoice'
						, @event_organisation_id = @or_id 
					-- message
					select @alert_message = 'Started invoice generation in background - completed in 10 seconds'
				end

			-- if we have a message
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 10000

		end
		
	-- mb 2017-09-25 wine-sold-invoice-email
	-- THIS IS NOT SOLD ON EXCHANGE but sold as part of 67 consigment process
	else if @xproc='wine-sold-invoice-email'
		begin
			-- 
			select @alert_message =''
			-- must have numeric valid id
			if isnumeric(@xdata) <> 1 or isnull(@xdata,'') in ('','0','-1')
				begin
					-- error
					select @alert_message = 'This invoice id is not numeric (org nr_yyyyww): ' + isnull(@xdata,'')
				end
			else
				begin
					-- call process to generate
					declare @inv_id as bigint = @xdata
					declare @inv_or_id int = left(@inv_id,len(@inv_id)-6)

					-- and event
					EXEC st_event @user_id, @settings, 'X', null, 
						-- event, event user id, own transaction Y
						'67_SOLD_WINE_INVOICE_EMAIL', 172, 'Y', null
						, null, null, null, null
						-- pass in id 
						,'org_id_year_week',@inv_id, 'invoice','dm_report_67_sold_wines_invoice'
						, @event_organisation_id = @inv_or_id 
					-- message
					select @alert_message = 'Sending invoice email in background'
				end

			-- if we have a message
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 10000

		end


	-- wv 2017-06-11  Added wine price exclude process
	else if @xproc='wine-price-exclude' and @access in ('A','M')
		begin
			-- so xdata is wine_id, vintage, price mode and action  e.g. 12345~-1~E~update
			-- update will handle both insert and updating existing value
			declare @exc_wine_id varchar(10)
			declare @exc_vintage varchar(10)
			declare @price_mode varchar(10)
			declare @exclude_action varchar(50)
			-- and set
			select @exc_wine_id = dbo.fnGetPiece(@xdata,1,'~','')
			select @exc_vintage = dbo.fnGetPiece(@xdata,2,'~','')
			select @price_mode = dbo.fnGetPiece(@xdata,3,'~','')
			select @exclude_action = dbo.fnGetPiece(@xdata,4,'~','')
			-- only process if numeric
			if isnumeric(@exc_wine_id)=1 and isnumeric(@exc_vintage)=1
				begin
					-- call 
					declare @wine_price_exclude_id int
					-- and call
					EXEC st_update_wine_price_exclude 
						@user_id, @settings, 'X', @output_msg OUTPUT,

						null, -- @output_type varchar(10) = '' OUTPUT, 
						@wine_price_exclude_id OUTPUT,
						null,  --@stamp int,						 -- record update stamp  - optional passed in for updates
						@exclude_action,

						@user_brand,
						@exc_wine_id,
						@exc_vintage,
						@price_mode,

						null,		-- @new_price decimal(18,2),
						null		-- @price_adj_percentage decimal(18,2)

				end

			else
				begin
					-- report error
					select @alert_message = 'Wine exclude price error - values are not numeric:' + isnull(@xdata,'') + ' (wine_id~vintage~mode~action)'
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'Wine-price-exclude', @object_name, 'error', null, null, null, @alert_message
				end
		end

	-- wv 2017-06-16  Added action to receive wine - updates value 20 of the club wine entry
	else if @xproc='wine-bought-received' and @access in ('A','M')
		begin
			-- so xdata is wine_id ~ vintage ~ wine_entry_id ~ member_udf_id
			-- this was we id and udf id of the club wine  but now changed to id's of the member wines
			-- update will handle both insert and updating existing value
			declare @udf_wine_id varchar(10)
			declare @udf_vintage varchar(10)
			declare @udf_wine_entry_id varchar(10)
			declare @member_udf_id varchar(10)
			-- and set
			select @udf_wine_id = dbo.fnGetPiece(@xdata,1,'~','')
			select @udf_vintage = dbo.fnGetPiece(@xdata,2,'~','')
			select @udf_wine_entry_id = dbo.fnGetPiece(@xdata,3,'~','')
			-- when inserting there is NO member_udf_id !!!
			select @member_udf_id = dbo.fnGetPiece(@xdata,4,'~','')
			-- Only process if numeric
			if isnumeric(@udf_wine_id)=1 and isnumeric(@udf_vintage)=1 and isnumeric(@udf_wine_entry_id)=1 
				and (isnumeric(@member_udf_id)=1 or @member_udf_id = '')
				begin
					-- Check if exist, if not don't continue
					-- and call if we have an entry
					-- and field 14 and 15 MUST be empty (otherwise already received)
					if @member_udf_id = ''
							or
						(select count(1) from user_defined_field with (nolock) where udf_id = @member_udf_id
						and isnull(value_14,'') = '' and isnull(value_15,'') = '') = 1
						begin
							-- set action
							declare @udf_action varchar(50) ='Insert'
							if @member_udf_id <> ''
								select @udf_action = 'Update'
							-- get current date as varchar()
							declare @current_date_display varchar(20) = cast(cast(getdate() as date) as varchar(20))
							-- call update user defined field
							exec st_update_user_defined_field @user_id, @settings, @sql_logging, @output_message OUTPUT
								, @output_type OUTPUT,@member_udf_id OUTPUT, 0, @udf_action, '67', 'wine-entry', @udf_wine_entry_id
								,@value_14 = @current_date_display, @value_15 = @user_id
						end

					-- error 
					else
						begin
							-- report error
							select @alert_message = 'Wine received-consigned process. This is not a valid udf id for the member wine record (' + isnull(@member_udf_id,'') + ') - please contact WO support. (key data:' + isnull(@xdata,'') + ' (wine_id~vintage~wine_entry_id~member_udf_id)'
							exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
							-- and always record in audit trail
							exec st_audit_hdr  @user_id, @settings, 'Wine-bought-received', @object_name, 'error', null, null, null, @alert_message
						end
				end

			else
				begin
					-- report error
					select @alert_message = 'Wine received error - values are not numeric:' + isnull(@xdata,'') + ' (wine_id~vintage~wine_entry_id)'
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'Wine-bought-received', @object_name, 'error', null, null, null, @alert_message
				end
		end

	-- wv 2017-08-17  En primeur certificate
	else if @xproc='en-primeur-certificate' and @access in ('A','M')
		begin
			-- so xdata is wine_order_id 
			-- use piece in case we get more data to pass in
			declare @ep_wine_order_id varchar(10) = dbo.fnGetPiece(@xdata,1,'~','')

			-- Only process if numeric
			if isnumeric(@ep_wine_order_id)=1
				begin
					-- Check if exist, if not don't continue
					if (select count(1) from wine_order with (nolock) where wine_order_id = @ep_wine_order_id and isnull(order_status,'') in ('P','C'))=1
						begin
							-- and event
							EXEC st_event @user_id, @settings, 'X', null, 
								-- event, event user id, own transaction Y
								'EP_CERTIFICATE', @user_id, 'Y', null
								, null, null, null, null
								-- pass in id 
								,'wine_order_id',@ep_wine_order_id, 'order','dm_en_primeur'
								, @event_organisation_id = @or_id
							-- message
							select @alert_message = 'Started ep-certificate generation in background - completed in a few seconds'

						end

				end

			else
				begin
					-- report error
					select @alert_message = 'EP certificate error - wine order id is numeric:' + isnull(@xdata,'')
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'EP-certificate', @object_name, 'error', null, null, null, @alert_message
				end
		end


	-- wv 2017-09-08  Update wine menu list  (only for admin)
	else if @xproc='update-67-wine-menu-list' and @access in ('A','M')
		begin
			-- just call menu list for refresh
			declare @token varchar(100) = 'pm124578'  -- WHICH IS description !! 
			-- query = name~~vintage~~winetype~~country~~region~~grape~'
			-- query: type~glass sort by: sort dir: asc
			exec [dm_m_ws_wines_67] @user_id = 0, @settings = @settings, @sql_logging  = 'X', @output_message = @output_msg OUTPUT
			, @token = @token, @query = 'name~'
			, @sort_by = '', @sort_dir = 'asc', @records = null, @page = 1
			, @retrieve = 'Y'

			-- update messages
			select @alert_message = 'Updated wine menu list'
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'Update-67-wine-menu', @object_name, 'info', null, null, null, @alert_message

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end

	-- wv 2017-09-23  Suspend all offers for a user
	-- at the moment just ME
	else if @xproc = 'bulk-suspend-offers' and @access = 'A' and isnumeric(@xdata)= 1
		begin
			-- check xdata is an organisation id
			declare @x_org_id int = @xdata
			-- check if valid org id
			if @alias not in ('wolteradmin','peteradmin') 
				begin
					select @alert_message = 'You are not authorised to suspend all offers. Ask Wolter.'
				end

			else if (select count(1) from organisation with (nolock) where organisation_id = @x_org_id) = 0
				begin
					select @alert_message = 'This is not a valid organisation id: ' + isnull(cast(@x_org_id as varchar(10)),'')
				end

			else
				begin
					-- check if there are any open offers for this user
					if (select count(1) from wine_order with (nolock) where seller_id = @x_org_id and order_type='O' and order_status ='O' and cast(valid_till as date) > cast(getdate() as date)) = 0
						begin
							select @alert_message = 'This user does not have any active current offers that can be suspended, org id: ' + isnull(cast(@x_org_id as varchar(10)),'')
						end
					else
						begin
							-- now suspend the offers
							update wine_order
								set order_status ='S',suspend_reason ='Bulk offers suspended',updated_by = @user_id, updated = getdate(), stamp=stamp+1
							where seller_id = @x_org_id and order_type='O' and order_status ='O' and cast(valid_till as date) > cast(getdate() as date)
							-- and alert
							select @alert_message = 'Suspended all offers for this user, org id: ' + isnull(cast(@x_org_id as varchar(10)),'')
						end
				end

			-- always have message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end


	-- at the moment just ME
	else if @xproc ='bulk-suspend-bids' and @access = 'A' and isnumeric(@xdata)= 1
		begin
			-- check xdata is an organisation id
			declare @xb_org_id int = @xdata
			-- check if valid org id
			if @alias not in ('wolteradmin','peteradmin') 
				begin
					select @alert_message = 'You are not authorised to suspend all bids. Ask Wolter'
				end

			else if (select count(1) from organisation with (nolock) where organisation_id = @xb_org_id) = 0
				begin
					select @alert_message = 'This is not a valid organisation id: ' + isnull(cast(@xb_org_id as varchar(10)),'')
				end

			else
				begin
					-- check if there are any open offers for this user
					if (select count(1) from wine_order with (nolock) where buyer_id = @xb_org_id and order_type='B' and order_status ='O' and cast(valid_till as date) > cast(getdate() as date)) = 0
						begin
							select @alert_message = 'This user does not have any active current bids that can be suspended, org id: ' + isnull(cast(@xb_org_id as varchar(10)),'')
						end
					else
						begin
							-- now suspend the offers
							update wine_order
								set order_status ='S',suspend_reason ='Bulk bids suspended',updated_by = @user_id, updated = getdate(), stamp=stamp+1
							where buyer_id = @xb_org_id and order_type='B' and order_status ='O' and cast(valid_till as date) > cast(getdate() as date)
							-- and alert
							select @alert_message = 'Suspended all bids for this user, org id: ' + isnull(cast(@xb_org_id as varchar(10)),'')
						end
				end


			-- should always have a message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end


	-- at the moment just ME
	else if @xproc ='select-entries-reset' and isnull(@xdata,'') <> ''
		begin
			-- xdata is the mode

			-- just call the reset call, at the moment no message or alrts
			declare @rec_count int =  0
			EXEC st_update_select_table  @user_id, @settings, 'X', @output_msg OUTPUT,
				@select_mode = @xdata,
				@options = 'delete-all',
				@delete_entries = @rec_count OUTPUT

			-- should always have a message
			select @alert_message = 'De-selected ' + cast(@rec_count as varchar(10)) + case when @rec_count = 1 then ' entry' else ' entries' end + '.'
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end

	-- wv 2017-10-05  recalculate loan values
	else if @xproc ='recalculate-loan-values'
		begin

			-- if xdata passed as loan id use it
			declare @loan_filter int = null
			declare @cal_options varchar(50) = 'REFRESH'
			-- if NO loan id then error
			if isnumeric(isnull(@xdata,'void')) <> 1
				begin
					-- should always have a message
					select @alert_message = 'Error: Missing loan id - loan id must be passed in. (' + isnull(@xdata,'')+')'
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
				end
			else
				begin
					select @loan_filter = cast(@xdata as int)
					-- just call the recalculate with option refresh
					exec st_loan_calculate_value  @user_id, @settings, @sql_logging, @output_message output, @loan_filter, @cal_options
					-- if error
					if isnull(@output_message,'') <> ''
					select @alert_message = 'Error in LTV loan calculation for loan: ' + isnull(@xdata,'') + '. Error: ' + @output_message
					else
					-- should always have a message
					select @alert_message = 'Recalculated all loan LTV values for loan: ' + isnull(@xdata,'')
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
				end

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end



	-- wv 2017-10-31  Move landed wine into specific cellar
	else if @xproc ='land-wine-cellar'
		begin
			-- initialise
			select @alert_message = ''
			-- get container id and cellar id
			declare @container_id varchar(10) =  dbo.fnGetPiece(isnull(@xdata,''), 1, '~', '')
			declare @cellar_id varchar(10) =  dbo.fnGetPiece(isnull(@xdata,''), 2, '~', '')
			-- must be valid
			if isnumeric(@container_id) <> 1 or isnumeric(@cellar_id) <> 1
				begin
					-- set error message
					select @alert_message = 'Container or cellar id is not numeric, should be container~cellar, value is: ' + Isnull(@xdata,'')
				end
			else
				begin
					-- check valid container and cellar id belongs to the same user
					declare @container_owner int = 0
					declare @container_status varchar(10)
					select @container_owner = organisation_id, @container_status = [status]
						from container with (nolock)
					where container_id = @container_id 

					-- if nothing
					-- wv 2018-03-16 added Status P  (not USED for Western !!)
					if isnull(@container_status,'') not in ('A','P','L') 
						begin
							-- set error message
							select @alert_message = 'This container does not have status Open.  Container status is: ' + isnull(@container_status,'') 
						end
					else
						begin
							-- check your are authorised
							select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_USERS_CONTAINER_LANDED','')
							-- if not in the list
							if (isnull(@authorised,'') <> '' and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%'))
								begin
									-- log in audit
									select @audit_exception ='You are not authorised to update containers to landed. (AUTHORISED_USERS_CONTAINER_LANDED)'
									exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-authorised', null, @container_id, null, @audit_exception
									select @alert_message = @audit_exception
								end
							else
								begin

									-- and cellar
									declare @cellar_owner int = 0
									select @cellar_owner = owner_id
										from cellar with (nolock)
									where cellar_id = @cellar_id

									-- if not the same (or they dont exist)
									if isnull(@container_owner,0) = 0 or isnull(@container_owner,0) <> isnull(@cellar_owner,0) 
										begin
											-- set error message
											select @alert_message = 'Container and cellar do not belong to the same owner. Container owner / Cellar owner: ' + isnull(cast(@container_owner as varchar(10)),'') + ' / ' + isnull(cast(@cellar_owner as varchar(10)),'')  + ' (xdata: container~cellar=' + Isnull(@xdata,'') +')'
										end

									else
										begin
											-- we now have a valid container and valid cellar id 
											-- so call close_container to move wine into the right cellar and close the container
											declare @con_msg varchar(1000) = ''
											-- let this module do the alert message
											exec st_m_container_close @user_id, @settings, @sql_logging, @con_msg OUTPUT,
												@container_id, @cellar_id, ''
											-- if error
											if isnull(@con_msg,'') <> ''
												set @alert_message = 'Error in closing container: ' + @con_msg
										end
								 end
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, 'alert_message_html_warning'

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end


	else if @xproc ='land-wine-transit'
		begin
			-- initialise
			select @alert_message = ''
			-- get container id and cellar id
			select @cont_id = @xdata
			select @loc_key = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_INBOUND_LOCATION','')
			-- must be valid
			if isnumeric(@cont_id) <> 1 
				begin
					-- set error message
					select @alert_message = 'The container id is not numeric, value is: ' + Isnull(@xdata,'')
				end
			else
				begin
					-- check your are authorised
					select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_USERS_CONTAINER_TRANSIT','')
					-- if not in the list
					if (isnull(@authorised,'') <> '' and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%'))
						begin
							-- log in audit
							select @audit_exception ='You are not authorised to update containers. (AUTHORISED_USERS_CONTAINER_TRANSIT)'
							exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-authorised', null, @cont_id, null, @audit_exception
							select @alert_message = @audit_exception
						end
					else
						begin
							-- check status
							select @cont_status = ''
							select @cont_status = c.[status]
								from container c with (nolock)
							where c.container_id = @cont_id 
							
							-- if nothing
							if isnull(@cont_status,'') not in ('A','P') 
								begin
									-- set error message
									select @alert_message = 'This container does not have status Pending or Submitted (A or P). Container status is: ' + isnull(@cont_status,'') 
								end

							else
								begin
									-- we now have a valid container 
									-- just call to update status to  In Transit  (L)
									-- and also pass option landed

									-- and status to transmitted
									exec st_update_container @user_id, @settings, @sql_logging, @output_message OUTPUT
										, null, @cont_id, 0, 'update~ADMIN~NOALERTMESSAGE~LANDED'
										, @status_interface = '', @status = 'L'
									
								--	if dbo.fnGetParameter(@user_id,@settings,'SET_INBOUND_LOCATION','N') = 'Y'
									--	exec st_wine_allocate @user_id, @settings, @sql_logging, @output_message OUTPUT, 'allocate', @loc_key, @cont_id, @options

									-- if we had an error
									if isnull(@output_message,'') <> ''
										begin
											select @audit_exception = 'Error in container update: ' + @output_message
										end
									else
										begin
											-- audit-- get description from lookup
											declare @status_description varchar(50) = dbo.fnGetLookupDescriptionDefault(@user_id,@settings,'ContainerStatus','L','L')
											-- log in audit
											select @audit_exception = replace('Changed container status to {status_description} (status L), status was: ' + isnull(@cont_status,'')
															,'{status_description}',isnull(@status_description,''))
										end
									-- record in audit and display
									exec st_audit_hdr  @user_id, @settings, 'change-status', @object_name, 'completed', null, @cont_id, null, @audit_exception
									-- and message
									exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 30000
								 end
						end
					end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, 'alert_message_html_warning'

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end


	else if @xproc ='land-wine-submit'
		begin
			-- initialise
			select @alert_message = ''
			-- get container id
			select @cont_id = @xdata
			-- must be valid
			if isnumeric(@cont_id) <> 1 
				begin
					-- set error message
					select @alert_message = 'The container id is not numeric, value is: ' + Isnull(@xdata,'')
				end
			-- must have at least some wine entries
			else if (select count(1) from wine_entry with (nolock) where isnull([disabled],0)=0 and container_id = cast(@xdata as integer)) = 0
				begin
					-- set error message
					select @alert_message = 'This container does not have any wines. Please add wines before submitting the container.'
				end
			else
				begin
					-- check your are authorised
					select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_USERS_CONTAINER_TRANSIT','')
					-- if not in the list
					if (isnull(@authorised,'') <> '' and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%'))
						begin
							-- log in audit
							select @audit_exception ='You are not authorised to update containers. (AUTHORISED_USERS_CONTAINER_TRANSIT)'
							exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-authorised', null, @cont_id, null, @audit_exception
							select @alert_message = @audit_exception
						end
					else
						begin
							-- status 
							select @cont_status = ''
							select @cont_status = [status], @cont_org_id = organisation_id
								from container
							where container_id = @cont_id 
							-- if nothing
							if isnull(@cont_status,'') <> 'A' 
								begin
									-- set error message
									select @alert_message = 'This container does not have status Pending (A). Container status is: ' + isnull(@cont_status,'') 
								end
							else
								begin
									-- We now have a valid container 
									-- if switch CONTAINER_SINGLE_CASE_PROCESSING is set then split whole cases now
									if dbo.fnGetParameter(@user_id,@settings,'CONTAINER_SINGLE_CASE_PROCESSING','') = 'Y'
										begin
											-- split wine entries for a container into one per case
											declare @split_msg varchar(1000) = '' 
											-- run
											exec st_m_container_split_entries @user_id, @settings, @sql_logging, @split_msg OUTPUT
												,'NOALERTMESSAGE', @cont_id  
											-- if error ignore for now. should be recorded already
										end
									-- now Update container status to Submitted
									update container
										set [status]='P', updated = getdate(), updated_by = @user_id
									where container_id=@cont_id

									-- Update the charges if charges enabled
									if dbo.fnGetParameter(@user_id,@settings,'ENABLE_CUSTOM_CHARGES','') = 'Y'
										begin
											-- we now have valid container, call create charges
											exec st_process_billing_charge @user_id,@settings,'X',@alert_message OUTPUT, 
												@run_type = 'inbound', @record_id = @cont_id, @options = 'NOALERTMESSAGE'
											-- if ok
											if isnull(@alert_message,'') = ''
												begin
													-- set template
													select @audit_exception = 'Created the container charges. '
												end
										end

									-- create event, get actual user
									declare @cont_user_id int = dbo.fnGetOrganisationUser(@cont_org_id)
									-- and create event
									EXEC st_event @user_id,@settings, null, @output_message OUTPUT
										,'CONTAINER_STATUS_P_SUBMITTED', @user_id, 'N', null
										,null, null, null, null
										,'container_id',@cont_id,'container','dm_m_container'
										,'organisation_id',@cont_org_id,'organisation','dm_organisation'
										,'event_user_id',@cont_user_id,'user','dm_user'

									-- audit
									select @audit_exception = isnull(@audit_exception,'') + ' Changed container status to P (submitted), status was: A'
									exec st_audit_hdr  @user_id, @settings, 'change-status', @object_name, 'completed', null, @cont_id, null, @audit_exception
									-- and message
									exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', 'Updated container status to ''Submitted''.', null, 30000
								 end
						end
					end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, 'alert_message_html_warning'

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end


	else if @xproc ='admin-delete-cellar'
		begin
			-- initialise
			select @alert_message = ''
			declare @cellar_msg varchar(1000) = ''

			-- must be valid
			if isnumeric(@xdata) <> 1 
				begin
					-- set error message
					select @alert_message = 'Cellar id is not numeric, value is: ' + Isnull(@xdata,'')
				end
			else
				begin
					-- let this module do the alert message
					exec st_update_cellar_delete @user_id, @settings, @sql_logging, @cellar_msg OUTPUT
						, null
						, @xdata
						, ''
					-- if error
					if isnull(@cellar_msg,'') <> ''
						set @alert_message = 'Error in deleting cellar: ' + @cellar_msg
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end

	else if @xproc ='admin-reset-trade'
		begin

			-- ONLY allowed if....
			--if isnull(@alias,'') not in ('wolteradmin') or isnull(@access,'') <> 'A'
			if isnull(@access,'') not in ('M','A','W') or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_RESET_TRADE','')+',') not like ('%,'+@alias+',%'))
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(@xdata) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Order reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else if (select order_status from wine_order with (nolock) 
						where wine_order_id = cast(@xdata as integer) 
							and cast(status_date as date) > dateadd(Y,-1,getdate())  ) <> 'C' 
				begin
					-- Must be a completed order in last year
					select @alert_message = 'Order status is not completed (in the last year)'
				end
			else
				begin
					-- we now have valid order
					-- reset to pending
					update wine_order
						set order_status ='P',updated_by=@user_id,updated=getdate()
						-- wv 2019-06-19 reset completed date to null
						,completed_date = null,cancel_date = null
					where wine_order_id = cast(@xdata as integer)

					-- wv 2019-06-19  NEED to add check on postings, this assumes they are done when purchased

					-- log in audit
					select @audit_exception ='Changed order status from Completed to Pending: ' + @xdata
					exec st_audit_hdr  @user_id, @settings, 'reset-order', @object_name, 'completed', null, @xdata, null, @audit_exception
	
					-- and message
					select @alert_message ='Updated order status from Completed to Pending'
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end

	else if @xproc ='admin-container-reset-pending'
		begin

			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(@xdata) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Container reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else
				begin
					-- check status
					select @status=[status] from container with (nolock) 
						where container_id = cast(@xdata as integer)
					-- if NOT pending
					if @status <> 'P'
						begin
							-- if already completed
							if @status = 'C'
								select @alert_message = 'This container is already completed and cannot be reset'
							else if @status in ('A','')
								select @alert_message = 'The status of this container is already pending'
							else 
								select @alert_message = 'This container cannot be reset, the status is not Submitted, status is: ' + isnull(@status,'')
						end
					else
						begin
							-- we now have valid container, reset to pending
							update container
								set [status] ='A',updated_by=@user_id,updated=getdate()
							where container_id = try_cast(@xdata as integer)
							-- log in audit
							select @audit_exception ='Changed container status back from Submitted to Pending: ' + @xdata
							exec st_audit_hdr  @user_id, @settings, 'reset-container', @object_name, 'completed', null, @xdata, null, @audit_exception
	
							-- and message
							select @alert_message ='Updated container status from Submitted to Pending'
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'
		end

	--jf 2019-05-07 reset to arrived
	else if @xproc ='admin-container-reset-submitted'
		begin

			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(@xdata) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Container reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else
				begin
					-- check status
					select @status=[status] from container with (nolock) 
						where container_id = cast(@xdata as integer)
					-- if NOT pending
					if @status <> 'L'
						begin
							-- if already completed
							if @status = 'C'
								select @alert_message = 'This container is already completed and cannot be reset'
							else if @status in ('P','')
								select @alert_message = 'The status of this container is already submitted'
							else 
								select @alert_message = 'This container cannot be reset, the status is not Arrived, status is: ' + isnull(@status,'')
						end
					else
						begin
							-- we now have valid container, reset to pending
							update container
								set [status] ='P',updated_by=@user_id,updated=getdate()
							where container_id = try_cast(@xdata as integer)
							-- log in audit
							select @audit_exception ='Changed container status back from Arrived to Submitted: ' + @xdata
							exec st_audit_hdr  @user_id, @settings, 'reset-container', @object_name, 'completed', null, @xdata, null, @audit_exception
	
							-- and message
							select @alert_message ='Updated container status from Arrived to Submitted'
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'
		end


	-- set charges
	else if @xproc in ('admin-container-create-charges','admin-container-recreate-charges')
		begin
			select @alert_message = ''
			select @alert_template = 'alert_message_html_danger'
			-- container id
			select @con_id = try_cast(@xdata as integer)
			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function. Admin access required'
				end
			else if ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CHARGES','')+',') not like ('%,'+@alias+',%'))
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function. Please contact support. (switch: USERS_ALLOWED_TO_EDIT_CHARGES)'
				end
			else if isnull(@con_id,0) < 1
				begin
					-- Must be numeric
					select @alert_message = 'Container reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else if isnull( (select count(1) from billing_charge with (nolock) where linked_to_id = @con_id and linked_to_table = 'inbound' and isnull([disabled],0)=0) ,0) > 0
				and (@xproc <> 'admin-container-recreate-charges')
				begin
					-- for create charges cannot exit already
					select @alert_message = 'This container already has charges associated with it. Remove these first before re-calculating charges.'
				end
			else
				begin
					-- get status
					select @status=[status] from container with (nolock) 
						where container_id = @con_id
					-- if not yet submitted/completed
					if @status in ('','A')
						select @alert_message = 'This container is not submitted/completed. First set status to submitted/completed, current status is: ' + isnull(@status,'') 
					else
						begin
							-- if recreate pass RECREATE
							if @xproc = 'admin-container-recreate-charges'
								select @options_input = 'RECREATE'

							-- we now have valid container, call create charges
							-- for recreate pass in recreate option
							exec st_process_billing_charge @user_id,@settings,'X',@alert_message OUTPUT, 
								@run_type = 'inbound', @record_id = @con_id, @options = @options_input
							-- if ok
							if isnull(@alert_message,'') = ''
								begin
									-- set template
									select @alert_template = 'alert_message_html_success'
									select @alert_message = 'Calculated container charges.'
								end
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'
		end

	-- set charges
	else if @xproc in ('admin-order-create-charges','admin-order-recreate-charges')
		begin
			-- reset
			select @alert_message = ''
			select @alert_template = 'alert_message_html_danger'
			-- basket id
			select @basket_id = try_cast(@xdata as integer)
			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function. Admin access required.'
				end
			else if ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CHARGES','')+',') not like ('%,'+@alias+',%'))
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function. Please contact support.'
				end
			else if isnull(@basket_id,0) = 0
				begin
					-- Must be numeric
					select @alert_message = 'Order reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else if isnull( (select count(1) from billing_charge with (nolock) where linked_to_id = @con_id and linked_to_table = 'outbound' and isnull([disabled],0)=0) ,0) > 0
				and (@xproc <> 'admin-order-recreate-charges')
				begin
					-- Must be numeric
					select @alert_message = 'This order already has charges associated with it. Remove these first before re-calculating charges.'
				end
			else
				begin
					-- if recreate pass RECREATE
					if @xproc = 'admin-order-recreate-charges'
						select @options_input = 'RECREATE'

					-- get status
					select @status=[status] from basket with (nolock) 
						where basket_id = @basket_id
					-- if not yet completed
					if @status not in ('C','S')
						select @alert_message = 'This order is not completed. First set status to completed, status is: ' + isnull(@status,'') 
					else
						begin
							-- we now have valid basket, call create charges
							exec st_process_billing_charge @user_id,@settings,'X',@alert_message OUTPUT, 
								@run_type = 'outbound', @record_id = @basket_id, @options = @options_input
							-- if ok
							if isnull(@alert_message,'') = ''
								begin
									-- set template
									select @alert_template = 'alert_message_html_success'
									select @alert_message ='Calculated order charges.'
								end
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'
		end


	-- wv 2018-02-12  Create bank transfers
	else if @xproc ='bank-transfer-create'
		begin
			-- check if authorised
			select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_ACCOUNT_USERS','')
			-- if not 
			if (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%')
				begin
					-- log in audit
					select @audit_exception ='You are not authorised to create bank transfers.'
					exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-authorised', null, null, null, @audit_exception
					-- and alert
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 30000
				end
			else
				begin
					-- call processing
					exec [st_create_bank_transfers] @user_id, @settings, @sql_logging, @output_message, @brand, ''
				end

			-- wait 1 second so message gets picked up
			waitfor delay '00:00:01'

		end

	-- wv 2018-02-12  Create bank transfers
	else if @xproc ='rerun-cellar-load-matching'
		begin
			-- THIS MUST INCLUDE  confirmation before hand

			-- check access
			if @access not in ('A','M')
				begin
					select @audit_exception = 'Rerun cellar load matching is only allowed for admin users. Please contact support'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception
				end
			else if (select count(1) from cellar_load where cellar_load_id = try_parse(isnull(@xdata,0) as int)) = 0
				begin
					-- not a valid cellar load id
					select @audit_exception = 'Rerun matching. This is not a valid cellar load id: ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			else if (select process_status from cellar_load where cellar_load_id = cast(@xdata as int)) ='L'
				begin
					-- Already loaded 
					select @audit_exception = 'Rerun matching. This cellar is already loaded and cannot be rerun. Cellar id ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			else
				begin
					-- if here ok
					-- clear all matched wine names
					update wo_client_cellars 
						set matched_wine_name=''
					where isnull(matched,'') <> 'Y' and cellar_load_id = cast(@xdata as int)
					-- and update status to schedule matching
					update cellar_load
					set process_status = 'SM',updated_by = @user_id, updated = getdate()
						,processing_notes = isnull(processing_notes,'') + '<br />Re-running wine matching. Status set to SM.'
					where cellar_load_id = cast(@xdata as int)
					-- message
					select @audit_exception =  N'Wine name matching started in background. For files of 1000+ entries this can take several minutes.<br />
		To review the matching progress re-fresh the cellar load list.'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'info', null, null, null, @audit_exception				
				end

				-- always do alert
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 10000

				-- wait 1 second so message gets picked up
				waitfor delay '00:00:01'

		end

	-- wv 2018-02-12  Create bank transfers
	else if @xproc ='cellar-load-set-to-matched'
		begin
			-- THIS MUST INCLUDE confirmation before hand

			-- check access
			if @access not in ('A','M')
				begin
					select @audit_exception = 'Set all to matched is only allowed for admin users. Please contact support'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception
				end
			else if (select count(1) from cellar_load where cellar_load_id = try_parse(isnull(@xdata,0) as int)) = 0
				begin
					-- not a valid cellar load id
					select @audit_exception = 'Set all to matched. This is not a valid cellar load id: ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			else if (select COUNT(1) from wo_client_cellars where matched='Y' and cellar_load_id = cast(@xdata as int)) > 0
				begin
					-- Already loaded 
					select @audit_exception = 'Set all to matched. This cellar load is already been matched or partially matched and cannot be changed. Cellar load id ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			else
				begin
					-- if here ok
					-- clear all matched wine names
					update wo_client_cellars 
						set matched='Y',matched_by=null,matched_on_date=null  -- dont set matched by and on so we know it was defaulted like this.
					where cellar_load_id = cast(@xdata as int)
					-- message
					select @audit_exception =  N'Updated all entries to matched.'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'info', null, null, null, @audit_exception
				end

				-- always do alert
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 10000

				-- wait 1 second so message gets picked up
				waitfor delay '00:00:01'

		end

	-- wv 2018-02-12  Create bank transfers
	else if @xproc ='cellar-load-set-to-unmatched'
		begin
			-- THIS MUST INCLUDE confirmation before hand

			-- check access
			if @access not in ('A','M')
				begin
					select @audit_exception = 'Set all to un-matched is only allowed for admin users. Please contact support'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception
				end
			else if (select count(1) from cellar_load where cellar_load_id = try_parse(isnull(@xdata,0) as int)) = 0
				begin
					-- not a valid cellar load id
					select @audit_exception = 'Set all to unmatched. This is not a valid cellar load id: ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			else
				begin
					-- if here ok
					-- clear all matched wine names
					update wo_client_cellars 
						set matched='N',matched_by=null,matched_on_date=null  -- dont set matched by and on so we know it was defaulted like this.
					where cellar_load_id = cast(@xdata as int)
					-- message
					select @audit_exception =  N'Updated all entries to unmatched.'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'info', null, null, null, @audit_exception
				end

				-- always do alert
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 10000

				-- wait 1 second so message gets picked up
				waitfor delay '00:00:01'

		end


	-- wv 2018-02-12  Create bank transfers
	else if @xproc ='generate-ep-certificate'
		begin
			-- ONLY allowed if admin user
			if isnull(@access,'') <> 'A'
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(@xdata) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Wine order reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else
				begin
					-- check valid order and en-primeur entry
					declare @wo_status varchar(10)
					declare @ep_indicator varchar(10)
					declare @wo_id int = cast(@xdata as integer)
					-- get data
					select @wo_status = wo.order_status,@ep_indicator = we.en_primeur
						from wine_order wo with (nolock)
							join wine_entry we with (nolock) on wo.buyer_wine_entry_id = we.wine_entry_id 
					where wo.wine_order_id = @wo_id
					-- valid order, completed
					if isnull(@wo_status,'') <> 'C'
						select @alert_message = 'Order status is not completed for this order: ' + isnull(@xdata,'')
					else if isnull(@ep_indicator,'') <> 'Y' 
						select @alert_message = 'The buyer wine entry for this order is NOT an En Primeur: ' + isnull(@xdata,'')
					else
						begin
							-- we now have valid wine entry, kick off event to generate en primeur certificate
							---- Add events for this
							EXEC st_event @user_id,@settings,@sql_logging,@output_message OUTPUT
									,'EP_CERTIFICATE', @user_id, null, null
									,@wo_id, null, null, null
									,'wine_order_id',@wo_id,'order','dm_en_primeur'
	
								-- log in audit
							select @audit_exception ='Generated en primeur certificate for: ' + @xdata
							exec st_audit_hdr  @user_id, @settings, 'generate-en-primeur', @object_name, 'scheduled', null, @xdata, null, @audit_exception
	
							-- and message
							select @alert_message ='Scheduled event to generate en primeur certificate'
						end
				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000
		end

	-- wv 2018-02-12  Create bank transfers
	else if @xproc in ('disable-emails','reenable-emails')
		begin
			-- THIS MUST INCLUDE  confirmation prompt before hand  (set in content)
			-- check access
			if @access not in ('A')
				begin
					select @audit_exception = 'Disable emails is only allowed for admin users. Please contact support'
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception
				end
			else if (select count(1) from organisation where organisation_id = try_parse(isnull(@xdata,0) as int)) = 0
				begin
					-- not a valid organisation id
					select @audit_exception = 'Disable emails. This is not a valid organisation id: ' + isnull(@xdata,'')
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
				end
			-- not requiired
			--else if dbo.fnUserEmailList(try_parse(isnull(@xdata,0) as int),'-','')  like '%#disabled#%'
			--	begin
			--		-- Already disabled 
			--		select @audit_exception = 'Disable emails. The emails are already disabled for this user'
			--		-- and always record in audit trail
			--		exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @audit_exception				
			--	end

			else
				begin
					declare @disabled varchar(20) = '#disabled#'
					-- for disable
					if @xproc = 'disable-emails'
						begin
							-- if here ok, replace @ 
							update organisation set email = replace (email,'@',@disabled) 
							where organisation_id = cast(@xdata as int)
							-- and users
							update [user] set email = replace (email,'@',@disabled)
							where organisation_id = cast(@xdata as int)
							-- message
							select @audit_exception =  N'Disabled all organisation and user emails for this organisation: ' + @xdata
						end
					else
						begin
							-- if here ok, replace @ 
							update organisation set email = replace (email,@disabled,'@')
							where organisation_id = cast(@xdata as int)
							-- and users
							update [user] set email = replace (email,@disabled,'@') 
							where organisation_id = cast(@xdata as int)
							-- message
							select @audit_exception =  N'Re-enabled all organisation and user emails for this organisation: ' + @xdata

						end
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'info', null, null, null, @audit_exception				
				end

				-- always do alert
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @audit_exception, null, 10000

				-- wait 1 second so message gets picked up
				waitfor delay '00:00:01'

		end

	-- wv 2018-02-12  Wine actions -- initially for Oswalds but are generic
	else if @xproc in ('consume-wine', 'take-away-wine', 'put-back-wine', 'store-wine', 'change-cellar')
		begin
			-- get wine entry id
			declare @bar_wine_entry_id varchar(20) = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- and option of what to do (is qty for all options except store wine where it is the location ref)
			declare @qty_location varchar(20) = dbo.fnGetPiece(@xdata, 2, '~', '')
			-- get default cellar 1 and 2
			declare @default_cellar_name_1 varchar(50) = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_PROFESSIONAL_CELLAR_FOR_USER','Oswalds')
			declare @default_cellar_name_2 varchar(50) = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_PROFESSIONAL_CELLAR_FOR_USER_2','Pensbury')
			-- pv 14-02-2019 addewd third for sothebys
			declare @default_cellar_name_3 varchar(50) = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_PROFESSIONAL_CELLAR_FOR_USER_3','')
			-- alert message
			select @alert_message = ''

			-- ONLY allowed if merchant user
			if isnull(@access,'') not in ('M','A','W')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(@bar_wine_entry_id) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@bar_wine_entry_id,'')
				end

			else if @xproc in ('consume-wine', 'take-away-wine', 'put-back-wine', 'change-cellar') and isnumeric(@qty_location) <> 1 
				begin
					-- Qty must be numeric when moving wine
					select @alert_message = 'Qty must be > 0, value is: ' + isnull(@qty_location,'')
				end
			else if @xproc in ('consume-wine', 'take-away-wine', 'put-back-wine', 'change-cellar') and cast(@qty_location as int) <= 0 
				begin
					-- Qty must be greater than 0
					select @alert_message = 'Qty must be > 0, value is: ' + isnull(@qty_location,'')
				end
			else if @xproc in ('store-wine') and ltrim(isnull(@qty_location,'')) = '' 
				begin
					-- For storing location must be passed
					select @alert_message = 'When storing when you must scan the location reference.'
				end
			else if @xproc in ('consume-wine', 'take-away-wine', 'put-back-wine', 'change-cellar') and cast(@qty_location as int) <= 0 
				begin
					-- Qty must be greater than 0
					select @alert_message = 'Qty must be > 0, value is: ' + isnull(@qty_location,'')
				end

			-- if we dont have an error carry on
			if isnull(@alert_message,'') = ''
				begin

					-- first get basic wine entry details
					declare @current_cellar_id int
					declare @current_cellar_name varchar(50)
					declare @other_cellar_id int	-- other cellar (i.e. NOT this one but the other main one 
					declare @cellar_id_1 int		-- main cellar id
					declare @current_owner int
					declare @parent_id int
					declare @current_qty int
					declare @current_status varchar(50)
					-- retrieve
					select @current_cellar_id = we.cellar_id, @current_qty = we.no_bottles
						, @current_owner = c.owner_id, @current_status = we.[status]
						, @current_cellar_name = c.cellar_name, @parent_id = parent_id
						from wine_entry we with (nolock) 
						join cellar c with (nolock) on c.cellar_id = we.cellar_id
					where wine_entry_id = @bar_wine_entry_id

					-- get other cellar id (for this user)
					select top 1 @other_cellar_id = cellar_id 
						from cellar c with (nolock)
					where cellar_id <> @current_cellar_id and isnull([disabled],0) = 0 and cellar_type = 'P'
						and c.owner_id = @current_owner 
						and (cellar_name = @default_cellar_name_1 or cellar_name = @default_cellar_name_2 or cellar_name = @default_cellar_name_3)
					-- and get main cellar id
					select @cellar_id_1 = c.cellar_id from cellar c with (nolock)
					where c.owner_id = @current_owner 
						and isnull(c.[disabled],0) = 0 and c.cellar_type = 'P'
						and c.cellar_name = @default_cellar_name_1


					-- get qty consumed

					-- get cellar to allow consumed from
					declare @consume_cellar varchar(50) = dbo.fnGetParameter(@user_id,@settings,'CONSUME_CELLAR_NAME_STARTING_WITH','')

					-- now check there are enough bottles to be moved
					if (select count(1) from wine_entry with (nolock) where wine_entry_id = @bar_wine_entry_id) = 0 
						begin
							-- Not a valid wine entry
							select @alert_message = 'This is not a valid wine entry id, value is: ' + isnull(@bar_wine_entry_id,'')
						end
					else if @xproc in ('consume-wine', 'take-away-wine', 'change-cellar', 'put-back-wine') and isnull(@current_qty,0) < @qty_location
						begin
							-- can not move more than what is available
							select @alert_message = 'Current qty. available is not enough, requested qty: ' + cast(@qty_location as varchar(10)) + ', available qty: ' + cast(@current_qty as varchar(10))
						end
					else if @xproc = ('consume-wine') and isnull(@current_cellar_name,'') not like @consume_cellar +'%'
						begin
							-- can not consume from this cellar
							select @alert_message = 'You can not consume wine stored at this location. The stored location is: ' + isnull(@current_cellar_name,'') + ', allowed location for consuming wine is: ' + isnull(@consume_cellar,'')
						end
					else if lower(@current_status) not in ('active','consumed') and @current_status not like 'disposed%'
						begin
							-- Not a valid wine entry status
							select @alert_message = 'This is not a valid wine entry status, the status is: ' + isnull(@current_status,'')
						end

					-- check there are enough consumed bottles to be put back.
					-- this is a bit tricky !!!
					--else @xproc = 'put-back-wine'
					--	begin
						
					--	end
					else
						begin
							-- separate fields
							declare @w_msg varchar(500)
							declare @w_type varchar(50)
							declare @new_we_id int = @bar_wine_entry_id
							-- now do processing, separated for each action
							if @xproc = 'consume-wine'
								begin
									-- call wine move function
									EXEC st_update_wine_entry_move  @user_id, @settings, 'X', @w_msg OUTPUT 
										,@w_type OUTPUT, @new_we_id OUTPUT, @stamp = null 
										,@options = 'NOALERTMESSAGE'    -- Consume~~Consumed in the club',		--@options varchar(50),            -- generic purposes		
										,@move_type = 'Consume'     -- move type
										,@quantity = @qty_location  -- number of bottles to be moved
										,@notes = ''
									-- output and errors handled below
								end
							else if @xproc = 'take-away-wine'
								begin
									-- call wine move function
									EXEC st_update_wine_entry_move  @user_id, @settings, 'X', @w_msg OUTPUT 
										,@w_type OUTPUT, @new_we_id OUTPUT, @stamp = null 
										,@options = 'NOALERTMESSAGE'    -- Consume~~Consumed in the club',		--@options varchar(50),            -- generic purposes		
										,@move_type = 'Dispose'     -- move type
										,@quantity = @qty_location  -- number of bottles to be moved
										,@disposal_notes = 'Taken away'
										,@wine_status = 'DisposedOther'
									-- output and errors handled below							
								end
							else if @xproc = 'put-back-wine'
								begin
									-- wv 2019-06-16  Check if we have active wine entry, stored AT oswalds !!
									--  where we can just add the qty to again

									-- get parent id of this wine entry barcode of this wine (we are putting back)
									-- and wine id, and vintage, and bottle size and condition
									declare @parent_we_id int = 0
									declare @current_no_bottles int = 0
									select top 1 @parent_we_id=pwe.wine_entry_id, @current_no_bottles = pwe.no_bottles
									from wine_entry we
										join user_defined_field udf_we on udf_we.table_name ='wine-entry' and udf_we.record_id=we.wine_entry_id
										join wine_entry pwe with (nolock) on we.wine_id = pwe.wine_id and we.vintage = pwe.vintage
											and we.bottle_size_ref = pwe.bottle_size_ref
										join user_defined_field udf_pwe on udf_pwe.table_name ='wine-entry' and udf_pwe.record_id=pwe.wine_entry_id
											and udf_pwe.value_9 = udf_we.value_9
									where we.wine_entry_id = @bar_wine_entry_id
										and pwe.[status] = 'active'
										and isnull(pwe.[disabled],0)=0
										and pwe.cellar_id=@cellar_id_1  -- @cellar_id_1 is the main cellar like Oswalds
										-- must have some bottles
										and pwe.no_bottles > 0
									-- order in reverse qty order
									order by pwe.no_bottles desc

									-- support
									select @audit_exception = 'Put away processing for WE: ' + isnull(cast(@bar_wine_entry_id as varchar(10)),'') + ', parent WE id: ' + isnull(cast(@parent_we_id as varchar(10)),'') + ', current bottles in parent we: ' + isnull(cast(@current_no_bottles as varchar(10)),'')
									exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'info', null, @parent_we_id, null, @audit_exception

									-- if we found an entry then update this
									if isnull(@parent_we_id,0) > 0
										begin
											-- update qty
											declare @new_qty_bottles int = @current_no_bottles + @qty_location
											-- if we have a wine entry then update this with the new qty
											EXEC st_update_wine_entry  @user_id, @settings, 'X', @w_msg OUTPUT
												,@w_type OUTPUT, @parent_we_id, @stamp = null 
												,@options = 'NOALERTMESSAGE'		
												,@no_bottles = @new_qty_bottles
												-- we only update qty
												--,@status = 'Active'
												--,@cellar_id = @cellar_id_1
												--,@notes = 'wine was consumed but put back'

											-- and deduct from consumed qty if update ok
											if isnull(@w_msg,'') =''
												begin
													update wine_entry
														set no_bottles = no_bottles - @qty_location
															,disposal_notes= disposal_notes + char(13) + char(10) + 'put back ' + cast(@qty_location as varchar(10)) + ' bottles to main cellar'
															-- if nothing left disable this 
															,[disabled] = case when @current_qty = @qty_location then 1 else 0 end
													where wine_entry_id = @bar_wine_entry_id
												end

										end

									-- else do what we did before
									-- if qty of this entry IS 1 just change cellar and status
									else if @current_qty = @qty_location
										begin
											-- get the cellar id to move this entry to
											-- at the moment always cellar 1  (Oswalds)
											-- and update
											EXEC st_update_wine_entry  @user_id, @settings, 'X', @w_msg OUTPUT
												,@w_type OUTPUT, @bar_wine_entry_id OUTPUT, @stamp = null 
												,@options = 'NOALERTMESSAGE'		
												--,@no_bottles = @current_parent_qty stays the same
												,@status = 'Active'
												,@cellar_id = @cellar_id_1
												,@notes = 'wine was consumed but put back'
										end
									else
										begin
											
											-- put back qty  (this is always 1 at the moment because we dont know how many there are)
											-- use transfer  so it also copies the UDF record
											declare @tmp_notes_1 varchar(200) = 'Moved back from consumed' + cast(@qty_location as varchar(10)) + ' bottle(s) to main cellar'
											-- Move from consumed to main cellar (Oswalds)
											EXEC st_update_wine_entry_transfer  @user_id, @settings, 'X', @w_msg OUTPUT, 
												@w_type OUTPUT, @new_we_id OUTPUT, @stamp = null
												,@options = 'OVERWRITESELFMANAGED~NOALERTMESSAGE~NOTRANSACTION'	-- not sure we need this 'OVERWRITESELFMANAGED'
												,@quantity = @qty_location
												,@cellar_id = @cellar_id_1
												,@additional_notes = @tmp_notes_1
												,@status_overwrite ='Active'
										end

								end
							else if @xproc = 'store-wine'
								begin
									-- call wine entry update function
									EXEC st_update_wine_entry  @user_id, @settings, 'X', @w_msg OUTPUT, 
										@w_type OUTPUT, @new_we_id OUTPUT, @stamp = null
										,@options = 'NOALERTMESSAGE'		
										,@cellar_ref = @qty_location
								end
							else if @xproc = 'change-cellar'
								begin
									declare @tmp_notes_2 varchar(200) = 'Moved ' + cast(@qty_location as varchar(10)) + ' bottle(s) to other cellar'
									-- Move from pensbury to Oswalds or Oswalds to Pensbury
									EXEC st_update_wine_entry_transfer  @user_id, @settings, 'X', @w_msg OUTPUT, 
										@w_type OUTPUT, @new_we_id OUTPUT, @stamp = null
										,@options = 'OVERWRITESELFMANAGED~NOALERTMESSAGE~NOTRANSACTION'	-- not sure we need this 'OVERWRITESELFMANAGED'
										,@quantity = @qty_location
										,@cellar_id = @other_cellar_id
										,@additional_notes = @tmp_notes_2
										,@cellar_ref = ''		-- when moving blank out cellar ref because it wont apply to the new location
								end
	
							-- log in audit
							select @audit_exception ='Action: ' + @xproc + ', for: ' + isnull(@xdata,'')
							-- if an error
							if @w_type = 'E' or isnull(@w_msg,'') <> ''
								begin
									-- set error mesg
									select @audit_exception = 'An error occured in: ' + @audit_exception + char(13) + char(10) + @w_msg
									exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'error', null, @new_we_id, null, @audit_exception
									-- and message
									select @alert_message = @audit_exception
								end
							else
								begin
									exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'completed', null, @new_we_id, null, @audit_exception
									-- nothing here select @alert_message = @audit_exception
								end

						end

				end

			-- if message then display
			if isnull(@alert_message,'') <> ''
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, 'alert_message_html_warning'
		end

	-- wv 2018-02-12  Wine actions -- initially for Oswalds but are generic
	else if @xproc in ('cellar-load-clear')
		begin
			-- just clear selected entries for this user
			delete from select_table where select_mode='cellar_load_entries' and user_id = @user_id
			declare @del_count int = @@rowcount
			-- log
			select @audit_exception = ' Cleared selected entries for cellar match: ' + cast(@del_count as varchar(10))
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'clear-completed', null, @xdata, null, @audit_exception
		end

	else if @xproc in ('cellar-load-match')
		begin
			-- just set entries to matched
			update wcc
				set wcc.matched='Y',wcc.matched_by=@user_id,wcc.matched_on_date = getdate()
			from wo_client_cellars wcc
				join select_table st on st.record_id = wcc.ID and st.user_id = @user_id and select_mode='cellar_load_entries'
			where st.user_id = @user_id and select_mode='cellar_load_entries'
			-- dont have load id cellar_load_id=@xdata
			declare @match_count int = @@rowcount
			-- and clear selection
			delete from select_table where select_mode='cellar_load_entries' and user_id = @user_id
			-- log in audit trail
			select @audit_exception = ' Set entries to matched for cellar load, updated total: ' + cast(@match_count as varchar(10))
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'completed', null, @xdata, null, @audit_exception
		end

	else if @xproc in ('cellar-load-unmatch')
		begin
			-- just set entries to unmatched
			update wcc
				set wcc.matched='N',wcc.matched_by=null,wcc.matched_on_date = null
			from wo_client_cellars wcc
				join select_table st on st.record_id = wcc.ID and st.user_id = @user_id and select_mode='cellar_load_entries'
			where st.user_id = @user_id and select_mode='cellar_load_entries'
				and wcc.matched='Y'
			-- dont have load id cellar_load_id=@xdata
			declare @unmatch_count int = @@rowcount
			-- and clear selection
			delete from select_table where select_mode='cellar_load_entries' and user_id = @user_id
			-- log in audit trail
			select @audit_exception = ' Set entries to un-matched for cellar load, updated total: ' + cast(@unmatch_count as varchar(10))
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'completed', null, @xdata, null, @audit_exception
		end

	-- wv 2018-08-29  approve basket for delivery  (could do credit check ??)
	else if @xproc='admin-basket-approve' and ISNUMERIC(@xdata) = 1 and @access in ('W','A','M')
		begin
			-- check if we have an active basket with status A for submitted
			-- check if we got a valid basket
			declare @basket_org_name varchar(100)
			select @basket_status = [status],@basket_org_id = u.organisation_id
				, @basket_type = b.basket_type, @basket_org_name = o.name
				from basket b with (nolock)
					join [user] u with (nolock) on b.user_id = u.user_id
					join [organisation] o on u.organisation_id = o.organisation_id
			where basket_id = try_cast(@xdata as integer)

			-- if not status A
			if isnull(@basket_status,'') = ''
					select @alert_message = 'This is not a valid basket id, id is: ' + isnull(@xdata,'')
			else if isnull(@basket_status,'') <> 'A'
					select @alert_message = 'The basket status is not valid, status should be Submitted (A) but status is: ' + @basket_status

			-- else ok, set to approved
			else
				begin
					-- basket id
					select @basket_id = cast(@xdata as int)
					-- open basket status
					update basket
						set [status]='C',updated=getdate(),updated_by=@user_id
					where basket_id = @basket_id and [status]='A'
					-- 
				end

			-- if no error
			if isnull(@alert_message,'') = ''
				begin
					-- if no errors
					select @alert_template = 'alert_message_html_success'
					select @alert_message = 'This basket is now approved for delivery.<br><br>To ship these wines <a href="/picking-list.aspx?reset=Y&amp;organisation={org_name}({org_id})&amp;rt=/basket-admin-list.aspx">click here</a>.'
					-- and replace
					select @alert_message = replace(
									        replace(@alert_message,'{org_name}',isnull(@basket_org_name,''))
												,'{org_id}',cast(@basket_org_id as varchar(10)))
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 60000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'approved-basket', @object_name, 'completed', null, @basket_id, null, @alert_message			
		end


	-- wv 2018-08-29  reset basket to pending
	-- when submitted basket system will move wine OUT of the current cellar.
	else if @xproc='admin-basket-reset-pending' and ISNUMERIC(@xdata) = 1 and @access in ('W','A','M')
		begin
			-- check if we have an active basket with status A for submitted
			-- check if we got a valid basket
			select @basket_status = [status], @basket_id = b.basket_id 
				from basket b with (nolock)
			where basket_id = cast(@xdata as integer)
			-- if not status status A=submitted or C-approved cannor reset  
			if isnull(@basket_status,'') = ''

				select @alert_message = 'This is not a valid basket id, id is: ' + isnull(@xdata,'')
			else if isnull(@basket_status,'') not in ('A','C')
				select @alert_message = 'The basket status is not valid, you can only reset if status is A, submitted or C, approved. Status is: ' + @basket_status
			else
				begin
					-- check if we have active basket 
					select @alert_message = ''
					-- get basket ORG ID
					select @basket_org_id = u.organisation_id, @basket_type = b.basket_type
						from basket b with (nolock)
							join [user] u with (nolock) on b.user_id = u.user_id
						where basket_id = @xdata

					-- check if we got already an open basket for anybody for this organisation
					select @basket_count=COUNT(1) 
						from basket b with (nolock)
							join [user] u with (nolock) on u.user_id = b.user_id
					where basket_type=@basket_type and b.[status]='B' and u.organisation_id = @basket_org_id 

					-- check
					if isnull(@basket_count,0) > 0
						begin
							select @alert_message = 'Basket cannot be re-opened. There is already an active basket in use. Please first close or clear the open basket and try to re-open again.' 
						end
					else
						begin
							-- open basket processing
							exec st_process_basket 
								@user_id, @settings, @sql_logging, @output_message=@output_message output, 
								@status='B', @basket_type='CALLOFF',
								@address_id=null, 
								@submit_notes= null,
								@incoming_basket_id = @basket_id
							-- if we had an error
							if isnull(@output_message ,'') <> ''
								select @alert_message = @output_message
						end
					-- if errors
					if isnull(@alert_message,'') = ''
						select @alert_message = 'Basket re-opened. Quantities have been set back.'
					-- and give message
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'reopen-basket', @object_name, 'info', null, @basket_id, null, @alert_message
				end
		end
		
	-- mb 2018-09-18  clear wine-move-list selection
	else if @xproc in ('wine-move-clear-selection')
		begin
			-- just clear selected entries for this user
			delete from select_table where select_mode='wine_entry_move' and user_id = @user_id
			declare @move_del_count int = @@rowcount
			-- log
			select @audit_exception = ' Cleared selected entries for wine move: ' + cast(@move_del_count as varchar(10))
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'clear-completed', null, @xdata, null, @audit_exception
		end


	-- wv 2018-09-20  Update billing charge overwrite
	else if @xproc in ('charge-overwrite-update')
		begin
			-- testing only
			-- exec st_audit_hdr  @user_id, @settings, @xproc, 'dm_m_proc', 'info', null, @xdata, null, @input_fields
			-- check we have org, charge type  value and notes
			declare @ch_org_id varchar(50) =  dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @ch_type varchar(50) =  dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @ch_value varchar(50) =  dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @ch_expiry varchar(50) =  dbo.fnGetPiece(@xdata, 4, '~', '')
			declare @ch_notes varchar(500) =  left(dbo.fnEscapeURL(dbo.fnGetPiece(@xdata, 5, '~', ''),'R'),500)
			-- pv 2019-03-29 added category for multiple locations (Sotheby's)
			declare @ch_category varchar(500) =  dbo.fnGetPiece(@xdata, 6, '~', '')
			select @alert_template = 'alert_message_html_danger'

			-- default category if not passed
			if isnull(@ch_category,'') = '' 
				select @ch_category ='ChargeType'

			-- get brand for this org
			-- this may fail
			declare @ch_org_brand varchar(10)
			select @ch_org_brand = brand_ref from organisation o with (nolock) where organisation_id = try_cast(@ch_org_id as int)

			-- validate
			if isnull(@ch_org_id,0) = 0 or isnumeric(@ch_org_id) <> 1
				select @alert_message = 'This is not a valid organisation id number, id is: ' + isnull(@ch_org_id,'') 
			else if @ch_category not like 'ChargeType%'
				select @alert_message = 'This is not a valid charge category, category passed: ' + isnull(@ch_category,'') 
			else if (select count(1) from organisation o with (nolock) where organisation_id = try_cast(@ch_org_id as int)) = 0
				select @alert_message = 'This is not a valid organisation id, id is: ' + isnull(@ch_org_id,'') 
			else if isnull(@ch_type,'') = ''
				select @alert_message = 'Please select a charge type. Use <space><space> to see all types' 
			else if (select count(1) from [lookup] with (nolock) where category = @ch_category and reference = @ch_type and brand_ref = @ch_org_brand) = 0
				select @alert_message = 'This is not a valid charge type, type is: ' + isnull(@ch_type,'') 
			else if isnull(@ch_value,'') <> '' and isnumeric(@ch_value) <> 1
				select @alert_message = 'This is not a valid overwrite value: ' + isnull(@ch_value,'')
			else if isnull(@ch_expiry,'') <> '' and try_cast(@ch_expiry as date) is null
				select @alert_message = 'This is not a valid expiry date (leave blank for no expiry date): ' + isnull(@ch_expiry,'')
			else
				begin
					-- use standard update BUT no alert
					declare @ch_options varchar(100) = 'NOALERTMESSAGE'
					-- make sure date is null
					select @ch_expiry = case when @ch_expiry = '' then null else @ch_expiry end
					-- get ID if it exist
					declare @ch_id int = null
					select top 1 @ch_id = billing_charge_overwrite_id 
					from billing_charge_overwrite with (nolock)
						where organisation_id = @ch_org_id 
							and charge_type = @ch_type 
							and (category = @ch_category or (@ch_category='ChargeType' and isnull(category,'')=''))
							and isnull([disabled],0)=0
					-- if blanked out (removed), add option delete and set value to 999 so its a value number
					-- but dont set to 0 because if that gets used it could cost TWC lots of money !
					if @ch_value= ''
						select @ch_options = @ch_options + '~delete',@ch_value=-99
					-- call standard update (which will create another audit entry)
					-- return alert message
					EXEC st_update_billing_charge_overwrite @user_id, @settings, @sql_logging, @alert_message OUTPUT,
						@output_type OUTPUT,
						@ch_id OUTPUT,
						0,			        --@stamp int,			-- record update stamp  - optional passed in for updates
						@options = @ch_options,	-- varchar(50),     -- generic purposes
						-- input parameters
						@organisation_id = @ch_org_id,
						@charge_type = @ch_type,
						@overwrite_value = @ch_value,
						@expiry_date = @ch_expiry,
						@notes = @ch_notes,
						@category = @ch_category

				end

			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					if @ch_options like '%delete%'
						select @alert_message = 'Removed overwrite charge ' + @ch_type + ', for organisation id ' + @ch_org_id, @audit_action='delete'
					else
						begin
							select @alert_message = 'Updated overwrite charge ' + @ch_type + ', for organisation id ' + @ch_org_id +', new value: ' + @ch_value
								+ case when @ch_expiry is null then '' else ', expiry date set to: ' + dbo.fnDateTimeFormat(@user_id,@settings,@ch_expiry, 'dd/mm/yyyy','','','') end
							-- check default value is more than overwrite
							if try_cast(@ch_value as decimal(18,2)) > try_cast((select lookup_field_1 from [lookup] o with (nolock) where category = @ch_category and reference = @ch_type and brand_ref = @ch_org_brand) as decimal(18,2))
								select @alert_message = @alert_message + '<br><br>WARNING: your custom value is greater than the default value for this charge type'
									,@alert_template = 'alert_message_html_warning'
						end
				end
			else
				begin
					-- we have an error
					select @audit_action = 'Error'

				end

			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'billing-charge-update', @object_name, @audit_action, null, @ch_id, null, @alert_message
		end


	-- wv 2018-09-23  Update billing charge
	else if @xproc in ('charge-update')
		begin
			-- always log start of update
			exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields

			-- check we have org, charge type  value and notes
			declare @bch_id varchar(50) =  dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @bch_quantity varchar(50) =  dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @bch_unit_amount varchar(50) =  dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @bch_notes varchar(500) =  left(dbo.fnEscapeURL(dbo.fnGetPiece(@xdata, 4, '~', ''),'R'),500)
			-- get data
			declare @bch_table_id int
			declare @bch_invoiced varchar(10)
			declare @bch_brand varchar(10)
			declare @bch_description varchar(100) 
			declare @bch_org_id int
			declare @default_charge_amount decimal(18,2)
			declare @update_action varchar(10) = ''
			-- get data
			select top 1 @bch_table_id = bc.billing_charge_id
				,@bch_invoiced = bc.invoiced_yes_no
				,@bch_brand = o.brand_ref
				,@bch_description = charge_description
				,@bch_org_id = bc.organisation_id
				,@default_charge_amount = bc.default_charge_amount
			 from billing_charge bc with (nolock)
				join organisation o with (nolock) on o.organisation_id = bc.organisation_id
				where billing_charge_id = try_cast(@bch_id as int)
			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- check if this user is allowed
			if @access not in ('W','A','M') or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CHARGES','')+',') not like ('%,'+@alias+',%'))
				select @alert_message =  'You are not allowed to edit billing charges - please contact support.'
			-- check billing id
			else if isnull(@bch_id,'') = ''
				select @alert_message = 'Please select a valid charge type' 
			-- if it does not exist
			else if isnull(@bch_table_id,0) = 0
				select @alert_message = 'This is not a valid billing charge id, id is: ' + isnull(@bch_id,'')
			-- If already invoiced
			else if isnull(@bch_invoiced,'') = 'Y'
				select @alert_message = 'This charge is already invoiced and cannot be changed, id is: ' + isnull(@bch_id,'') 
			else if isnull(@bch_unit_amount,'') <> '' and try_cast(@bch_unit_amount as decimal(18,2)) is null
				select @alert_message = 'This is not a valid unit charge amount: ' + isnull(@bch_unit_amount,'')
			else if isnull(@bch_quantity,'') <> '' and isnumeric(@bch_quantity) <> 1
				select @alert_message = 'This is not a valid quantity: ' + isnull(@bch_quantity,'')
			else if (isnull(@bch_quantity,'') = '' or isnull(@bch_unit_amount,'') = '') and(isnull(@bch_quantity,'') <> '' or isnull(@bch_unit_amount,'') <> '')
				select @alert_message = 'Please enter a valid QUANTITY or AMOUNT'
			else if (isnull(@bch_quantity,'') = '' or isnull(@bch_unit_amount,'') = '') and isnull(@bch_notes,'') <> ''
				select @alert_message = 'Please enter a valid QUANTITY and AMOUNT or delete the notes to delete the entry'
			else
				begin
					-- use standard update BUT no alert
					declare @bch_options varchar(100) = 'NOALERTMESSAGE'

					-- if all fields are blanked out then remove this charge
					if @bch_quantity='' and @bch_unit_amount = '' and @bch_notes = ''
						begin
							-- now remove the charge
							select @bch_options = @bch_options +'~DELETE~',@update_action='D'

							-- call standard update (which will create another audit entry)
							EXEC st_update_billing_charge @user_id, @settings, @sql_logging, @alert_message OUTPUT,
								@output_type OUTPUT,
								@bch_id OUTPUT,
								0,							--@stamp int,					-- record update stamp  - optional passed in for updates
								@options = @bch_options		-- varchar(50),         -- generic purposes
								-- no input parameters for delete except the id above
						end
					else
						begin
							select @update_action='U'
							-- always update overwrite charge amount (even if it is the same, because it as now set specifically)
							-- and update quantity (could be 0)
							-- if blanked out (removed), set to 0
							if isnull(@bch_unit_amount,'') = ''
								select @bch_unit_amount=0
							-- quantity set to 1
							if @bch_quantity = ''
								select @bch_quantity = 1
							-- and calculate total amount
							declare @bch_total decimal(18,2) = try_cast(isnull(@bch_quantity,0) as decimal(18,2)) * try_cast(isnull(@bch_unit_amount,0) as decimal(18,2))
							-- if > 0 and amount the same as the default charge set to null
							-- so we keep using default amount (set to null number)
							if try_cast(@bch_unit_amount as decimal(18,2)) > 0 and try_cast(@bch_unit_amount as decimal(18,2)) = try_cast(@default_charge_amount as decimal(18,2))
								select @bch_unit_amount = -654321

							-- call standard update (which will create another audit entry)
							EXEC st_update_billing_charge @user_id, @settings, @sql_logging, @alert_message OUTPUT,
								@output_type OUTPUT,
								@bch_id OUTPUT,
								0,							--@stamp int,					-- record update stamp  - optional passed in for updates
								@options = @bch_options,	-- varchar(50),         -- generic purposes
								-- input parameters
								@overwrite_charge_amount = @bch_unit_amount,
								@quantity = @bch_quantity,
								@total_charge = @bch_total,
								@notes = @bch_notes
					end
				end

			-- if no errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if action D  for delete
					if @update_action='D'
						select @alert_message = 'Deleted charge ' + isnull(@bch_description,'') + ', for organisation id ' + cast(@bch_org_id as varchar(10)) 
					else
						select @alert_message = 'Updated charge ' + isnull(@bch_description,'') + ', for organisation id ' + cast(@bch_org_id as varchar(10)) +', new value: ' + cast(@bch_total as varchar(10))
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message,@audit_action='error'
				end

			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'billing-charge-update', @object_name, @audit_action, null, null, null, @alert_message
		end


	-- set invoices as invoiced for one month and brand
	else if @xproc in ('billing_charge_set_as_invoiced','billing_charge_uninvoice')
		begin
			-- default template
			select @alert_template = 'alert_message_html_danger'
			-- check access
			if @access not in ('W','A','M') or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CHARGES','')+',') not like ('%,'+@alias+',%'))
				select @alert_message =  'You are not allowed to edit billing charges - please contact support.'
			else
				begin
					-- check we have org, charge type  value and notes
					declare @set_year int = cast(left(@xdata,4) as integer)
					declare @set_month int = cast(right(@xdata,2) as integer)

					-- and update
					if @xproc = 'billing_charge_uninvoice' 
						begin
							update bc
								set bc.invoiced_yes_no = 'N',updated = getdate(), updated_by = @user_id,invoice_number = ''
							from billing_charge bc
								join [organisation] o with (nolock) on bc.organisation_id = o.organisation_id
							where -- only enabled entries
								isnull(bc.[disabled],0) = 0
								-- and only this brand
								and o.brand_ref = @brand
								-- and the selected month
								and year(billing_date) = @set_year and month(billing_date) = @set_month
								-- and set to invoiced
								and bc.invoiced_yes_no = 'Y'
						end
					else
						begin
							update bc
								set bc.invoiced_yes_no = 'Y',updated = getdate(), updated_by = @user_id
							from billing_charge bc
								join [organisation] o with (nolock) on bc.organisation_id = o.organisation_id
							where -- only enabled entries
								isnull(bc.[disabled],0) = 0
								-- and only this brand
								and o.brand_ref = @brand
								-- and the selected month
								and year(billing_date) = @set_year and month(billing_date) = @set_month
								-- just whole month to invoiced, but only entries which are not already set
								and isnull(bc.invoiced_yes_no,'') <> 'Y'
						end

					-- count 
					select @count = @@rowcount
					select @alert_template = 'alert_message_html_success'
					-- and audit trail
					if @xproc = 'billing_charge_uninvoice'
						-- if value blank its remove
						select @alert_message = 'Updated month ' + isnull(@xdata,'??') + ' to un-invoiced. Updated total of ' + cast(@count as varchar(10)) + ' records.'
					else
						select @alert_message = 'Updated month ' + isnull(@xdata,'??') + ' to invoiced. Updated total of ' + cast(@count as varchar(10)) + ' records.'
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'billing-charge-invoiced', @object_name, 'info', null, null, null, @alert_message

		end


	-- wv 2018-09-23  Update billing charge
	else if @xproc in ('charge-insert')
		begin
			-- always log start of update
			exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields

			-- check we have org, charge type  value and notes
			declare @ich_org_id varchar(50) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @ich_type_description varchar(50) =  dbo.fnEscapeURL(dbo.fnGetPiece(@xdata, 2, '~', ''),'R')
			declare @ich_quantity varchar(50) =  dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @ich_unit_amount varchar(50) =  dbo.fnGetPiece(@xdata, 4, '~', '')
			declare @ich_linked_type varchar(50) =  dbo.fnGetPiece(@xdata, 5, '~', '')
			declare @ich_linked_id varchar(50) =  dbo.fnGetPiece(@xdata, 6, '~', '')
			declare @ich_date date =  try_cast(ltrim(dbo.fnGetPiece(@xdata, 7, '~', '')) as date) -- if invalid its null
			declare @ich_notes varchar(500) =  left(dbo.fnEscapeURL(dbo.fnGetPiece(@xdata, 8, '~', ''),'R'),500)
			-- wv 2019-04-09 Added correct charge type here
			declare @ich_category varchar(500) =  dbo.fnGetPiece(@xdata, 9, '~', '')
			-- default category if not passed
			if isnull(@ich_category,'') = '' 
				select @ich_category ='ChargeType'

			-- if id container () then retrieve id from 
			if @ich_org_id like '%(%)'
				select @ich_org_id = dbo.fnGetOrgIDFromString(@ich_org_id)
			-- other
			declare @ich_table_id int
			declare @ich_id int
			declare @ich_org_id_int int = try_cast(@ich_org_id as int)
			declare @ich_out varchar(500) = ''
			declare @ich_type varchar(100)= ''
			declare @ich_default_unit_price decimal(18,2)
			declare @ich_total_amount decimal(18,2)

			-- strip amount from description ( - )
			select @ich_type_description = dbo.fnGetPiece(@ich_type_description,1,' - ','')
			-- get lookup brand for charge type
			select @lookup_brand = dbo.fnGetLookupBrand(@user_id,@settings,@ich_category)
			declare @taxes int = 0
			declare @ib_taxes int = 0
			select top 1 @taxes = count(*) from billing_charge with (nolock) where organisation_id = @ich_org_id and linked_to_table = @ich_linked_type and linked_to_id = @ich_linked_id and charge_type = 'tax'
			select top 1 @ib_taxes = count(*) from billing_charge with (nolock) where organisation_id = @ich_org_id and linked_to_table = @ich_linked_type and linked_to_id = @ich_linked_id and charge_type = 'ib-tax'
			if isnull(@ich_quantity,'') = 'tax' and isnull(@ich_unit_amount,'') = 'tax' and isnull(@ich_type_description,'') = 'tax'
				begin
					 if @taxes = 0
						select @ich_quantity = cast(cast(lc.lookup_field_1 as decimal(18,2))/100 as varchar(20))
							,@ich_unit_amount = cast(sum(bc.total_charge) as varchar(20))
						from organisation o with (nolock)
							join billing_charge bc with (nolock) on o.organisation_id = bc.organisation_id and bc.linked_to_table = @ich_linked_type and bc.linked_to_id = @ich_linked_id and bc.charge_type <> 'tax'
							join [lookup] lc with (nolock) on lc.brand_ref = o.brand_ref collate database_default and lc.category = @ich_category collate database_default and lc.reference = @ich_type_description collate database_default
						where o.organisation_id = @ich_org_id
						group by lc.lookup_field_1					
				end
			-- pv 2019-07-05 added taxes to ib bottles
			if isnull(@ich_quantity,'') = 'ib-tax' and isnull(@ich_unit_amount,'') = 'ib-tax' and isnull(@ich_type_description,'') = 'ib-tax' and @ib_taxes =0
				begin
					select @currency = dbo.fnGetPiece(lookup_field_1, 1, '~', '')
					from [lookup] with (nolock)
					where lookup_field_2 = @ich_category
					select @ich_quantity = '1'

					select @ich_unit_amount = sum(
						dbo.fnGetDutyVAT(@user_id,@settings, w.wine_sub_type, we.bottle_size_ref, 1
							, (isnull(bi.quantity_cases,0) * we.case_size_ref) + isnull(bi.quantity_bottles,0)
							, dbo.fnBottlePrice(@user_id,@settings,null
									,we.price
									,dbo.fnGetWinePrice(we.wine_id,we.vintage,@currency,-1,@region,'Y')
									,null)
								* ((isnull(bi.quantity_cases,0) * we.case_size_ref) + isnull(bi.quantity_bottles,0))
							)
						)		
					from wine_entry we
					join wine w on w.wine_id = we.wine_id
					join basket_item bi on bi.wine_entry_id = we.wine_entry_id
					where bi.basket_id = @ich_linked_id			
				end

			-- get charge id, and at same time the default unit cost
			-- this could be an overwrite from billing overwrite !!
			select top 1 @ich_table_id = lct.lookup_id, @ich_type = reference
				,@ich_default_unit_price = case when bco.overwrite_value is not null then isnull(bco.overwrite_value,0.00)
					else try_cast(lct.lookup_field_1 as decimal(18,2)) end
			from lookup lct with (nolock)
				left join [billing_charge_overwrite] bco with (nolock) on lct.reference = bco.charge_type collate database_default
					and bco.organisation_id = @ich_org_id_int
					and (bco.[expiry_date] is null or bco.[expiry_date] >= cast(isnull(@ich_date,getdate()) as date))
			where 
				lct.category = @ich_category
				and lct.brand_ref= @lookup_brand
				and dbo.fnXMLTextDisplay(lct.[description],99,0,'en') = @ich_type_description
				and isnull(lct.[disabled],0) = 0

			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- check if this user is allowed
			if @taxes <> 0 and isnull(@ich_type_description,'') = 'tax'
				select @alert_message =  'You have already added taxes. If you want to recalculate delete the existing charge before adding it again'
			else if @ib_taxes <> 0 and isnull(@ich_type_description,'') = 'ib-tax'
				select @alert_message =  'You have already added taxes for your in bond bottles. If you want to recalculate delete the existing charge before adding it again'
			else if @access not in ('W','A','M')
				select @alert_message =  'You are not allowed to insert billing charges - please contact support.'
			else if isnull(@ich_type_description,'') = ''
				select @alert_message = 'Please select a valid charge type. Enter <space><space> or type ALL to list all valid charge types.' 
			else if isnull(@ich_table_id,0) = 0
				select @alert_message = 'This is not a valid billing charge type, type is: ' + isnull(@ich_type_description,'') + ', category is: ' + isnull(@ich_category,'')
			-- date must be valid if entered
			else if ltrim(dbo.fnGetPiece(@xdata, 7, '~', '')) <> '' and @ich_date is null
				select @alert_message = 'Please enter a valid date or select a date from the date picker. Date entered: ' + isnull(ltrim(dbo.fnGetPiece(@xdata, 7, '~', '')),'')
			else if isnull(@ich_quantity,'') = ''
				select @alert_message = 'Please enter a valid quantity or enter 1 for one off charges.' 
			else if isnull(@ich_quantity,'') <> '' and try_cast(@ich_quantity as decimal(18,2)) is null
				select @alert_message = 'Please enter a valid numeric quantity. Quantity entered is: ' + isnull(@ich_quantity,'')
			else if isnull(@ich_unit_amount,'') <> '' and try_cast(@ich_unit_amount as decimal(18,2)) is null
				select @alert_message = 'This is not a valid unit charge amount: ' + isnull(@ich_unit_amount,'') + '. To use the default system unit charge leave this field blank.' 
			else if isnull(@ich_unit_amount,'') = '' and isnull(@ich_quantity,'') = ''
				select @alert_message = 'You must enter a quantity OR an amount.'
			else
				begin
					--- make sure date is null or set
					select @ich_date = case when @ich_date = '' then null else @ich_date end
					-- if no quantity set to 1
					if isnull(@ich_quantity,'') = ''
						select @ich_quantity = 1
					-- if no unit amount set to the default
					if isnull(@ich_unit_amount,'') = ''
						select @ich_unit_amount = @ich_default_unit_price
					-- set qty to integer
					-- pv 2019-05-02 changed to decimal
					declare @ich_quantity_dec decimal(18,2) = try_cast(@ich_quantity as decimal(18,2)) 
					declare @ich_unit_amount_dec decimal(18,2) = try_cast(@ich_unit_amount as decimal(18,2))
					-- and calculate total amount
					select @ich_total_amount = @ich_quantity_dec * @ich_unit_amount_dec
					-- use standard create BUT no alert
					declare @ich_options varchar(100) = 'NOALERTMESSAGE~insert'

					-- call standard
					EXEC st_m_create_billing_charge  @user_id,  @settings, null, @alert_message output,
						@charge_type = @ich_type,
						@ch_org_id = @ich_org_id_int,
						@billing_date  = @ich_date,
						@quantity = @ich_quantity_dec,	-- pv 2019-05-02 changed to decimal

						@total_amount = @ich_total_amount,
						@notes = @ich_notes,
						@linked_to_table = @ich_linked_type,
						@linked_to_id = @ich_linked_id,

						@options = @ich_options,
						@overwrite_charge_amount = @ich_unit_amount_dec	-- if this is the same as the default this will be set to null

				end
			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Inserted charge ' + isnull(@ich_type,'') + ', for organisation id ' + @ich_org_id + ', total value: ' + cast(@ich_total_amount as varchar(10))
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message,@audit_action='error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'billing-charge-insert', @object_name, @audit_action, null, null, null, @alert_message
		end

	-- pv 06-02-2019 added notification-insert
	else if @xproc in ('notification-insert')
		begin

			-- call out
			exec dm_m_proc_notification_insert  @user_id, @settings, @sql_logging, @output_message output,
					@xdata, @user_org_id, @access, @user_brand,
					@admin_user, @options, @redirect_page

		end


	-- pv 2019-06-11 added noti
	else if @xproc in ('note-edit')
		begin
			-- always log start of update
			exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields

			-- check we have org, charge type  value and notes
			declare @note_id int = cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
			declare @note_text varchar(8000) =  dbo.fnGetPiece(@xdata, 2, '~', '')
			if isnull(@note_id,0)=0 or isnull(@note_text,'') = ''
				select @output_message = 'This is not valid'
			else
				begin
					--- make sure date is null or set

					-- call standard
					EXEC st_update_notification_note  @user_id,  @settings, null,
						@output_message = @output_message output,
						@notification_note_id = @note_id,
						@note = @note_text,
						@stamp=null

				end
			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Edited notification ' + isnull(cast(@note_id as varchar(20)),'') + ', text: ' + @note_text 
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'note-edit', @object_name, 'info', null, null, null, @alert_message
		end

	-------------------------
	-- pv 2019-02-21 added start-page-change to change the default home page for a user only
	else if @xproc in ('start-page-change')
		begin
			-- get lookup brand for startpage
			select @lookup_brand = dbo.fnGetLookupBrand(@user_id,@settings,'StartPage')
			-- get start page
			declare @start_page varchar(50) = @xdata
			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- validate
			if isnull(@start_page,'')=''
				select @alert_message = 'Please pass in a start page'
			else if isnull((select count(1) reference from [lookup] with (nolock) where category='StartPage' and reference= @start_page  and brand_ref= @lookup_brand),0) =0 
				select @alert_message = 'Please pass in a valid start page for this brand. ('+@start_page+')'
			else
				begin
					-- call update module to update notes
					EXEC st_update_organisation  @user_id,@settings, 'X', @alert_message OUTPUT,
						@output_type OUTPUT,
						@organisation_id = @user_org_id,
						@stamp = 0,  			-- record update stamp  - optional passed in for updates
						@options = 'NOALERTMESSAGE',	--  @options 
						-- and update subscription
						@start_page = @start_page	
				end


			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Updated start page' 
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'start-page-change', @object_name, 'info', null, null, null, @alert_message
		end

	-- pv 2019-03-5 added user-name-change 
	else if @xproc in ('user-name-change')
		begin
			-- get user name
			declare @user_name varchar(50) = @xdata
			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- validate
			if isnull(@user_name,'')=''
				select @alert_message = 'Please pass in a user name'
			else if isnull(@admin_user,'') ='Y'
				select @alert_message = 'You cannot change the username when logged on as a user.'
			else if LEN(@user_name) > 20
				select @alert_message = 'The user name should be 20 characters or less'
			else if @user_name like '%/%'
				select @alert_message = @user_name + ' is not an allowed format for user name, please remove the "/"'
			else if @alias = @user_name 
				select @alert_message = 'Plerase enter a different username or click cancel to close this window.'
			else
				begin
					-- call update module to update user
					EXEC st_update_user  @user_id,@settings, 'X', @alert_message OUTPUT,
						@output_type OUTPUT,
						@event_user_id = @user_id,
						@alias = @user_name,
						@stamp = 0,  			-- record update stamp  - optional passed in for updates
						@options = 'NOALERTMESSAGE'	--  @options 
						-- and update user
				end


			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Updated user name' 
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'user-name-change', @object_name, 'info', null, null, null, @alert_message
		end

	-------------------------

	-- wv 2018-08-10  Wine Move functions
	else if @xproc in ('picking-list-clear-all')
		begin
			-- strip standard text
			declare @pick_type varchar(50) = replace(@xproc,'picking-list-','')

			-- at the moment just clear all 
			if @pick_type = 'clear-all'
				begin
					-- just delete all entries for this user
					delete from select_table where user_id=@user_id and select_mode='picking_list'
					select @alert_message = 'Removed selected items from the picking list.'
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

		end



	-- wv 2018-10-04 Archive account 
	else if @xproc in ('archive-account')
		begin

			/*
			to check result

			declare @org_id int = 52020
			select * from organisation where organisation_id = @org_id
			select * from [user] where organisation_id = @org_id
			select * from [user_defined_field] where table_name ='organisation' and record_id = @org_id

			*/

			-- check your are authorised
			select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_USERS_TO_ARCHIVE_ACCOUNTS','')
			-- get current number
			declare @value_1 varchar(100) = ''
			select @value_1 = value_1 from user_defined_field where brand_ref=@user_brand and table_name='organisation' and record_id = cast(@xdata as int)
			-- count wines for this account
			declare @acc_wines int
			select @acc_wines = count(1)
				from wine_entry we with (nolock)
					join cellar c with (nolock) on we.cellar_id = c.cellar_id
				where c.owner_id = try_cast(@xdata as int)
					and [status]='active'
					and [no_bottles] > 0



			-- if not numeric
			if isnumeric(@xdata) <> 1
				begin
					-- log in audit
					select @audit_exception ='This is not a valid organisation id: ' + isnull(@xdata,'')
					exec st_audit_hdr  @user_id, @settings, 'error', @object_name, 'invalid-id', null, @xdata, null, @audit_exception
					select @alert_message = @audit_exception
				end

			-- if active wines
			if isnull(@acc_wines,0) > 0
				begin
					-- log in audit
					select @audit_exception ='This account still has valid wine entries, organisation id: ' + isnull(@xdata,'')
					exec st_audit_hdr  @user_id, @settings, 'error', @object_name, 'wines', null, @xdata, null, @audit_exception
					select @alert_message = @audit_exception
				end


			-- if not in the list
			else if (isnull(@authorised,'') <> '' and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%'))
				begin
					-- log in audit
					select @audit_exception ='You are not authorised to archive accounts. (AUTHORISED_USERS_TO_ARCHIVE_ACCOUNTS)'
					exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-authorised', null, @container_id, null, @audit_exception
					select @alert_message = @audit_exception
				end

			else if isnull(@value_1,'') like 'archived-%'
				begin
					-- log in audit
					select @audit_exception ='This account is already archived. Organisation id: ' + isnull(@xdata,'')
					exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-valid', null, @container_id, null, @audit_exception
					select @alert_message = @audit_exception
				end

			else if isnull(@value_1,'') = '' or isnumeric(@value_1) <> 1
				begin
					-- log in audit
					select @audit_exception ='This is a not a valid account to be archived. Organisation id: ' + isnull(@xdata,'')
					exec st_audit_hdr  @user_id, @settings, 'warning', @object_name, 'not-valid', null, @container_id, null, @audit_exception
					select @alert_message = @audit_exception
				end

			else
				begin
					-- archive account
					-- first user defined field
					update user_defined_field
						set value_1 = case when value_1 like 'archived%' then value_1 else 'archived-' + isnull(value_1,'') end
							,value_2 = case when value_2 like 'archived%' then value_2 else 'archived-' + isnull(value_2,'') end
							,updated = getdate()
							,updated_by=@user_id
					where brand_ref=@user_brand and table_name='organisation' and record_id = cast(@xdata as int)

					-- and alias and password for the users
					update [user]
						set alias=case when alias not like 'archived%' then 'archived-'+alias else alias end
							,updated=getdate(), updated_by = @user_id
							,[disabled]=1
							,[password] = case when [password] not like 'archived%' then 'archived-'+[password] else [password] end
					where organisation_id = cast(@xdata as int)
						-- only actual users
						and user_access ='U'
						-- and not the admin users. (so they still show up)
						and isnull(admin_user,'') <> 'Y'

					-- and organisation name
					update organisation
						set name=case when name not like 'archived%' then 'archived-'+name else name end
							,updated=getdate(), updated_by = @user_id
							,[disabled]=1
					where organisation_id = cast(@xdata as int)

					-- audit trail
					select @audit_exception ='Archived account: ' + isnull(@xdata,'') + '.  Users and Organisation record'
					exec st_audit_hdr  @user_id, @settings, 'completed', @object_name, 'archived', null, @xdata, null, @audit_exception
					select @alert_message = @audit_exception

					/*
						so to unarchive remove the archived- text from user alias, user password and organisation name
						and also from user-defined fields code and number
					*/

				end

			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

		end


	else if @xproc in ('create-mixed-cases')
		begin
			-- mixed cases to be create for an organisation

			-- check we have org id
			declare @cmc_org_id varchar(50) =  dbo.fnGetPiece(@xdata, 1, '~', '')
			-- spiral cellar size  (2m ,2.5m or 3m)  - not needed but maybe usefll in future
			declare @cmc_size varchar(50) =  dbo.fnGetPiece(@xdata, 2, '~', '')
			-- model cellar id
			-- this should match to model-cellar-2m  and  model-cellar-2m-numbered 
			declare @cmc_model_cellar varchar(50) =  dbo.fnGetPiece(@xdata, 3, '~', '')

			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- get org brand
			declare @cmc_org_brand varchar(10) = ''
			select @cmc_org_brand = brand_ref from organisation with (nolock)
				where organisation_id = try_cast(@cmc_org_id as int)

			-- should check if org has got a spiral cellar ??

			-- get cellar id
			declare @cmc_cellar_id int 
			declare @cac_admin_id int
			select @cac_admin_id = try_cast(dbo.fnGetParameter(@user_id, @settings, 'M_WHITE_LABEL_ADMIN_ID',0) as int)
			-- and cellar id
			select top 1 @cmc_cellar_id = cellar_id from cellar with (nolock)
				where owner_id = @cac_admin_id
					and cellar_name = @cmc_model_cellar

			-- check if this org is valid
			if isnull(@cmc_org_id,'') = '' or isnumeric(@cmc_org_id) <> 1
				select @alert_message = 'This is not a valid organisation id: ' + isnull(@cmc_org_id,'')
			-- must be for correct brand
			else if isnull(@cmc_org_brand,'') <> @user_brand
				select @alert_message = 'This organisation does not belong to your brand: ' + isnull(@cmc_org_brand,'')
			-- and must have model cellar
			else if isnull(@cmc_cellar_id,0) = 0
				select @alert_message = 'You must pass in a valid model cellar name, model cellar, ' + isnull(@cmc_model_cellar,'') + ', not found for admin ID: ' + isnull(cast(@cac_admin_id as varchar(10)),'')

			else
				begin
					-- call copy mixed case procedure
					EXEC st_m_create_default_mixed_cases  @user_id,  @settings, null, @alert_message output
						,@to_organisation_id = @cmc_org_id
						,@copy_from_cellar_id = @cmc_cellar_id
						,@options = ''
					-- if error

				end

			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Copied bins from ' + isnull(@cmc_model_cellar,'') + ', for organisation id ' + cast(@cmc_org_id as varchar(10))
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'copy-mixed-cases', @object_name, 'info', null, null, null, @alert_message
		end


	else if @xproc in ('delete-account')
		begin
			-- delete account details
			-- so USER, organisation, cellars and address
			-- ONLY if there are no wines for this user (AT all)
			-- so even if wines are deleted but exist you cannot delete a user

			-- check we have org id
			declare @del_user_id varchar(50) = dbo.fnGetPiece(@xdata, 1, '~', '')

			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- get org brand
			declare @del_org_brand varchar(10) = ''
			declare @del_org_id varchar(50)
			select top 1 @del_org_brand = brand_ref, @del_org_id = u.organisation_id
			from [user] u with (nolock)
				join organisation o with (nolock) on o.organisation_id = u.organisation_id
				where u.[user_id] = try_cast(@del_user_id as int)

			-- get wines
			declare @del_wine_count int 
			select @del_wine_count = count(1)
			from wine_entry we with (nolock)
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
			where c.owner_id = @del_org_id

			-- check if this org is valid
			if isnull(@del_user_id,'') = '' or isnumeric(@del_user_id) <> 1
				select @alert_message = 'This is not a valid user id: ' + isnull(@del_user_id,'')
			-- must be for correct brand
			else if isnull(@del_org_brand,'') <> @user_brand
				select @alert_message = 'This organisation does not belong to your brand: ' + isnull(@del_org_brand,'')
			-- and must have NO wines
			else if isnull(@del_wine_count,0) > 0
				select @alert_message = 'This user already has or has had wines in their account and cannot be deleted'

			else
				begin
					-- call copy mixed case procedure
					--EXEC wo_delete_user  @user_id,  @settings, null, @alert_message output
					--	,@del_user_id = @del_user_id
					--	,@delete = 'Y'
					--	,@options = ''
					-- just call in right order
					-- wine entries not now
						--delete from wine_entry
						--where cellar_id in (select cellar_id from cellar where owner_id= @organisation_id)
					-- mixed case
					delete from [mixed_case] where cellar_id in (select cellar_id from cellar where owner_id= @del_org_id)
					-- cellars
					delete from [cellar] where owner_id = @del_org_id
					-- address
					delete from [address] where organisation_id = @del_org_id
					-- delete users
					delete from [user] where organisation_id = @del_org_id
					-- and 
					delete from organisation where organisation_id = @del_org_id
					-- 

				end

			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Delete this account, for user id ' + cast(@del_user_id as varchar(10))
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'deleted-account', @object_name, 'info', null, null, null, @alert_message
		end


	-- wv 2018-12-05  Check and correct container status
	else if @xproc in ('check-container-status')
		begin
			-- call standard module
			select @con_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- check if this org is valid
			if isnull(@con_id,'') = '' or isnumeric(@con_id) <> 1
				begin
					select @alert_message = 'This is not a valid container id: ' + isnull(@con_id,'')
					-- and message
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000
				end
			else
				begin
					-- call standard proc
					exec st_check_container_status @user_id, @settings, @sql_logging, null
						, @con_id, null
						, @options = 'ALERT'
				end
		end


	-- wv 2018-10-16 delete consignment
	-- actual -- this will set status to cancelled X
	else if @xproc in ('wine-consignment-delete','wine-consignment-approve','wine-consignment-suspend','wine-consignment-unsuspend','wine-consignment-sold','wine-consignment-complete','wine-consignment-rollback')
		begin
			-- check we have a wine consignment id
			select @con_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @con_bottles_sold int = isnull(try_cast(dbo.fnGetPiece(@xdata, 2, '~', '') as int),0)
			select @wine_entry_id = isnull(try_cast(dbo.fnGetPiece(@xdata, 3, '~', '') as int),0)
			declare @payment_made varchar(10) = isnull(dbo.fnGetPiece(@xdata, 4, '~', ''),'')
			declare @paid_amount decimal(18,2) = isnull(try_cast(dbo.fnGetPiece(@xdata, 5, '~', '') as decimal(18,2)),0)
			declare @payment_type varchar(10) = isnull(dbo.fnGetPiece(@xdata, 6, '~', ''),'')
			declare @suspension_note varchar(800) = isnull(dbo.fnGetPiece(@xdata, 7, '~', ''),'')

			-- if we have wine entry but no con_id get it (assume there is only one active one
			if isnull(@con_id,'') = '' and @wine_entry_id > 0
				begin
					-- ONLY works for active consignment
					select @con_id = wine_consignment_id
						from wine_consignment wci with (nolock)
						where wine_entry_id = try_cast(@wine_entry_id as int)
							-- must be enabled
							and isnull([disabled],0) = 0
							-- only select pending, approved or suspendedconsignment
							and isnull(consignment_status,'') in ('A','P','Y')
				end
				

			-- default template
			select @alert_template = 'alert_message_html_danger'
			declare @consigned_bottles int
			declare @sell_as_single_lot varchar(1) =''
			declare @sell_by_case_only varchar(1) =''

			-- get status
			select top 1 @con_status = consignment_status, @con_org_brand = o.brand_ref
				, @consigned_bottles = wc.consigned_bottles
				, @sell_as_single_lot = sell_as_single_lot, @sell_by_case_only=sell_by_case_only
			from [wine_consignment] wc with (nolock)
				join wine_entry we with (nolock) on we.wine_entry_id = wc.wine_entry_id
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
			where wc.wine_consignment_id = @con_id
			-- get description
			select @con_description = dbo.fnGetLookupDescriptionDefault(@user_id,@settings, 'ConsignmentStatus',@con_status,@con_status)

			-- select text
			if @xproc = 'wine-consignment-delete' 
				select @con_text = 'delete', @con_new_status ='X'
			else if @xproc = 'wine-consignment-approve' 
				select @con_text = 'approve', @con_new_status = 'A'
			else if @xproc = 'wine-consignment-suspend' 
				select @con_text = 'suspend', @con_new_status = 'Y'
			else if @xproc = 'wine-consignment-unsuspend'
				-- pv 2019-06-14 for the US-X it should go back to pending when un-suspending
				select @con_text = 'un-suspend', @con_new_status = case when dbo.fnGetParameter(@user_id,@settings,'ALLOW_TRADING_US','N') ='Y' then 'P' else 'A' end
			else if @xproc = 'wine-consignment-sold' 
				select @con_text = 'sell', @con_new_status = 'S'
			else if @xproc = 'wine-consignment-complete' 
				select @con_text = 'complete', @con_new_status = 'C'
			else 
				select @con_text = @xproc, @con_new_status = @con_status

			---- pv 2019-05-22 if using US exchange the user should be either a license holder or a WO admin
			if dbo.fnGetParameter(@user_id,@settings,'ALLOW_TRADING_US','N') ='Y' and @access <> 'A' and @xproc not in ('wine-consignment-complete','wine-consignment-rollback','wine-consignment-delete' )
				and ',' +  dbo.fnGetParameter(@user_id,@settings,'LICENSE_HOLDER_IDS','') + ',' not like '%,' + cast(@user_org_id as varchar(15)) + ',%' 
				begin
					select @alert_message = 'You are not authorised to edit wine consignments. Org_id/User_id: ' + cast(@user_org_id as varchar(15)) + '/' + cast(@user_id as varchar(15))
				end
			-- for sold check we have a valid qty
			else if @xproc = 'wine-consignment-sold' and @con_bottles_sold= 0
				select @alert_message = 'For confirming sold you must pass in a valid nr of bottles. Passed in is: ' + isnull(dbo.fnGetPiece(@xdata, 2, '~', ''),'')
			else if @xproc = 'wine-consignment-sold' and @con_bottles_sold > @consigned_bottles
				select @alert_message = 'You cannot sell more bottles than what is consigned. Sold qty: ' + isnull(dbo.fnGetPiece(@xdata, 2, '~', ''),'') + ', consigned quantity is: ' + isnull(cast(@consigned_bottles as varchar(10)),'')
			-- check sell as single lot
			else if @xproc = 'wine-consignment-sold' and isnull(@sell_as_single_lot,'') ='' and @con_bottles_sold < @consigned_bottles
				select @alert_message = 'You must purchase all bottles. This consignment is set to sell as single lot. Sold qty: ' + isnull(dbo.fnGetPiece(@xdata, 2, '~', ''),'') + ', consigned quantity is: ' + isnull(cast(@consigned_bottles as varchar(10)),'')
			-- check sell by case only
			--else if @xproc = 'wine-consignment-sold' and isnull(@sell_as_single_lot,'') ='' and @con_bottles_sold < @consigned_bottles
			--	select @alert_message = 'You must purchase all bottles. This consignment is set to sell as single lot. Sold qty: ' + isnull(dbo.fnGetPiece(@xdata, 2, '~', ''),'') + ', consigned quantity is: ' + isnull(cast(@consigned_bottles as varchar(10)),'')
			-- check if this id is valid
			else if isnull(@con_id,'') = '' or isnumeric(@con_id) <> 1 or isnull(@con_status,'') = ''
				select @alert_message = 'This is not a valid wine consignment id: ' + isnull(@con_id,'')
			-- must be for correct brand
			else if isnull(@con_org_brand,'') <> @user_brand
				select @alert_message = 'This wine consignment does not belong to your brand: ' + isnull(@con_org_brand,'')
			else if @xproc = 'wine-consignment-complete' and @payment_made <> 'Y' and dbo.fnGetParameter(@user_id,@settings,'ALLOW_TRADING_US','N') ='Y'
				select @alert_message = 'The payment needs to be made before completing the transaction'

			-- and must have valid status
			else if 
				(@xproc = 'wine-consignment-delete' and @con_status not in ('P','A'))
				or
				(@xproc = 'wine-consignment-approve' and @con_status not in ('P'))
				or
				(@xproc = 'wine-consignment-suspend' and @con_status not in ('P','A'))
				or
				(@xproc = 'wine-consignment-unsuspend' and @con_status not in ('Y'))
				or
				(@xproc = 'wine-consignment-sold' and @con_status not in ('P','A','Y'))
				or
				(@xproc = 'wine-consignment-complete' and @con_status not in ('S'))  -- can NOT go direct to complete at the moment
				-- pv 2019-06-04 added option to rollback sold transactions
				or
				(@xproc = 'wine-consignment-rollback' and @con_status <> 'S')

				select @alert_message = 'You cannot ' + @con_text + ' this consignment, incorrect status.'
					+ ' Current status is: ' + @con_description 
			else
				begin
					-- for updating status 
					-- pv 2019-05-23 added more fields and specificoption for 'complete' to copy wine entry
					if @xproc = 'wine-consignment-complete'
						begin
							declare @date_now date = getdate()
							-- for complete
							EXEC st_update_wine_consignment_complete @user_id,  @settings, null, @alert_message output
								,@wine_consignment_id = @con_id
								,@consignment_status = @con_new_status
								-- must specifically ask for event !!
								,@options = 'NOALERTMESSAGE,EVENT'
								,@payment_made = @payment_made
								,@paid_amount = @paid_amount
								,@payment_type = @payment_type
								,@payment_date = @date_now
						end
					else if @xproc = 'wine-consignment-sold'
						begin
							-- for sold
							EXEC st_update_wine_consignment_sold @user_id,  @settings, null, @alert_message output
								,null
								,@wine_consignment_id = @con_id
								,@bottles_sold = @con_bottles_sold
								,@consignment_status = 'S'
								-- must specifically ask for event !!
								,@options = 'NOALERTMESSAGE,EVENT'
						end

					-- pv 2019-06-04 added option to rollback transactions once completed or sold
					else if @xproc = 'wine-consignment-rollback'
						begin
							-- for sold
							EXEC st_update_wine_consignment_rollback @user_id,  @settings, null, @alert_message output
								,null
								,@wine_consignment_id = @con_id
								,@consignment_status = @con_status
								-- must specifically ask for event !!
								,@options = 'NOALERTMESSAGE,EVENT'
						end

					else if @xproc in ('wine-consignment-suspend', 'wine-consignment-unsuspend') and dbo.fnGetParameter(@user_id,@settings,'ALLOW_TRADING_US','N') ='Y'
						begin
						select @suspension_note = replace(@suspension_note,'%20', ' ' ) 
							-- use update
							EXEC st_update_wine_consignment @user_id,  @settings, null, @alert_message output
								,@wine_consignment_id = @con_id
								,@stamp = null
								,@consignment_status = @con_new_status
								,@notes = @suspension_note
								-- must specifically ask for event !!
								,@options = 'NOALERTMESSAGE,EVENT'
						end

					else
						begin
							-- use update
							EXEC st_update_wine_consignment @user_id,  @settings, null, @alert_message output
								,@wine_consignment_id = @con_id
								,@stamp = null
								,@consignment_status = @con_new_status
								-- must specifically ask for event !!
								,@options = 'NOALERTMESSAGE,EVENT'
						end
				end

			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank 
					select @alert_message = 'Updated wine consignment, action: ' + @con_text + ', new status: ' 
							+ dbo.fnGetLookupDescriptionDefault(@user_id,@settings,'ConsignmentStatus',@con_new_status,@con_new_status)
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'updated-consigned', @object_name, 'info', null, null, null, @alert_message
		end


	else if @xproc = ('wine-consignment-sell-approve')
		begin
			-- check we have a wine consignment id
			select @wine_entry_id = isnull(try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int),0)
			declare @bottles_sold int = isnull(try_cast(dbo.fnGetPiece(@xdata, 2, '~', '') as int),0)
			declare @bottle_price decimal(18,4) = isnull(try_cast(dbo.fnGetPiece(@xdata, 3, '~', '') as decimal(18,4)),0)
			select @status = dbo.fnGetPiece(@xdata, 4, '~', '')

			-- JP 2019-07-02 For now default expiry date
			declare @consign_expiry_default date = getdate()+30

			-- JP 2019-07-05 insert some info into udf
			declare @proposed_price decimal(18,4) = null
			declare @wholesaler_price decimal(18,4) = null
			declare @min_price_competitors decimal(18,4) = null
			declare @avg_price_competitors decimal(18,4) = null
			declare @lowest_competitor varchar(255) = null
			
			select @wholesaler_price = we.price, @proposed_price = dbo.fngetproposedprice(@user_id,@settings,'',@brand,we.price,we.wine_Id,we.vintage,we.bonded_type,we.bottle_size_ref,@region, @currency) 
			from wine_entry we with (nolock) 
			where we.wine_entry_Id = @wine_entry_id
			
			--select @alert_message = 'brand: '+isnull(cast(@brand as varchar(20)),'')+' wine entry id: '+isnull(cast(@wine_entry_id as varchar(20)),'')
			--	+' currency: '+isnull(cast(@currency as varchar(20)),'')+ ' region: '+isnull(@region,'')

			--exec st_audit_hdr  @user_id, @settings, 'updated-consigned', @object_name, 'more details 1', null, null, null, @alert_message

			select @min_price_competitors = MIN(wpmd.price_75cl_bottle), @avg_price_competitors = AVG(wpmd.price_75cl_bottle)
			from wine_entry we with (nolock) 
			join wine_price_merchant_details wpmd with (nolock) 
				on isnull(wpmd.disabled,0) = 0 and wpmd.wine_Id = we.wine_Id and wpmd.vintage = we.vintage 
					and wpmd.price_region_ref = @region and wpmd.currency_ref = @currency and wpmd.price_point > getdate()-7
			join [lookup] lk with (nolock) on wpmd.merchant = lk.reference collate SQL_Latin1_General_CP1_CI_AS and lk.category = 'MerchantMarketCompetitor'
				and isnull(lk.disabled,0)=0 and lk.brand_ref = @brand
			where we.wine_entry_Id = @wine_entry_id
			group by we.wine_entry_id
			
			select top 1 @lowest_competitor = wpmd.merchant
			from wine_entry we with (nolock) 
			join wine_price_merchant_details wpmd with (nolock) 
				on isnull(wpmd.disabled,0) = 0 and wpmd.wine_Id = we.wine_Id and wpmd.vintage = we.vintage 
					and wpmd.price_region_ref = @region and wpmd.currency_ref = @currency and wpmd.price_point > getdate()-7
			join [lookup] lk with (nolock) on wpmd.merchant = lk.reference collate SQL_Latin1_General_CP1_CI_AS and lk.category = 'MerchantMarketCompetitor'
				and isnull(lk.disabled,0)=0 and lk.brand_ref = @brand
			where we.wine_entry_Id = @wine_entry_id
				and wpmd.price_75cl_bottle = @min_price_competitors
				
			--select @alert_message = 'udf_11: '+isnull(cast(@wholesaler_price as varchar(20)),'')+' udf_12: '+isnull(cast(@proposed_price as varchar(20)),'')+' udf_13: '+isnull(cast(@min_price_competitors as varchar(20)),'')
			--	+' udf_14: '+isnull(cast(@avg_price_competitors as varchar(20)),'')+' udf_15: '+isnull(@lowest_competitor,'')

			--exec st_audit_hdr  @user_id, @settings, 'updated-consigned', @object_name, 'more details 2', null, null, null, @alert_message

			exec st_update_user_defined_field @user_id, @settings, @sql_logging, @output_message OUTPUT
				, @output_type OUTPUT,null, 0, 'NOALERTMESSAGE', @brand, 'wine-entry'
				, @wine_entry_id, @value_11 = @wholesaler_price, @value_12 = @proposed_price, @value_13 = @min_price_competitors
				, @value_14 = @avg_price_competitors, @value_15 = @lowest_competitor

			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- use update
			EXEC st_update_wine_consignment @user_id,  @settings, null, @alert_message output
				,@wine_entry_id = @wine_entry_id
				,@consignment_status = @status
				,@consigned_bottles = @bottles_sold
				,@selling_price = @bottle_price
				,@stamp = null
				,@admin_set_approve_status = 'Y'
				, @expiry_date = @consign_expiry_default
				-- must specifically ask for event !!
				,@options = 'NOALERTMESSAGE,EVENT'
		
			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank 
					select @alert_message = 'Updated auto-consignment, action: ' + 'auto-consign' + ', new status: ' 
							+ dbo.fnGetLookupDescriptionDefault(@user_id,@settings,'ConsignmentStatus',@status,@status)
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'updated-consigned', @object_name, 'info', null, null, null, @alert_message
		end

	-- process include/exclude merchant
	else if @xproc in ('ws-prices-include-merchant', 'ws-prices-exclude-merchant')
		begin
			-- check we have a valid mderchant name
			-- its escape for url so reverse
			declare @merchant_name varchar(100) = dbo.fnEscapeURL(dbo.fnGetPiece(@xdata, 1, '~', ''),'R')
			-- check it exist ??
			-- just update for now
			-- action
			declare @action varchar(20) = case when @xproc = 'ws-prices-include-merchant' then 'Include' else 'Exclude' end 
			-- get lookup id
			declare @lookup_id int
			select @lookup_id = lookup_id from [lookup]
				where category='ExcludedMerchants' and reference = @merchant_name
					and brand_ref= @brand and isnull([disabled],0) = 0
			-- if entry doesnt exit
			if isnull(@lookup_id,0) = 0
				begin
					-- insert into lookup
					select @id = MAX([lookup_id]) from dbo.[lookup];
					-- and insert
					insert into [dbo].[lookup]
						([lookup_id],[category],[reference],[brand_ref],[description],[display_order],[is_default_entry],[notes],[lookup_field_1],[disabled],[created],[created_by],[updated],[updated_by],[stamp])
					values
						(@id+1,'ExcludedMerchants',@merchant_name,@brand,@merchant_name,0,'N',NULL,@action,0,getdate(),@user_id,getdate(),@user_id,0)
				end
			else
				begin
					-- else update existing entry
					update [lookup]
						set lookup_field_1 = @action,updated=getdate(), updated_by=@user_id
					where lookup_id = @lookup_id and brand_ref= @brand
				end
			-- and record
			select @audit_exception = case when isnull(@lookup_id,0) = 0 then 'Inserted ' else 'Updated ' end
				+ @action + ' merchant price for merchant ' + @merchant_name
			exec st_audit_hdr  @user_id, @settings, @action, @object_name, 'completed', null, @lookup_id, null, @audit_exception

		end

	else if @xproc in ('enable-consignment-organisation')
		begin
			-- check we have a valid organisation id
			declare @con_org_id int = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
			declare @con_flag varchar(1) = dbo.fnGetPiece(@xdata, 2, '~', '')
			select @alert_template = 'alert_message_html_danger'

			-- if not valid
			if isnull(@con_org_id,0) = 0 
				select @alert_message = 'This is not a valid organisation number: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- check if its valid and for current brand
			select @con_org_brand = brand_ref from organisation with (nolock)
				where organisation_id = @con_org_id
			-- must be for valid
			if isnull(@con_org_brand,'') = ''
				select @alert_message = 'This is not a valid organisation: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- and for correct brand
			else if isnull(@con_org_brand,'') <> @user_brand
				select @alert_message = 'This organisation does not belong to your brand: ' + isnull(@user_brand,'')
			else if isnull(@con_flag,'') not in ('','A','Y','N')
				select @alert_message = 'This is not a valid consignment indicator. enter Y, N or A, flag is ' + isnull(@con_flag,'')
			else
				begin
					-- do update in organisation
					-- for selling must update status and wine entry
					EXEC st_update_organisation  @user_id, @settings, @sql_logging, @alert_message OUTPUT
						,@organisation_id = @con_org_id
						,@stamp = null  		-- record update stamp  - optional passed in for updates
						,@enable_consignment = @con_flag
						,@options = 'NOALERTMESSAGE'
				end

			-- if no errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank 
					select @alert_message = 'Updated organisation consignment flag, consignment: ' + @con_flag
				end
			-- and give message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'info', null, null, null, @alert_message

		end



	-- wine entry edit option
	-- USED from pop up so out output_message if error
	else if @xproc='wine-entry-edit'
		begin
			-- validate, if ok update but with special processing
			select @select_name = dbo.fnGetPiece(@xdata,1,'~','')
			declare @tmp_new_wine_id int = dbo.fnGetOrgIDFromString(@select_name) 
			declare @tmp_ref_owner_id int 
			select @tmp_ref_owner_id = owner_id from wine with (nolock) where wine_id = @tmp_new_wine_id
			select @new_name = dbo.fnPiece(@xdata,2,'~','')
			select @producer_name = dbo.fnPiece(@xdata,3,'~','')
			select @wine_type = dbo.fnPiece(dbo.fnPiece(@xdata,4,'~',''),1,' - ','')
			--select @wine_sub_type = dbo.fnPiece.fnGetPiece(@xdata,4,'~',''),2,' - ','')
			-- strip country (we can pick that up from region)
			select @region = dbo.fnPiece(dbo.fnPiece(@xdata,5,'~',''),1,' - ','')
			select @wine_entry_id = try_cast(dbo.fnPiece(@xdata,6,'~','') as int)

			-- get current wine-id
			declare @tmp_we_owner_id int 
			declare @tmp_incoming_name varchar(200) =''
			select @wine_id = we.wine_id
				, @tmp_we_owner_id = w.owner_id
				, @tmp_incoming_name = we.incoming_wine_name
			from wine_entry we with (nolock)
				join wine w with (nolock) on w.wine_id = we.wine_id	
			 where we.wine_entry_id = @wine_entry_id
			 -- strip vintages from the front and bottle size info at the back
			 select @tmp_incoming_name = dbo.fnProcessIncomingWineName(@user_id,@settings,@tmp_incoming_name,'')

			-- check if edit is allowed for this user
			declare @allow_edit_reference_wines varchar(1)='N'

			-- always allow updating own wine
			-- or if WO admin (A W)
			-- or if authorised 
			if @tmp_we_owner_id > 0
				
				or @access in ('A','W') 
				or (','+dbo.fnGetParameter(@user_id, @settings,'M_ALLOW_TO_EDIT_REFERENCE_WINES','')+',') like ('%,'+@alias+',%')
				select @allow_edit_reference_wines = 'Y'

			-- user must be at least M or A
			if @allow_edit_reference_wines <> 'Y'
				select @output_message = 'You are not authorised to update reference wine records. Please contact support.' 
			else if isnull(@wine_entry_id,0) = 0 
				select @output_message = 'This is not a valid wine entry id: ' + dbo.fnGetPiece(@xdata,6,'~','')
			else if isnull(@wine_id,0) = 0
				select @output_message = 'This wine entry id does not exist: ' + dbo.fnGetPiece(@xdata,6,'~','')
			-- check if we have a valid id selected
			-- ONLY when we are matching to another wine, otherwise NOT required
			if isnull(@select_name,'') <> '' and isnull(@tmp_new_wine_id,0) = 0 
				select @output_message = 'You must select a valid wine from the dropdown including the numeric id (), entered wine is: ' + dbo.fnGetPiece(@xdata,1,'~','')

			else
				begin
					-- if we have a new reference wine 
					if isnull(@tmp_new_wine_id,0) > 0 
						begin
							-- we now have a valid id so update this wine entry
							EXEC st_update_wine_entry  @user_id, @settings, 'X', @output_message OUTPUT, 
								-- type, id, stamp and options   (options is disposed type ~ price~ note)
								@output_type OUTPUT, @wine_entry_id OUTPUT,	0, 'NOALERTMESSAGE~'
								,@wine_id = @tmp_new_wine_id	
						end

					else
						begin
							-- update custom wine with the additional data

							-- Get data
							declare @region_country varchar(50) = null
							-- get region
							select @region_country = parent from region with (nolock) 
								where region_type='region' and region=@region and isnull([disabled],0)=0
					
							-- If here update the linked wine (custom OR ref wine)
							select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_USERS_UPDATE_REFERENCE_WINES','')
							-- only allow update of reference wine if WO admin
							if isnull(@tmp_we_owner_id,0)=0 and @access not in ('W','A') and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%')
								select @output_message = 'You are not authorised to update reference wines.'
							else if isnull((select count(1) from lookup with (nolock) where category='WineType' 
								and dbo.fnXMLTextDisplay(description, 100, 0, 'en')=@wine_type),0) = 0
								select @output_message = 'This is not a valid wine type, please select from the dropdown. Type entered: ' + @wine_type
							else if isnull(@region_country,'') = ''
								select @output_message = 'This is not a valid region, please select from the dropdown: ' + dbo.fnPiece(@xdata,5,'~','')
							else
								begin
									-- set to null if not passed so we dont change it
									if rtrim(isnull(@producer_name,'')) = ''
										select @producer_name = null
									if rtrim(isnull(@wine_type,'')) = ''
										select @wine_type = null
									if rtrim(isnull(@region,'')) = ''
										select @region = null
									if rtrim(isnull(@region_country,'')) = ''
										select @region_country = null
									if isnull(@new_name,'') = ''
										select @new_name = null
									-- update wine details
									EXEC st_update_wine  @user_id, @settings, 'X', @output_message OUTPUT, 
										-- type, id, stamp and options   (options is disposed type ~ price~ note)
										@output_type OUTPUT, @wine_id OUTPUT,	0, 'NOALERTMESSAGE~'
										,@producer_name = @producer_name
										,@name = @new_name
										,@country_ref = @region_country
										,@region= @region
										,@wine_type = @wine_type
									-- if error gets reported									 
								end
						end

/*					-- Now check for updating related records
					-- process all wines with the same incoming wine name
					-- ONLY if we have an incoming winename
					-- and the parameter is set
					if dbo.fnGetParameter(@user_id, @settings,'PROCESS_RELEATED_CUSTOM_WINES','N') = 'Y'
						and isnull(@tmp_incoming_name,'') <> ''
							begin
								-- use separate proc to do this
								exec st_update_related_wines
									@user_id, @settings, @sql_logging, null
									-- new wine id, incoming wine name
									,@tmp_new_wine_id, @tmp_incoming_name 
									-- producer ,  new wine name
									,@producer_name, @new_name, @region_country, @region
									-- type and options
									,@wine_type , ''

							end
*/

				end
		end

	-- pv 2019-06-13 added to bring wine entry back to main cellar when pending
	else if @xproc='wine-entry-activate'
		begin
			-- validate, if ok update but with special processing
			select @wine_entry_id = cast(dbo.fnGetPiece(@xdata,1,'~','') as int)
			declare @no_bottles int = cast(dbo.fnGetPiece(@xdata,2,'~','') as int)
			declare @consignment_status varchar(10) = dbo.fnGetPiece(@xdata,3,'~','')
			-- check no of bottles in consignment if exists
			declare @cur_consigned_bottles int
			declare @wine_consignment_id int
			declare @cur_consignment_status varchar(10)
			select @wine_consignment_id = wine_consignment_id
				,@cur_consigned_bottles = consigned_bottles 
				,@cur_consignment_status = consignment_status
			from wine_consignment where wine_entry_id = @wine_entry_id

			if isnull(@wine_entry_id,0) = 0 
				select @output_message = 'This is not a valid wine entry id: ' + cast(isnull(@wine_entry_id,'') as varchar(20))
			else if isnull(@no_bottles,0) = 0
				select @output_message = 'The number of bottles is not valid (' + cast(isnull(@no_bottles,'') as varchar(20)) + ' bottles)'
			else if ((isnull(@cur_consignment_status,'') = '' or @cur_consignment_status not in ('X','E')) and isnull(@cur_consigned_bottles, 0 ) =  @no_bottles) or @consignment_status <> @cur_consignment_status
				select @output_message = 'You are not allowed to move this entry. Consignment Status: ' + @cur_consignment_status + '/' + @consignment_status + ' - No. Bottles: ' + cast(@cur_consigned_bottles as varchar(10)) + '/' + cast(@no_bottles as varchar(10))
			else
				begin
					EXEC st_update_wine_entry_move  @user_id, @settings, 'X', @output_message OUTPUT 
						,@output_type OUTPUT, @wine_entry_id OUTPUT, @stamp = null 
						,@options = 'NOALERTMESSAGE,NOTRANSACTION,ADMIN,NOCONSIGNMENTADJUST'	-- option ADMIN otherwise not owner error		
						,@move_type = 'ACTIVATE'     -- move type
						,@quantity = @no_bottles  -- number of bottles to be moved
						,@wine_status = 'Active'
					if isnull(@consignment_status,'') = 'E'
						begin

							EXEC st_update_wine_consignment @user_id,  @settings, null, @output_message output
								,@wine_consignment_id = @wine_consignment_id
								,@consignment_status = 'X'
								,@options = 'NOALERTMESSAGE~NOTRANSACTION,EVENT,ADMIN,LICENSE_HOLDER'
						end
				end
			-- if errors
			if isnull(@output_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine Entry Activated. Wine Entry ID: ' + cast(isnull(@wine_entry_id,'') as varchar(20))
					-- and display
				end
			else
				begin
					select @alert_template = 'alert_message_html_danger'
					select @alert_message = @output_message
				end
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'wine-entry-activate', @object_name, 'info', null, null, null, @output_message
		end


	-- wv 2018-11-16  Update basket tracking information
	-- edit popup
	--	1 = shipper   name (reference)
	--  2 = Tracking cookie
	--  3 = Full shipping URL (if required)  most sites wont need this
	--  4 = actual shipping date
	--  5 - Basket id
	else if @xproc='basket-tracking-update'
		begin
			-- validate, if ok update but with special processing
			declare @shipper varchar(100) = dbo.fnGetPiece(@xdata,1,'~','')
			declare @shipper_ref varchar(30)
			-- can be just description OR description ()
			if @shipper like '%(%)'
				select @shipper_ref = dbo.fnGetIDFromString(@shipper,'') 
			else
				begin
					-- now check if its just full description
					-- get lookup brand for charge type
					select @lookup_brand = dbo.fnGetLookupBrand(@user_id,@settings,'Shipper')
					-- and select
					select top 1 @shipper_ref = reference
						from [lookup] with (nolock) 
					where category ='shipper'
						and isnull([disabled],0)=0
						and brand_ref=@lookup_brand
						and dbo.fnXMLText([description],0,'','en') = @shipper
				end

			declare @tracking_id varchar(50) = dbo.fnPiece(@xdata,2,'~','')
			declare @tracking_URL varchar(200) = dbo.fnPiece(@xdata,3,'~','')
			declare @ship_date varchar(20) = dbo.fnPiece(@xdata,4,'~','')
			select @basket_id = try_cast(dbo.fnPiece(@xdata,5,'~','') as int)
			-- get current basket owner
			declare @tmp_basket_owner_id int 
			select @tmp_basket_owner_id = u.organisation_id,@status= b.[status]
				from basket b with (nolock)
				join [user] u with (nolock) on u.[user_id] = b.[user_id]
			 where b.basket_id = @basket_id

			-- user must be at least M or A
			if @access not in ('W','A','M')
				select @output_message = 'You are not authorised to use this function' 
			else if isnull(@basket_id,0) = 0 
				select @output_message = 'This is not a valid basket id: ' + isnull(dbo.fnGetPiece(@xdata,5,'~',''),'')
			else if isnull(@tmp_basket_owner_id,0) = 0
				select @output_message = 'This basket id does not exist: ' + isnull(dbo.fnGetPiece(@xdata,5,'~',''),'')
			else if isnull(@status,'') not in ('S','C')
				select @output_message = 'This basket does not have the correct status: ' + isnull(@status,'')
			-- date must be valid if entered
			else if ltrim(dbo.fnGetPiece(@xdata, 4, '~', '')) <> '' and @ship_date is null
				select @alert_message = 'Please enter a valid date or select a date from the date picker. Date entered: ' + isnull(ltrim(dbo.fnGetPiece(@xdata, 4, '~', '')),'')
			else if isnull(@tracking_id,'') =''
				select @output_message = 'Please enter the tracking ID for this shipment. '
			else if isnull(dbo.fnGetPiece(@xdata,1,'~',''),'') =''
				select @output_message = 'Please enter a valid shipper. '
			else if dbo.fnGetLookupDescriptionDefault(@user_id,@settings,'Shipper',@shipper_ref,@shipper_ref) =''
				select @output_message = 'This is not a valid shipper, please select a valid shipper from the dropdown. Entered value: ' + dbo.fnGetPiece(@xdata,1,'~','')

			else
				begin
					-- call update basket
					EXEC st_update_basket  @user_id, @settings, 'X', @output_message OUTPUT, 
						-- type, id, stamp and options   (options is disposed type ~ price~ note)
						@output_type OUTPUT, @basket_id OUTPUT,	0, 'NOALERTMESSAGE~'
						,@actual_shipped_date = @ship_date
						,@shipper_ref  = @shipper_ref
						,@tracking_id = @tracking_id
						,@tracking_url = tracking_url		-- not used for TWC

				end
		end

	-- archiving users and wines
	else if @xproc in ('archive-user-account','archive-reset-user-account','archive-user-wines')
		begin
			-- call special procedure
			EXEC st_archive_wine_users  
				@user_id, 
				@settings, 	  
				@sql_logging,
				@output_message OUTPUT,
	  
				@xproc,
				@xdata,
				@options,
				@redirect_page  OUTPUT

			-- No further action

		end

	-- Generate monthly charges
	else if @xproc = 'generate-monthly-charges'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				select @alert_message = 'You are not authorised to use this function. Admin access required.'
			-- must in authorised list
			else if ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CHARGES','')+',') not like ('%,'+@alias+',%'))
				select @alert_message = 'You are not authorised to use this function. Please contact support to add alias (' +isnull(@alias,'')+') to parameter USERS_ALLOWED_TO_EDIT_CHARGES.'

			-- check if there are any monthly charges for this month already
			declare @charges_count int
			declare @last_month_day date =dateadd(DD,-1,  cast(
					cast(year(getdate()) as varchar(10))
					+ '-' +cast(month(getdate()) as varchar(10))
					+ '-01' 
					as date))
			-- for testing select @last_month_day = cast('2018-nov-30' as date)
			-- get charge type for this white label
			select @charges_count = count(1)
				from billing_charge bc with (nolock)
					join lookup lct with (nolock) on lct.category like 'ChargeType%' and lct.reference=bc.charge_type collate database_default and isnull(lct.[disabled],0) = 0 and lct.brand_ref=@user_brand
					join organisation o with (nolock) on o.organisation_id = bc.organisation_id
			where isnull(bc.[disabled],0) = 0
				-- for this month
				and year(billing_date) = year(@last_month_day) and month(billing_date) = month(@last_month_day)
				and (lookup_field_4 like 'storage%' or lookup_field_4 like 'subscription%')
				and o.brand_ref=@user_brand

			-- if there are already charge records, contact support to recreate
			if isnull(@charges_count,0) > 0
				begin
					-- set message
					select @alert_message = replace(
											replace(N'There are already, {charges_count}, monthly charges created for this month, {month}.
Please contact WO support to reset the charges for this month.'
												,'{charges_count}',isnull(cast(@charges_count as varchar(20)),''))
												,'{month}',isnull(cast(@last_month_day as varchar(20)),''))
				end


			-- if no error do processing
			if isnull(@alert_message,'') = ''
				begin
					-- call background processing, first run for storage
					exec st_process_billing_charge @user_id,@settings,'X',@alert_message OUTPUT
						-- all storage charges,  record id 0 is for all customers
						, @run_type = 'storage-all', @record_id = 0, @options = ''

					-- and then for subscription, only if no error
					if isnull(@alert_message,'') = ''
						exec st_process_billing_charge @user_id,@settings,'X',@alert_message OUTPUT
						-- all subscription charges
						, @run_type = 'subscription-all', @record_id = 0, @options = ''
					
				end

			-- if no error set success message
			if isnull(@alert_message,'') = '' 
				begin
					-- success
					select @alert_template = 'alert_message_html_success'
					select @alert_message = 'Generated monthly charges.'
				end
			else
				begin
					-- audit only if there was an error
					select @audit_exception = @alert_message + ' ' + @input_fields
					exec st_audit @user_id, @settings, @object_name, '', 'Error', @audit_exception
				end

			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template
		end

	-- JP20190116 send "My Positions" email to selected user
	else if @xproc in ('email-user-my-position')
		begin
		
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''
			declare @email_user_id int = ISNULL(TRY_CAST(@xdata as int),0)

			-- Check that @xdata has a real user id
			IF NOT EXISTS(
				SELECT 1 from [user] where [user_Id] = @email_user_id and [user_Id] > 0
			) 
				BEGIN
					Set @alert_message = 'This user doesn''t exist'
				END
			
			-- If islocked or disabled, 
			IF EXISTS(
				SELECT 1 from [user] where [user_Id] = @email_user_id and [user_Id] > 0
					and (ISNULL(disabled,0) = 1 OR ISNULL(is_locked,'N')='Y')
			) 
				BEGIN
					Set @alert_message = 'This user is locked or disabled'
				END

			-- If islocked or disabled, 
			IF (
				SELECT ISNULL(email,'') from [user] where [user_Id] = @email_user_id and [user_Id] > 0
			) = ''
				BEGIN
					Set @alert_message = 'This user doesn''t have an email address!'
				END
				

			-- if no error do processing
			IF isnull(@alert_message,'') = ''
				BEGIN

					EXEC st_event @user_id,@settings,@sql_logging,@alert_message OUTPUT
						,'PURE_POSITIONS_EMAIL', @email_user_id, 'N', null
						,null, null, null, null
						,'id',@email_user_id,'pure_email','dm_pure_positions_email'

				END

			-- if no error set success message
			if isnull(@alert_message,'') = '' 
				begin
					-- success
					select @alert_template = 'alert_message_html_success'
					select @alert_message = 'Email sent successfully'
				end
			else
				begin
					-- audit only if there was an error
					select @audit_exception = @alert_message + ' ' + @input_fields
					exec st_audit @user_id, @settings, @object_name, '', 'Error', @audit_exception
				end

			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

			-- No further action

		end
		
	-- mb - 2019-01-23 - add wine entries to container for dynamics
	else if @xproc = 'dynamics-c9_warehousejobs'
		begin
			if @options = 'CREATE_CONTAINER_API'
				begin
					-- mb - 2019-01-22 - also create an event record for each wine entry on the container
					if dbo.fnGetParameter(@user_id, @settings, 'CREATE_CONTAINER_ITEMS','N') = 'Y'
						begin
							DECLARE dyn_cont_wine_entries CURSOR FOR
								SELECT wine_entry_id, wine_id
								FROM wine_entry
								where container_id = @xdata
								and isnull([disabled],0) = 0

							declare @dyn_cont_weid int
							declare @dyn_cont_wid int
							declare @dyn_cont_uid int
							select @dyn_cont_uid = dbo.fnGetParameter(@user_id, @settings, 'M_WHITE_LABEL_SYSTEM_USER','-1')
		
							OPEN dyn_cont_wine_entries
							FETCH NEXT FROM dyn_cont_wine_entries INTO @dyn_cont_weid, @dyn_cont_wid
							WHILE(@@FETCH_STATUS = 0)
							BEGIN
								EXEC st_event @dyn_cont_uid, @settings, @sql_logging, @output_message OUTPUT, 'CREATE_CONTAINER_WINE_ENTRY', @dyn_cont_uid, 'N', null, null, @dyn_cont_weid, null, @dyn_cont_wid, 'container_id', @xdata, 'container', 'dm_m_container_api'
							
								FETCH NEXT FROM dyn_cont_wine_entries INTO @dyn_cont_weid, @dyn_cont_wid
							END

							CLOSE dyn_cont_wine_entries
							DEALLOCATE dyn_cont_wine_entries

						end
				end
			else if @options = 'CALLOFF_API'
				begin
					-- mb - 2019-01-22 - also create an event record for each wine entry in the basket
					if dbo.fnGetParameter(@user_id, @settings, 'CREATE_BASKET_ITEMS','N') = 'Y'
						begin
							DECLARE dyn_basket_wine_entries CURSOR FOR
								SELECT bi.basket_item_id, bi.wine_entry_id, we.wine_id
								FROM basket_item bi
									join wine_entry we on bi.wine_entry_id = we.wine_entry_id
								where bi.basket_id = @xdata
								and isnull(bi.[disabled],0) = 0
								and isnull(we.[disabled],0) = 0
								
							declare @dyn_basket_biid int
							declare @dyn_basket_weid int
							declare @dyn_basket_wid int
							declare @dyn_basket_uid int
							select @dyn_basket_uid = dbo.fnGetParameter(@user_id, @settings, 'M_WHITE_LABEL_SYSTEM_USER','-1')
		
							OPEN dyn_basket_wine_entries
							FETCH NEXT FROM dyn_basket_wine_entries INTO @dyn_basket_biid, @dyn_basket_weid, @dyn_basket_wid
							WHILE(@@FETCH_STATUS = 0)
							BEGIN
								EXEC st_event @dyn_basket_uid, @settings, @sql_logging, @output_message OUTPUT, 'CREATE_BASKET_WINE_ENTRY', @dyn_basket_uid, 'N', null, null, @dyn_basket_weid, null, @dyn_basket_wid
									, 'basket_id', @xdata, 'basket', 'dm_basket_list_v2'
									, 'basket_item_id', @dyn_basket_biid, 'basket_item', 'dm_m_basket_item'
							
								FETCH NEXT FROM dyn_basket_wine_entries INTO @dyn_basket_biid, @dyn_basket_weid, @dyn_basket_wid
							END

							CLOSE dyn_basket_wine_entries
							DEALLOCATE dyn_basket_wine_entries

						end
				end
		end


	-- wv 2019-02-13  reset or discard events
	else if @xproc in ('reset-event-reload','reset-event-discard')
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get event merge and process status
			declare @merge_status varchar(10)
			declare @proc_status varchar(10)
			select @merge_status=merge_status,@proc_status=process_status
				from event_record with (nolock)
			where event_record_id = try_cast(@xdata as int)

			-- ONLY allowed for admin
			if isnull(@access,'') not in ('M','A','W')
				select @alert_message = 'You are not authorised to use this function. Admin access required.'
			else if isnull(@merge_status,'') = '' and isnull(@process_status,'') = ''
				select @alert_message = 'This is not a valid event record id: ' + isnull(@event_record_id,'')
			else if isnull(@proc_status,'') = 'C'
				select @alert_message = 'This event is already completed. Use View and then action --> reload to process again'
			else 
				begin
					-- update 
					update event_record
						-- either reset or discard
						set merge_status = case when @xproc = 'reset-event-reload' then 'A' else 'X' end
							-- process status always X
							,process_status = 'X'
							,updated=getdate(),updated_by=@user_id
					where event_record_id = try_cast(@xdata as int)
						and isnull(process_status,'') <> 'C'

					-- if not ok
					if @@rowcount = 0
						select @alert_message = 'Update to event record failed'					

				end

			-- if no error set success message
			if isnull(@alert_message,'') = '' 
				begin
					-- success
					select @alert_template = 'alert_message_html_success'
					select @alert_message = case when @xproc = 'reset-event-reload'  then 'Event record reloaded - processing within next few seconds'
						else 'Event record discarded' end
					-- audit trail
					select @audit_exception = @alert_message + ' ' + @input_fields
					exec st_audit @user_id, @settings, @object_name, '', 'reset-event', @audit_exception
				end
			else
				begin
					-- audit for error
					select @audit_exception = @alert_message + ' ' + @input_fields
					exec st_audit @user_id, @settings, @object_name, '', 'Error', @audit_exception
				end

			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template
		end

	-- mb 2019-02-21 catch all other dynamics- calls to not throw an error
	else if @xproc like 'dynamics-%'
		begin
		
			-- dont' do anything
			select 1

		end


	-- jf 2019-03-01  delete file (disable)
	else if @xproc = 'disable-file'
		begin
			-- just clear selected entries for this user
			update wo_file set [disabled] = 1, [updated] = getdate(), [updated_by] = @user_id where file_id=@xdata
			-- log
			select @audit_exception = 'Disabled file ID: ' + cast(@xdata as varchar(10)) 
				+ '<br /> File Category: ' + (select file_category from wo_file with (nolock) where file_id=@xdata)
				+ '<br /> File Type: ' + (select file_type from wo_file with (nolock) where file_id=@xdata)
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'disable-file', null, @xdata, null, @audit_exception
		end


		-- jf 2019-03-06  complete inspection request
	else if @xproc = 'complete-inspection'		
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			declare @inspection_basket_id int 
			declare @inspection_brand varchar(50)
			select top 1 @inspection_basket_id = basket_id, @inspection_brand = o.brand_ref
				from basket b with (nolock)
				join [user] u with (nolock) on b.user_id = u.user_id
				join organisation o with (nolock) on o.organisation_id = u.organisation_id
			where basket_id= try_cast(@xdata as int)
				and basket_type='INSPECTION_REQUEST'

			-- check if allowed
			if isnull(@access,'') not in ('M','A','W')
				select @alert_message = 'You are not authorised to use this function. Admin access required.'
			else if isnull(try_cast(@xdata as int),0) = 0
				select @alert_message = 'This is not a valid basket id: ' + isnull(@xdata,'')
			else if isnull(@inspection_basket_id,0) = 0
				select @alert_message = 'This is not a valid basket id: ' + isnull(@xdata,'')
			else if @user_brand <> @inspection_brand
				select @alert_message = 'Your are not authorised to access this basket. Basket id: ' + isnull(@xdata,'')

			-- if no error set success message
			if isnull(@alert_message,'') = '' 
				begin
					-- success
					select @alert_template = 'alert_message_html_success'
					select @alert_message = 'Inspection request completed.'
					-- Update status but also check this is an inspection
					update basket set [status] = 'C', [updated] = getdate(), [updated_by] = @user_id 
					where basket_id=@xdata and basket_type='INSPECTION_REQUEST'
					-- log
					select @audit_exception = 'Complete Inspection Request: ' + cast(@xdata as varchar(10))
					exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'complete-inspection', null, @xdata, null, @audit_exception
				end
			else
				begin
					-- audit for error
					select @audit_exception = 'Error: ' + isnull(@alert_message,'') + ' ' + @input_fields
					exec st_audit @user_id, @settings, @object_name, '', 'Error', @audit_exception
				end

			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

		end


		--jf 2019-03-05 request inspection photo
	else if @xproc ='request-inspection'
		begin
			-- initialise
			select @alert_message=''

			-- must be user	
			if isnull(@access,'') not in ('M','A','W','U')
				begin
					-- set error message
					select @alert_message = 'You are not authorised to use this function.'
				end
			else if isnumeric(cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)) <> 1 
				begin
					-- Must be numeric
					select @alert_message = 'Inspection reference is not numeric, value is: ' + isnull(@xdata,'')
				end
			else

				begin
					-- get id
					select @wine_entry_id = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
					select @notes = try_cast(dbo.fnGetPiece(@xdata, 2, '~', '') as varchar(200))
					-- make sure basket id is NOT passed in
					select @basket_id = null

					-- and insert basket
					exec st_insert_basket_item @user_id, @settings,	@sql_logging, @output_message output, 
						@basket_item_id=@basket_item_id output,
						@wine_entry_id=@wine_entry_id,
						@basket_type='INSPECTION_REQUEST',
						@quantity_cases=0,
						@quantity_bottles=1,
						@notes=@notes

					-- if ok
					if isnull(@output_message,'') = ''
						begin
							-- process the basket
							exec st_process_basket @user_id, @settings, @sql_logging, @output_message output, 
								@status='A',
								@basket_type='INSPECTION_REQUEST',
								@address_id=null,
								@submit_notes=@notes
						end

					-- if not ok error
					if isnull(@output_message,'') <> ''
						select @alert_message = @output_message
				end

			-- check for error
			if isnull(@alert_message,'') <> ''
				begin
					-- log in audit trail
					exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'error-inspection', null, @xdata, null, @alert_message
					-- and return in @output_message
					select @output_message = @alert_message
				end
			else
				begin
					select @alert_message = 'Your request will be processed.'
					select @alert_template = 'alert_message_html_success'
					-- display message 
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template
				end

			-- errors are returned in @output_message

		end


	-- jf 2019-03-15 - edit cellar reference
	else if @xproc in ('edit-cellar-reference','edit-cellar-ref')
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			-- alert message
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_entry_id = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
			select @cellar_ref = dbo.fnGetPiece(@xdata, 2, '~', '')
	
			-- get this wine brand and location (from container!!)
			select @record_brand = ''
			declare @cur_cellar_ref varchar(100) = ''					
			declare @cur_location varchar(20) = ''					
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_cellar_ref = cellar_ref, @cur_location = co.warehouse_ref
			from wine_entry we with (nolock)
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
				left join container co with (nolock) on co.container_id = we.container_id
			where wine_entry_id = @wine_entry_id

			-- Check access via standard function
			-- this includes access level, brand match and location
			select @tmp_msg = dbo.fnValidateAuthorisationAndBrand(@user_id,@settings,'USERS_ALLOWED_TO_EDIT_CELLAR_REF',@record_brand,@cur_location,'','','','','')
		
			-- 	and other checks
			if isnull(@wine_entry_id,0) = 0
				select @alert_message = 'Wine entry is not numeric, wine entry: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- or doesnt exist
			else if isnull(@record_brand,'') = ''
				select @alert_message = 'This wine entry does not exist, wine entry: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- must be admin access and authorised - use function, also check record brand
			else if isnull(@tmp_msg,'') <> ''
				select @alert_message = @tmp_msg
				
			-- if here ok
			else 
				begin
					-- only update if different
 					if isnull(@cellar_ref,'') <> isnull(@cur_cellar_ref,'')
						begin
							-- update
							exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
								,@wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
								,@cellar_ref = @cellar_ref
							
							-- If we have an error
 							if isnull(@output_message,'') <> ''
								select @alert_message = 'Error:' + @output_message
						end
				end

			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Cellar ref has been updated.<br/><br/>Old value: '+ isnull(@cur_cellar_ref,'') + '<br/>New value: ' + isnull(@cellar_ref,'')
					-- if it was the same
					if isnull(@cellar_ref,'') = isnull(@cur_cellar_ref,'')
						select @alert_message = 'New value was the same, no changes made.'
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template
					-- NOTE that error message returned via output-message and processed in dm_m_api_proc
				end
			else
				begin
					-- only display alert if error
					select @audit_action ='val-error'
					select @output_message= @alert_message
				end

			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'edit-cellar-ref', @object_name, @audit_action, null, null, null, @alert_message
	end


	-- jf 2019-03-19 - edit club loction
	else if @xproc = 'edit-club-location'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			declare @club_wine_entry_id varchar(20) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @new_club varchar(20) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @new_provenance_c varchar(100)
			-- alert message
			select @alert_message = ''
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> '67'
					begin
						-- set error message
						select @alert_message = 'This wine does not belong to your brand.'
						exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
						exec st_audit_hdr  @user_id, @settings, 'edit-club-loc', @object_name, 'error', null, null, null, @alert_message
					end
			else if isnull(@access,'') not in ('M','A','W') --or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_CLUB_LOC','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@club_wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@club_wine_entry_id,'')


			else if (left(@new_club,1) <> 'F' or len(@new_club) <> 5) and @new_club <> ''
				select @alert_message = '<b>WRONG FORMAT</b><br/><br/> Location code must start with <b>F</b> and must be <b>5</b> characters long<br/><hr />
												You entered location starting with <b>'+left(@new_club,1)+'</b> and is <b>'+cast(len(@new_club) as varchar(10))+'</b> characters long.<br/><br/>'
			else 
				begin
					
					-- current club loction
					declare @club_c varchar(50)
					declare @wall_c varchar(50)
					declare @library_c varchar(50)	
					declare @provenance_c varchar(100)						
					select	 @club_c = isnull(dbo.fnGetPiece(provenance, 1, '~', ''),'')
							,@wall_c = isnull(dbo.fnGetPiece(provenance, 2, '~', ''),'')
							,@library_c = isnull(dbo.fnGetPiece(provenance, 3, '~', ''),'')
						,@provenance_c = isnull(provenance,'')
						from wine_entry with (nolock) where wine_entry_id = @club_wine_entry_id

					if @club_c <> @new_club
						set @new_provenance_c = @new_club+'~'+@wall_c+'~'+@library_c+'~'
						exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

 					if @club_c <> @new_club
						begin
							-- update
							exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
								,@club_wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
								,@provenance = @new_provenance_c
							
							-- If we have an error
 							if isnull(@output_message,'') <> ''
								select @alert_message = 'Error:' + @output_message
						end
				end
		    
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Location has been updated.<br/><br/>Old Loction: '+ @club_c + '<br/>New Location: ' + @new_club
					if @new_club = @club_c
						select @alert_message = 'Location is same, no changes made.'
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'edit-club-loc', @object_name, 'info', null, null, null, @alert_message

	end

	-- jf 2019-03-19 - edit wall loction
	else if @xproc = 'edit-wall-location'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			declare @wall_wine_entry_id varchar(20) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @new_wall varchar(20) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @new_provenance_w varchar(100)
			-- alert message
			select @alert_message = ''
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> '67'
					begin
						-- set error message
						select @alert_message = 'This wine does not belong to your brand.'
						exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
						exec st_audit_hdr  @user_id, @settings, 'edit-club-loc', @object_name, 'error', null, null, null, @alert_message
					end
			else if isnull(@access,'') not in ('M','A','W') --or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_WALL_LOC','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wall_wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@wall_wine_entry_id,'')


			else if (left(@new_wall,1) <> 'G' or len(@new_wall) <> 4) and @new_wall <> ''
				select @alert_message = '<b>WRONG FORMAT</b><br/><br/> Location code must start with <b>G</b> and must be <b>4</b> characters long<br/><hr />
												You entered location starting with <b>'+left(@new_wall,1)+'</b> and is <b>'+cast(len(@new_wall) as varchar(10))+'</b> characters long.<br/><br/>'
			else 
				begin
					
			-- current club loction
			declare @club_w varchar(50)
			declare @wall_w varchar(50)
			declare @library_w varchar(50)	
			declare @provenance_w varchar(100)						
			select	 @club_w = isnull(dbo.fnGetPiece(provenance, 1, '~', ''),'')
					,@wall_w = isnull(dbo.fnGetPiece(provenance, 2, '~', ''),'')
					,@library_w = isnull(dbo.fnGetPiece(provenance, 3, '~', ''),'')
                ,@provenance_w = isnull(provenance,'')
                from wine_entry with (nolock) where wine_entry_id = @wall_wine_entry_id

          if @wall_w <> @new_wall
			set @new_provenance_w = @club_w+'~'+@new_wall+'~'+@library_w+'~'
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

 			if @wall_w <> @new_wall
				begin
					-- update
					exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
						,@wall_wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
						,@provenance = @new_provenance_w
							
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end



		        end

			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Location has been updated.<br/><br/>Old Loction: '+ @wall_w + '<br/>New Location: ' + @new_wall
					if @new_wall = @wall_w
						select @alert_message = 'Location is same, no changes made.'
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'edit-wall-loc', @object_name, 'info', null, null, null, @alert_message

	end


	
	-- jf 2019-03-19 - edit library loction
	else if @xproc = 'edit-library-location'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			declare @library_wine_entry_id varchar(20) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @new_library varchar(20) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @new_provenance_l varchar(100)
			-- alert message
			select @alert_message = ''
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> '67'
					begin
						-- set error message
						select @alert_message = 'This wine does not belong to your brand.'
						exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
						exec st_audit_hdr  @user_id, @settings, 'edit-club-loc', @object_name, 'error', null, null, null, @alert_message
					end
			else if isnull(@access,'') not in ('M','A','W') --or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_EDIT_LIBRARY_LOC','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@library_wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@library_wine_entry_id,'')


			else if (left(@new_library,1) not in ('C','W','R') or len(@new_library) <> 6) and @new_library <> ''
				select @alert_message = '<b>WRONG FORMAT</b><br/><br/> Location code must start with <b>C</b> or <b>W</b> or <b>R</b> and must be <b>6</b> characters long<br/><hr />
												You entered location starting with <b>'+left(@new_library,1)+'</b> and is <b>'+cast(len(@new_library) as varchar(10))+'</b> characters long.<br/><br/>'
			else 
				begin
					
			-- current club loction
			declare @club_l varchar(50)
			declare @wall_l varchar(50)
			declare @library_l varchar(50)	
			declare @provenance_l varchar(100)						
			select	 @club_l = isnull(dbo.fnGetPiece(provenance, 1, '~', ''),'')
					,@wall_l = isnull(dbo.fnGetPiece(provenance, 2, '~', ''),'')
					,@library_l = isnull(dbo.fnGetPiece(provenance, 3, '~', ''),'')
                ,@provenance_l = isnull(provenance,'')
                from wine_entry with (nolock) where wine_entry_id = @library_wine_entry_id

          if @library_l <> @new_library
			set @new_provenance_l = @club_l+'~'+@wall_l+'~'+@new_library+'~'
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

 			if @library_l <> @new_library
				begin
					-- update
					exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
						,@library_wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
						,@provenance = @new_provenance_l
							
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end



		        end

			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Location has been updated.<br/><br/>Old Loction: '+ @library_l + '<br/>New Location: ' + @new_library
					if @new_library = @library_l
						select @alert_message = 'Location is same, no changes made.'
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'edit-library-loc', @object_name, 'info', null, null, null, @alert_message

	end


	-- pv 2019-03-20 added change-warehouse-ref
	else if @xproc in ('change-warehouse-ref')
		begin
			-- get user_id and warehouse_ref
			declare @selected_user_id varchar(50) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @selected_org_id int--=try_cast( dbo.fnGetPiece(@xdata, 2, '~', '') as int)
			declare @warehouse_ref varchar(50) =  dbo.fnGetPiece(@xdata, 3, '~', '')
			-- default template
			select @alert_template = 'alert_message_html_danger'
			-- pv 2019-04-02 check for authorised users
			select @authorised = dbo.fnGetParameter(@user_id,@settings,'AUTHORISED_EDIT_LOCATION_ADMIN_USERS','')
			-- get users brand
			declare @selected_org_brand varchar(50), @selected_user_access varchar(5)
			select @selected_org_brand = brand_ref, @selected_org_id = u.organisation_id, @selected_user_access = u.access_level
			from [user] u with(nolock)
				join organisation o with(nolock) on u.organisation_id = o.organisation_id
			where u.[user_id] = @selected_user_id
			
			-- validate
			if (isnull(@authorised,'') <> '' and (','+isnull(@authorised,'')+',') not like ('%,'+ @alias+',%'))
				select @alert_message = 'You are not authorised to update locations (AUTHORISED_EDIT_LOCATION_ADMIN_USERS)'
			else if isnull(@selected_org_id,0)=0
				select @alert_message = 'Invalid organisation id: ' +  dbo.fnGetPiece(@xdata, 2, '~', '')
			else if isnull(@selected_org_brand,'')=''
				select @alert_message = 'Invalid brand for organisation id: ' +  dbo.fnGetPiece(@xdata, 2, '~', '')
			else if isnull(@admin_user,'') = 'Y'
				select @alert_message = 'You cannot change the default location when logged on as a user.(Admin Only)'
			else if @user_brand <> @selected_org_brand
				select @alert_message = 'You cannot edit users that don''t belong to your brand: ' + @user_brand +' - '+ @selected_org_brand	
			else if isnull(@warehouse_ref, '') = '' and @selected_user_access = 'U' 
				select @alert_message = 'Please select a default location.'
			
			else
				begin
					-- call update module to update org
					EXEC st_update_organisation  @user_id,@settings, 'X', @alert_message OUTPUT,
						@stamp = null,
						@organisation_id = @selected_org_id,
						@warehouse_ref = @warehouse_ref
						-- and update org
				end


			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Updated warehouse ref' 
					-- and display
					exec st_alert_message @selected_user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'user-name-change', @object_name, 'info', null, null, null, @alert_message
		end

	-- pv 2019-03-25 added trading preferences
	else if @xproc in ('change-trading-preferences')
		begin
			-- get user_id and warehouse_ref
			declare @default_delivery_option varchar(20) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @default_delivery_address varchar(20) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @matching_offer varchar(10) =  dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @inspection_request varchar(10) =  dbo.fnGetPiece(@xdata, 4, '~', '')
			declare @default_storage_address varchar(20) =  dbo.fnGetPiece(@xdata, 5, '~', '')
			declare @storage_account_name varchar(50) =  dbo.fnGetPiece(@xdata, 6, '~', '')
			-- set checkboxes value to yes or no
			if @matching_offer <> 'Y'
				select @matching_offer = 'N'
		
			if @inspection_request <> 'Y'
				select @inspection_request = 'N'
	

			-- default template
			select @alert_template = 'alert_message_html_danger'

			-- validate
			if isnull(@default_storage_address,'') = '' and isnull(@default_delivery_address, '') = ''
				select @alert_message = 'Please select a default storage or delivery address'
				
			else if isnull(@default_delivery_option, '') = ''
				select @alert_message = 'Please select default delivery option'

			else if isnull(@default_storage_address, '') <> '' and isnull(@storage_account_name,'') = ''
				select @alert_message = 'Please add your account name for the storage location'

			else if isnull(@default_storage_address, '') = '' and isnull(@default_delivery_option,'') = 'transfer'
				select @alert_message = 'Please select a default storage location'

			else if isnull(@default_delivery_address, '') = '' and isnull(@default_delivery_option,'') = 'delivery'
				select @alert_message = 'Please select a default delivery address'

			else
				begin
					-- call update module to update org
					EXEC st_update_organisation  @user_id,@settings, 'X', @alert_message OUTPUT,
						@stamp = null,
						@organisation_id = @user_org_id,
						@default_delivery_option = @default_delivery_option,
						@default_delivery_address = @default_delivery_address,
						@matching_offer = @matching_offer,
						@inspection_request = @inspection_request,
						@default_storage_address = @default_storage_address,
						@storage_account_name = @storage_account_name
						-- and update org
				end


			-- if errors
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Updated trading preferences' 
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
					
					-- trigger email event to send confirmation
					exec st_event @user_id, @settings, @sql_logging, null, 'TRADING_PREFERENCES_UPDATED'
					,@user_Id, 'N', null, null, null, null, null
					,'organisation_id', @user_org_id, 'organisation', 'dm_organisation'

				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'change-trading-preferences', @object_name, 'info', null, null, null, @alert_message
		end



	--jf 2019-03-26 call off wine for delivery
	else if @xproc like 'call-off-%'
		begin

			-- initialise
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			select @wine_entry_id = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
			select @basket_item_id = isnull(try_cast(dbo.fnGetPiece(@xdata, 2, '~', '') as int),'')
			select @quantity_cases = try_cast(dbo.fnGetPiece(@xdata, 3, '~', '') as int)
			select @quantity_bottles = try_cast(dbo.fnGetPiece(@xdata, 4, '~', '') as int)
			select @notes = try_cast(dbo.fnGetPiece(@xdata, 5, '~', '') as varchar(200))

			-- if we have a basket id and no wine entry id get it
			if isnull(@wine_entry_id,0) = 0 and isnull(@basket_item_id,0) > 0
				select @wine_entry_id = wine_entry_id from basket_item with (nolock) where basket_item_id = @basket_item_id

			-- Get wine entry org id
			declare @callof_user_org_id int
			declare @we_status varchar(50)
			select top 1 @callof_user_org_id = o.organisation_id,@we_status = we.[status]
			from wine_entry we with (nolock)
				left join cellar c with (nolock) on c.cellar_id = we.cellar_id
				left join organisation o with (nolock) on o.organisation_id = c.owner_id
			where we.wine_entry_id = @wine_entry_id

						
			-- check if valid wine entry id
			if isnull(@we_status,'') <> 'Active'
				select @alert_message = 'This is not a valid wine entry id: ' + cast(@wine_entry_id as varchar(10))
			-- check access
			else if isnull(@access,'') not in ('A','W','M') and (@callof_user_org_id <> @user_org_id)
				select @alert_message = 'You are not authorised to use this function.'

		
			-- now do updates
			declare @action_text varchar(100) = ''

			if @xproc = 'call-off-add'
				begin
					select @basket_id = null

					-- and insert basket
					exec st_insert_basket_item @user_id, @settings,	@sql_logging, @output_message output, 
						@basket_item_id=@basket_item_id output,
						@wine_entry_id=@wine_entry_id,
						@basket_type='CALLOFF',
						@quantity_cases=@quantity_cases,
						@quantity_bottles=@quantity_bottles,
						@notes=@notes
						
						--xproc=call-off-add&xdata=489360~~1~0~test~

						-- if not ok error
						if isnull(@output_message,'') <> ''
							select @alert_message = @output_message
						else
							select @action_text = 'Wine has been entered to the basket.'
				end

			else if @xproc = 'call-off-remove'
				begin
					exec st_insert_basket_item @user_id, @settings,	@sql_logging, @output_message output, 
						@basket_item_id=@basket_item_id,
						@wine_entry_id=null,
						@basket_type='CALLOFF',
						@quantity_cases=null,
						@quantity_bottles=null,
						@notes=null
					
					-- if not ok error
					if isnull(@output_message,'') <> ''
						select @alert_message = @output_message
					else
						select @action_text = 'Wine has been removed from your basket.'
				end

			else if @xproc = 'call-off-update'
				begin
					exec st_insert_basket_item @user_id, @settings,	@sql_logging, @output_message output, 
						@basket_item_id=@basket_item_id,
						@wine_entry_id=@wine_entry_id,
						@basket_type='CALLOFF',
						@quantity_cases=@quantity_cases,
						@quantity_bottles=@quantity_bottles,
						@notes=@notes
						
					-- if not ok error
					if isnull(@output_message,'') <> ''
						select @alert_message = @output_message
						else
							select @action_text = 'Wine request has been updated.'
				end
			
			-- check for error
			if isnull(@alert_message,'') <> ''
				begin
					-- set confirmation message
					exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'call-off', null, @xdata, null, @alert_message
				end
			else
				begin
					select @alert_message = @action_text
					if @action_text like '%removed%'
						select @alert_template = 'alert_message_html_warning'
					else
						select @alert_template = 'alert_message_html_success'
				end


			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template

		end

	--------------------------------------
	--dk 2019-04-04 save manual matches of wines from critic reviews 
					--(Tested using report: Critic review unmatched wines)
	else if @xproc like 'unmatched-critic-wines'
		begin
		
		--declare @tasting_id varchar(800) = dbo.fnGetPiece(@xdata, 1, '~', '')
		declare @critic_wine_desc varchar(800) = dbo.fnGetPiece(@xdata, 1, '~', '')
		declare @potential_wine_name varchar(800) = dbo.fnGetPiece(@xdata, 2, '~', '')	
		declare @before_tasting_update as int 
		declare @after_tasting_update as int 
		declare @winename as varchar(800) 
		declare @wo_wine_id as varchar(200) 
		declare @no_of_wine_names as varchar(20) 
		declare @number_of_changes_made as int 
		declare @allow_update_critic_wine as varchar(1) = 'N'

		if @access in ('A') or @access in ('M')
		begin
			set @allow_update_critic_wine = 'Y'
		end

		-- user must be A
		if @allow_update_critic_wine <> 'Y'
		begin
			set @allow_update_critic_wine = 'N'

			-- unauthorised access
			select @alert_message =  'You are NOT authorised to update critic wines. Please contact support.'				
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'unauthorised access', @object_name, 'error', null, null, null, @alert_message
		end


		if @allow_update_critic_wine = 'Y'

			begin

			exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields			


				-- Alert: if user doesn't enter a potential wine name to match with critic wine name
				--if isnull(@potential_wine_name,'') = ''
				--begin
				--	-- report error
				--	select @alert_message =  'ERROR: Please enter a wine name to match the critic wine name'
				--	exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
				--	-- and always record in audit trail
				--	exec st_audit_hdr  @user_id, @settings, 'wine match not entered', @object_name, 'error', null, null, null, @alert_message
				--end

				if isnull(@potential_wine_name,'') = ''
				-- If potential wine name is not entered by user, take potential wine name listed next to the critic wine name
				begin

					set @potential_wine_name = (select top 1 packaging from tasting_note_or_review (nolock)
					where critic_wine_desc = @critic_wine_desc)

					set @wo_wine_id = 
					(select top 1 w.wine_id from wine w (nolock) 
					where w.name = @potential_wine_name) 
			
				end
		
			set @winename = @potential_wine_name
			set @no_of_wine_names = (select count(1) from wine w (nolock) 
			where name = @winename and disabled = 0 and isnull(owner_Id,0) = 0)

				-- Alert: if user has not entered a valid wine name
				if isnull(@no_of_wine_names,'') = '0'
				begin
					-- report invalid wine match
					select @alert_message =  'ERROR: Please enter a VALID wine name to match the critic wine name. Wine name: '+isnull(@winename,'')
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
					-- and always record in audit trail
					exec st_audit_hdr  @user_id, @settings, 'invalid wine match', @object_name, 'error', null, null, null, @alert_message
				end 
			
				-- Get the wine id of the potential wine name (whether its a wine user entered or empty - default potential wine)
				set @wo_wine_id = 
				(select top 1 w.wine_id from wine w (nolock)
				 where w.name = @potential_wine_name )

					-- UPDATE all critic wine names that have the same name with the potential wine name
					update tr
					set tr.wine_id = @wo_wine_id , tr.updated = getdate()
													, tr.updated_by = @user_Id
													, tr.condition = ''
													, tr.packaging = ''
													, tr.provenance = ''
													, tr.condition_notes = ''
					from tasting_note_or_review tr
					where tr.critic_wine_desc = @critic_wine_desc and tr.wine_id is null
						and disabled = 0
						and isnull(owner_id,0) =0

			set @after_tasting_update = @@ROWCOUNT
			
			
				if @after_tasting_update = 1 
					begin
						select @alert_message =  'Wine update has been made.'				
						set @alert_template = 'alert_message_html_succss'
					end

		end
	end 



	------------------------------------
	--dk 2019-04-16 save info of possible wrong information of a specific wine
	else if @xproc like 'review-wine-issue'

	-- Currently on Test

	/* Content: M_WINE_LIST_LIST_ITEMS_AMC_STD (My Wines)
			  : M_WINE_LIST_LIST_ITEMS_FWE_AO (Fine Wine Exhange Page)
			  : M_WINE_LIST_LIST_ITEMS_AW_STD (All Wines Page)
		      : POPOVER_REVIEW_WINE_BASIC

		      Called in : [dm_wine_search_page] as @review_popup_basic
					      [dm_wine_search_page_local]

	*/
		begin

		-- CURRENTLY BEING USED FOR TESTING
		--select @alert_message =  'REVIEW WINE ISSUE'		

		-- Maintenance vars
		---- Change to Y or N to run or jump over
		declare @allow_review_wine_issue as varchar(1) = 'Y' -- CHANGE TO Y IF YOU WANT IT TO WORK
		declare @max_wine_issue_id as int
		declare @after_issue_review as int
		declare @wine_issue_id int = -1 -- create a new unique ID when passed to st_update_wine_issue

		-- input vars
		declare @review_wine_id varchar(800) = dbo.fnGetPiece(@xdata, 1, '~', '')
		declare @review_wine_name varchar(800) = dbo.fnGetPiece(@xdata, 2, '~', '')
		declare @review_vintage varchar(800) = dbo.fnGetPiece(@xdata, 3, '~', '')
		declare @review_comment varchar(2000) = dbo.fnGetPiece(@xdata, 4, '~', '')
		--declare @review_wine_entry_id varchar(10) = dbo.fnGetPiece(@xdata, 5, '~', '')
		declare @review_wine_entry_id int

		-- defined vars
		declare @current_market_price varchar(800) = ''
		declare @purchase_price varchar(800) = ''
		declare @review_comment_final as varchar(2000) = null
		declare @current_purchase_price int

		-- Collecting the current market and purchase price to store in the wine issue
		select @current_market_price = current_price from wine_vintage_price (nolock)
			where wine_id = @review_wine_id
			and vintage = @review_vintage
			and disabled = isnull(0,0)
			and region_ref = 'europe'
			and currency_ref = 'GBP'

		---- need to joining to wvp because it does not have a region
		--select @purchase_price = price from wine_entry we (nolock)
		--	where we.wine_entry_id = @review_wine_entry_id

		select @current_purchase_price = price from wine_entry 
		where wine_id = 2220956
		and vintage = 2003
		and currency_ref = 'GBP'
		and disabled = isnull(0,0)

		select @review_wine_entry_id = wine_entry_id from wine_entry 
		where wine_id = 2220956
		and vintage = 2003
		and currency_ref = 'GBP'
		and price = @current_purchase_price
		and disabled = isnull(0,0)

		--if isnull(@review_wine_entry_id, '') = '' (select top 1 wine_entry_id where wine_id = @review_wine_id)

		set @review_comment_final = 
			'Wine_name: ' + isnull(@review_wine_name, '')
			+ '---' + 'Comment: ' +isnull( @review_comment, '')
			+ '---' + 'Current Purchase Price (75cl) : '+ isnull(@purchase_price, '')
			+ '---' + 'Current Market Price (75cl) : '+ isnull(@current_market_price, '')
			

		if @access in ('A','M') 
			begin
				set @allow_review_wine_issue = @allow_review_wine_issue 
			end

		-- user must be A
		if @allow_review_wine_issue <> 'Y'
			begin
				set @allow_review_wine_issue = 'N'
			
					select @alert_message =  'You are NOT authorised to request a review for wine details. Please contact support.'				
					exec st_audit_hdr  @user_id, @settings, 'unauthorised access', @object_name, 'error', null, null, null, @alert_message
			end

		-- Alert: Tell user to enter a comment and nothing was saved
		if @review_comment = ''
			begin

				select @alert_message =  'Please enter a comment. No information saved for this wine issue'				
				set @alert_template = 'alert_message_html_danger'
				exec st_audit_hdr  @user_id, @settings, 'empty comment box', @object_name, 'error', null, null, null, @alert_message
		
				set @allow_review_wine_issue = 'N'
			end
	

		if @allow_review_wine_issue = 'Y'
			begin
				exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields
			
				exec st_update_wine_issue  @user_id, @settings, 'X', @output_msg OUTPUT,
					@output_type OUTPUT,
					@wine_issue_id OUTPUT,
					0,		--@stamp int,			 -- record update stamp  - optional passed in for updates
					'',		--@options varchar(50),  -- generic purposes
				
					@wine_id = @review_wine_id,
					@vintage = @review_vintage,
					@wine_entry_id = @review_wine_entry_id,
					@issue_ref = 'Admin Comments',
					@comments = @review_comment_final

				print 'output msg: '+@output_msg
				print 'table id: '+isnull(cast(@wine_issue_id as varchar(50)),'')
				select @after_issue_review = COUNT(1) from wine_issue where wine_issue_id = @wine_issue_id

				if @after_issue_review = 1 
					begin

						-- Only used for debugging
						--select @alert_message = 
						--	'@review_wine_id: ' + @review_wine_id + 
						--	' @review_wine_name: ' + @review_wine_name + 
						--	' @review_vintage: ' + @review_vintage + 
						--	' @review_comment: ' + @review_comment + 
						--	' @review_wine_entry_id: ' + @review_wine_entry_id 
								
						--select @alert_message =  'Your comment is saved.'				
						set @alert_template = 'alert_message_html_succss'
					end
			end

			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
	end 


	-- wv 2019-04-26 complete container for warehouses where there is NO warehouse locations (so there is NO put away)
	else if @xproc = 'complete-container'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get container id 
			select @cont_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''

			-- get basic data
			declare @cont_brand_ref varchar(10)
			declare @cont_cellar_id int
			-- get data, incl. default cellar id for this organisation AND location
			select @cont_brand_ref = o.brand_ref, @cont_cellar_id=dbo.fnDefaultCellar(@user_id, @settings, c.organisation_id, 'LOCATION:'+isnull(c.warehouse_ref,''))
				from container c with (nolock) 
					join organisation o with (nolock) on o.organisation_id = c.organisation_id 
			where container_id = try_cast(@cont_id as int)

			-- first check container id
			if isnumeric(@cont_id) <> 1
				select @alert_message = 'This container id is not numeric: ' + isnull(@cont_id,'')
			else if (select count(1) from container c with (nolock)	where container_id = @cont_id ) = 0
				select @alert_message = 'This container id does not exist: ' + isnull(@cont_id,'')
			else if (@cont_brand_ref <> @user_brand)
				select @alert_message = 'This container id does belong to your clients: ' + isnull(@cont_id,'')
			-- check if there are any wine entries
			else if (select count(1) from wine_entry with (nolock) where container_id = try_cast(@cont_id as int) and isnull([disabled],0)=0) = 0
				select @alert_message = 'This container does not contain any wine entries. Container id: ' + isnull(@cont_id,'')
			-- and must have status Submitted (P)  or Processing  (L)
			else if isnull((select [status] from container c with (nolock) where container_id = @cont_id ),'') not in ('P','L')
				select @alert_message = 'This container does not have the correct statys, status should be Submitted or Processing (P or L) but status is: '
						+ isnull((select [status] from container c with (nolock) where container_id = @cont_id ),'')

			-- check if user is authorised								
			else if isnull(@access,'') not in ('M','A','W') or ((','+dbo.fnGetParameter(@user_id, @settings, 'AUTHORISED_USERS_CONTAINER_LANDED','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function. (Parameter AUTHORISED_USERS_CONTAINER_LANDED)'

			else 
				begin

					-- use default cellar id for this organisation and (container) location 
					update we 
						set [status]='Active', cellar_id = @cont_cellar_id, updated = getdate(),updated_by=@user_id
					from wine_entry we
					where we.container_id = try_cast(@cont_id as int) 
						and isnull(we.[disabled],0) = 0
						and [status] = 'Landed'
					-- count of records updated
					select @count = @@rowcount

					-- and update mixed case to same cellar id
					update mc
						set mc.cellar_id = @cont_cellar_id, mc.updated = getdate(),mc.updated_by=@user_id
					from mixed_case mc
						join wine_entry we on we.mixed_case_id = mc.mixed_case_id
					where we.container_id = try_cast(@cont_id as int) 
						and mc.cellar_id <> @cont_cellar_id
					-- at the moment dont count

					-- can NOT use check container because that uses warehouse locations
					-- exec st_check_container_status @user_id,  @settings, @sql_logging, @con_msg OUTPUT, @container_id, null, @options
					-- so just update container to completed
					update container
						set [status] = 'C', updated = getdate(), updated_by=@user_id
							,actual_arrival_date = isnull(actual_arrival_date,cast(getdate() as date))
					where container_id = @cont_id

				end

			-- if we had an error
			if isnull(@alert_message,'') <> ''
				begin
					-- set confirmation message
					exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'error', null, @xdata, null, @alert_message
				end
			else
				begin
					-- update messages
					select @alert_message = 'Completed container. Updated ' + isnull(cast(@count as varchar(10)),'') +' wine entries to status Active and moved into the correct cellar'
					select @alert_template = 'alert_message_html_success'
					-- record completed
					exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'completed', null, @cont_id, null, @alert_message
				end

			-- display message or error
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template


		end

		--dk 2019-05-01 update the organisation table if billing options are changed for a client
		else if @xproc in ('apply-billing-organisation')

			--check all alert messages
			begin
				-- check we have a valid organisation id
				declare @apply_billing_org_id int = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
				declare @apply_billing_flag varchar(1) = dbo.fnGetPiece(@xdata, 2, '~', '')
				select @alert_template = 'alert_message_html_danger'

				-- if not valid
				if isnull(@apply_billing_org_id,0) = 0 
					select @alert_message = 'This is not a valid organisation number: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
				-- check if its valid and for current brand
				select @record_brand = brand_ref from organisation with (nolock)
					where organisation_id = @apply_billing_org_id
				-- must be for valid
				if isnull(@record_brand,'') = ''
					select @alert_message = 'This is not a valid organisation: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
				-- and for correct brand
				else if isnull(@record_brand,'') <> @user_brand
					select @alert_message = 'This organisation does not belong to your brand: ' + isnull(@user_brand,'')
				else if isnull(@apply_billing_flag,'') not in ('','Y','N')
					select @alert_message = 'This is not a valid apply billing. enter Y or N ' + isnull(@apply_billing_flag,'')
				else
					begin
						-- do update in organisation
						-- for applying different billing status for client
						EXEC st_update_organisation  @user_id, @settings, @sql_logging, @alert_message OUTPUT
							,@organisation_id = @apply_billing_org_id
							,@stamp = null  		-- record update stamp  - optional passed in for updates
							,@apply_billing = @apply_billing_flag
							,@options = 'NOALERTMESSAGE'
					end
				
				-- if no errors
				if isnull(@alert_message,'') = ''
					begin
						select @alert_template = 'alert_message_html_success'
						-- if value blank 
						select @alert_message = 'Updated apply billing flag: ' + @apply_billing_flag
					end
				-- and give message
				exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				-- and always record in audit trail
				exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, 'info', null, null, null, @alert_message

			end


	-- jf 2019-05-05 - freeze stock (wine entry)
	--	xproc=freeze-stock&xdata=409227
			

	else if @xproc = 'freeze-stock'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_entry_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
			select @record_brand = ''
			select @cur_suspended_status = ''	
							
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_suspended_status = we.suspended_status
			from wine_entry we with (nolock)
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
			where wine_entry_id = @wine_entry_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
			
			else if isnull(@admin_user,'') <> 'Y' and isnull(@access,'') not in ('M','W','A')
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@wine_entry_id,'')
			else if isnull(@cur_suspended_status,'') in ('F', 'L') 
				select @alert_message = 'You cannot freeze this wine entry as current status is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'SuspendedStatus', @cur_suspended_status, @cur_suspended_status)
			else 
				begin
				
					-- update
					exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
						,@wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
						,@suspended_status = 'F'
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine Entry status has been changed to Frozen.'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'freeze-stock', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end

			

	-- jf 2019-05-05 - un-freeze stock (wine entry)
	--	xproc=un-freeze-stock&xdata=356537
			

	else if @xproc = 'un-freeze-stock'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_entry_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
			select @record_brand = ''
			select @cur_suspended_status = ''	
							
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_suspended_status = we.suspended_status
			from wine_entry we with (nolock)
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
			where wine_entry_id = @wine_entry_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
			
			else if isnull(@admin_user,'') <> 'Y' and isnull(@access,'') not in ('M','W','A')
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@wine_entry_id,'')
			else if isnull(@cur_suspended_status,'') not in ('F', 'L') 
				select @alert_message = 'You cannot un-freeze this wine entry'
			else 
				begin
				
					-- update
					exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
						,@wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
						,@suspended_status = ''
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine Entry status has been changed to Active.'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'un-freeze-stock', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end


	-- jf 2019-05-07 - lost stock (wine entry)
	--	xproc=lost-stock&xdata=415622
			

	else if @xproc = 'lost-stock'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_entry_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			select @loc_key = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_LOST_LOCATION','')
			
			select @record_brand = ''
			select @cur_suspended_status = ''	
							
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_suspended_status = we.suspended_status, @barcode = we.we_barcode
			from wine_entry we with (nolock)
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
			where wine_entry_id = @wine_entry_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
			
			else if isnull(@admin_user,'') <> 'Y' and isnull(@access,'') not in ('M','W','A')
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(@wine_entry_id,'')
			else if isnull(@cur_suspended_status,'') in ('F', 'L') 
				select @alert_message = 'You cannot declare this wine entry as lost as current status is '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'SuspendedStatus', @cur_suspended_status, @cur_suspended_status)
			else 
				begin
				
					-- update
					exec st_update_wine_entry @user_id, @settings, @sql_logging, @output_message OUTPUT, @output_type OUTPUT
						,@wine_entry_id, 0, 'NOTRANSACTION~NOALERTMESSAGE'
						,@suspended_status = 'L'
					if dbo.fnGetParameter(@user_id,@settings,'QUARANTINE_WHEN_LOST','') = 'Y'
						exec st_wine_move @user_id, @settings, @sql_logging, @output_message OUTPUT, 'move-case', @loc_key, @barcode, @options
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine Entry status has been changed to Lost'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'lost-stock', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end

	-- jf 2019-05-18 - resolve wine issue (change wine issue status to C - completed)
	--	xproc=resolve-issue&xdata=468
			

	else if @xproc = 'resolve-issue'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_issue_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
			select @record_brand = ''
			declare @cur_issue_status varchar(10) = ''	
							
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_issue_status = wi.status
			from wine_issue wi with (nolock)
				join wine_entry we with (nolock) on we.wine_entry_id  = wi.wine_entry_id
				join cellar c with (nolock) on c.cellar_id = we.cellar_id
				join organisation o with (nolock) on o.organisation_id = c.owner_id
			where wine_issue_id = @wine_issue_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
			
			else if isnull(@access,'') not in ('M','A','W') or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_RESOLVE_ISSUE','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_issue_id) <> 1 
				select @alert_message = 'Wine Issue ID is not numeric, value is: ' + isnull(@wine_entry_id,'')
			else if isnull(@cur_issue_status,'O') = 'C' 
				select @alert_message = 'You cannot resolve this issue as it is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'WineIssueStatus', @cur_suspended_status, @cur_suspended_status)
			else 
				begin
				
					-- update
					exec st_update_wine_issue @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_issue_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'C'
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine Issue has been Resolved.'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'resolve-issue', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end




	-- jf 2019-05-18 - complete contact request (change contact status to C - completed)
	--	xproc=complete-contact&xdata=30
			

	else if @xproc = 'complete-contact'
		
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''
			declare @contact_id int

			-- get wine entry id and location
			select @contact_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
			select @record_brand = ''
			declare @cur_contact_status varchar(10) = ''	
							
			-- and retrieve
			select @record_brand = o.brand_ref, @cur_contact_status = c.[status]
			from contact c with (nolock)
				join organisation o with (nolock) on o.organisation_id = c.organisation_id
			where contact_id = @contact_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This user does not belong to your brand.'
					
			
			else if isnull(@access,'') not in ('M','A','W') --or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_RESOLVE_ISSUE','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@contact_id) <> 1 
				select @alert_message = 'Contact ID is not numeric, value is: ' + isnull(@wine_entry_id,'')
			else if isnull(@cur_contact_status,'O') = 'C' 
				select @alert_message = 'You cannot complete this contact request as it is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'ContactStatus', @cur_contact_status, @cur_contact_status)
			else 
				begin
				
					-- update
					exec st_update_contact @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @contact_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'C'
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Client has been contacted.'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'complete-contact', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end



	--jf 2019-06-04 Submit stock take
	--	xproc=submit-stock-take&xdata=2084
	else if @xproc like '%-stock-take'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_stock_take_header_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
			select @record_brand = ''
			declare @cur_wsth_status varchar(10) = ''	
							
			-- and retrieve
			select @record_brand = wsth.brand_ref, @cur_wsth_status = wsth.[status]
			from wine_stock_take_header wsth with (nolock)
				where wine_stock_take_header_id = @wine_stock_take_header_id
				
			declare @tmp_msg_unsubmit varchar(500) = dbo.fnValidateAuthorisationAndBrand(@user_id,@settings,'USERS_ALLOWED_TO_UNSUBMIT_STOCKTAKE',@record_brand,'','','','','','')
			declare @tmp_msg_complete varchar(500) = dbo.fnValidateAuthorisationAndBrand(@user_id,@settings,'USERS_ALLOWED_TO_COMPLETE_STOCKTAKE',@record_brand,'','','','','','')
			declare @tmp_msg_cancel varchar(500) = dbo.fnValidateAuthorisationAndBrand(@user_id,@settings,'USERS_ALLOWED_TO_CANCEL_STOCKTAKE',@record_brand,'','','','','','')

								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This stock take does not belong to your brand.'
					
			
			
			


			else if isnull(@access,'') not in ('M','A','W') --or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_TO_SUBMIT_STOCK_TAKE','')+',') not like ('%,'+@alias+',%'))
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_stock_take_header_id) <> 1 
				select @alert_message = 'Wine Stock Take Header ID is not numeric, value is: ' + isnull(@wine_stock_take_header_id,'')
			else if isnull(@cur_wsth_status,'P') not in ('P','R') and @xproc = 'submit-stock-take'
				select @alert_message = 'You cannot submit this stock take as it is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'StockTakeStatus', @cur_wsth_status, @cur_wsth_status)
			else if isnull(@cur_wsth_status,'P') <> 'O' and @xproc = 'un-submit-stock-take'
				select @alert_message = 'You cannot reset this stock take to pending as it is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'StockTakeStatus', @cur_wsth_status, @cur_wsth_status)
			else if isnull(@cur_wsth_status,'P') <> 'O' and @xproc = 'complete-stock-take' 
				select @alert_message = 'You cannot complete this stock as it is still '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'StockTakeStatus', @cur_wsth_status, @cur_wsth_status)
			else if isnull(@cur_wsth_status,'P') = 'C' and @xproc = 'cancel-stock-take' 
				select @alert_message = 'You cannot cancel this stock take as it is already '+dbo.fnGetLookupDescriptionDefault(@user_id, @settings, 'StockTakeStatus', @cur_wsth_status, @cur_wsth_status)
			else 
				begin
				
					-- update
					if @xproc = 'submit-stock-take' 
						begin
							if @cur_wsth_status = 'P'
								begin
									exec st_create_wine_stock_take_reconciliation @user_id,@settings, 'X', @output_msg OUTPUT, @wine_stock_take_header_id=@wine_stock_take_header_id, @stamp = 1							
									exec st_update_wine_stock_take_header @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_stock_take_header_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'O', @submitted = @submitted_date, @submitted_by = @user_id
								end
							else if  @cur_wsth_status = 'R'
								begin
									exec st_create_wine_stock_take_reconciliation @user_id,@settings, 'X', @output_msg OUTPUT, @wine_stock_take_header_id=@wine_stock_take_header_id, @stamp = 1
									exec st_update_wine_stock_take_header @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_stock_take_header_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'O'
								end
						end
					else if @xproc = 'un-submit-stock-take'
						begin
							if isnull(@tmp_msg_unsubmit,'') <> ''
								select @alert_message= @tmp_msg_unsubmit
							else
								begin
									exec st_update_wine_stock_take_header @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_stock_take_header_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'R'
									EXEC st_create_wine_stock_take_reconciliation @user_id,@settings, 'X', @output_msg OUTPUT, @wine_stock_take_header_id=@wine_stock_take_header_id, @stamp = 1, @options = 'disable'
								end
						end

					else if @xproc = 'complete-stock-take'
						begin
							if isnull(@tmp_msg_complete,'') <> ''
								select @alert_message= @tmp_msg_complete
								else exec st_update_wine_stock_take_header @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_stock_take_header_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'C', @completed = @completed_date, @completed_by = @user_id
						end

					else if @xproc = 'cancel-stock-take'
						begin
							if isnull(@tmp_msg_cancel,'') <> ''
								select @alert_message= @tmp_msg_cancel
								else exec st_update_wine_stock_take_header @user_id, @settings, 'X', @outp_msg OUTPUT, @outp_type OUTPUT, @wine_stock_take_header_id, 0, 'NOTRANSACTION~NOALERTMESSAGE', @status = 'X'
						end

					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					
					-- if value blank its remove
					if @xproc = 'submit-stock-take'
						select @alert_template = 'alert_message_html_success'
							  ,@alert_message = 'Stock take has been Submitted.'
						      ,@audit_action = 'updated'

					if @xproc = 'un-submit-stock-take'
						select @alert_template = 'alert_message_html_warning'
						      ,@alert_message = 'Stock take has been reseted to pending.'
						      ,@audit_action = 'updated'

					if @xproc = 'complete-stock-take'
						select @alert_template = 'alert_message_html_success'
						      ,@alert_message = 'Stock take has been completed.'
						      ,@audit_action = 'completed'

					if @xproc = 'cancel-stock-take'
						select @alert_template = 'alert_message_html_danger'
						      ,@alert_message = 'Stock take has been canceled.'
						      ,@audit_action = 'canceled'
					
					
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, @xproc, @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end


	else if @xproc like 'stock-reconciliation-move'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @barcode = dbo.fnGetPiece(@xdata, 1, '~', '')
			select @loc_key = dbo.fnGetPiece(@xdata, 2, '~', '')
			
			
			--select @loc_key = dbo.fnGetParameter(@user_id,@settings,'DEFAULT_LOST_LOCATION','')

			-- alert message and brand
			select @alert_message = ''
			select @record_brand = ''
			
							
			-- and retrieve
			select @record_brand = wm.brand_ref--, @barcode = we.we_barcode
			from warehouse_location wl with (nolock)
				join warehouse_map wm with (nolock) on wm.warehouse_map_id = wl.warehouse_map_id
			where wl.barcode = @barcode
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
			
			 if isnull(@admin_user,'') <> 'Y' and isnull(@access,'') not in ('M','W','A')
          		select @alert_message = 'You are not authorised to use this function.'
			
			else 
				begin
				
					-- update
					exec st_wine_move @user_id, @settings, @sql_logging, @output_message OUTPUT, 'move-case', @loc_key, @barcode, @options
											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Location has been updated'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'stock-take-update-location', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end

	-- jf 2019-06-16 - staff request wine
	-- xproc=cellar-request-wine&xdata=124094~jf90~1~test test test~today
	else if @xproc = 'cellar-request-wine'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @wine_entry_id  = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @passcode varchar(10) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @quantity varchar(10) = dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @comment varchar(100) = dbo.fnGetPiece(@xdata, 4, '~', '')
			declare @date varchar(30)
			
			select @date = case when dbo.fnGetPiece(@xdata, 5, '~', '') = 'today' then cast(getdate() as datetime) when dbo.fnGetPiece(@xdata, 5, '~', '') = 'tomorrow' then cast(dateadd(dd, +1, getdate()) as datetime) end
			
			-- get passcode data
			declare @passcode_reference varchar(100)
			declare @passcode_name varchar(100)
			select @passcode_reference = reference,@passcode_name = dbo.fnXMLText([description],0,'','en')
				from [lookup] with (nolock)
			where category='passcode' 
				and lookup_field_1 = @passcode
				and isnull([disabled],0) = 0
				-- should take account of brand here, in here we have auserid but not if called from menu list
				-- passcode is only used by 67 at the moment
				-- brand_ref= @user_brand


			-- alert message
			select @alert_message = ''			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> '67'
					begin
						-- set error message
						select @alert_message = 'This wine does not belong to your brand.'
						exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
						exec st_audit_hdr  @user_id, @settings, 'cellar-request-wine', @object_name, 'error', null, null, null, @alert_message
					end
			else if isnull(@access,'') not in ('M','A','W') 
          		select @alert_message = 'You are not authorised to use this function.'
			else if isnumeric(@wine_entry_id) <> 1 
				select @alert_message = 'Wine entry is not numeric, value is: ' + isnull(cast(@wine_entry_id as varchar(10)),'')
			else if isnull(try_cast(@quantity as int),0) = 0 
				select @alert_message = 'Error, quantity is not numeric. (must be 1 or greater)'
			else if isnull(cast(@date as varchar(20)),'') = '' 
				select @alert_message = 'You must to specify date'
			else if isnull(@passcode_reference, '') = ''
					select @alert_message = 'Access denied. (Invalid passcode)'

			else 
				begin
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 30000, @alert_template
					-- update
					exec st_m_request_wine_ws @user_id, @settings, 'Y', null, null, @wine_entry_id, 'Y', null, '', @passcode, 'cellar', @quantity, @comment, null, @date
							
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
			
		        end

			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Wine has been requested'
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'cellar-request-wine', @object_name, 'info', null, null, null, @alert_message

		end

	-- wv 2019-06-18  Edit transfer status date
	-- xproc=acc-transfer-bank-date&xdata=1234~date    -- 1234  = acc_transfer_id
	else if @xproc = 'acc-transfer-bank-date'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			declare @acc_transfer_id int = try_cast(dbo.fnGetPiece(@xdata, 1, '~', '') as int)
			declare @acc_status_date varchar(10) = try_cast(dbo.fnGetPiece(@xdata, 2, '~', '') as date)
			
			-- alert message
			select @alert_message = ''			
								
			-- ONLY allowed if user is WO admin
			if isnull(@access,'') not in ('W','A') 
          		select @alert_message = 'You are not authorised to use this function. (WO admin only)'
			else if isnull(@acc_transfer_id,0) = 0 
				select @alert_message = 'Transfer id is not numeric, value is: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			else if isnull( (select count(1) from acc_transfer with (nolock) where acc_transfer_id = @acc_transfer_id),0) = 0 
				select @alert_message = 'Transfer id is not valid, value is: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			else if @acc_status_date is null 
				select @alert_message = 'Bank date is not a valid date, value is: ' + isnull(dbo.fnGetPiece(@xdata, 2, '~', ''),'')

			else 
				begin
					-- take copy of current record
					insert into audit_acc_transfer
					select * from acc_transfer where acc_transfer_id = @acc_transfer_id
					-- update transfer
					update acc_transfer
						set status_date=@acc_status_date,updated=getdate(), updated_by=@user_id
					where acc_transfer_id = @acc_transfer_id			
		        end

			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Transfer request date has been updated for transfer: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
					-- and display
					exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'acc-transfer-change-date', @object_name, 'info', null, null, null, @alert_message

		end

	-- wv 2019-06-20 added consignment bid Insert, amend OR delete
	else if @xproc in ('consignment-bid-insert','consignment-bid-amend','consignment-bid-delete')
		begin

			-- call out
			exec dm_m_proc_wine_consignment_bid  @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page

		end
	-- pv 2019-07-04 added update wine consignment for match bid
	else if @xproc in ('wine-consignment-update', 'wine-consignment-match-bid')
		begin

			-- call out
			exec dm_m_proc_wine_consignment_update  @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page

		end


	-- jf 2019-07-02 - complete container
	--	xproc=receive-container&xdata=490
	else if @xproc = 'receive-container'
		begin
			-- default template to danger
			select @alert_template = 'alert_message_html_danger'
			select @alert_message = ''

			-- get wine entry id and location
			select @container_id = dbo.fnGetPiece(@xdata, 1, '~', '')
			-- alert message
			select @alert_message = ''
			
										
			-- and retrieve
			select @record_brand = o.brand_ref
			from container c with (nolock)
				join organisation o with (nolock) on o.organisation_id = c.organisation_id
			where c.container_id = @container_id
				
			
								
			-- ONLY allowed if merchant user
			if isnull(@user_brand,'') <> @record_brand
				-- set error message
				select @alert_message = 'This wine does not belong to your brand.'
					
				-- Check access via standard function
			-- this includes access level, brand match and location
			select @tmp_msg = dbo.fnValidateAuthorisationAndBrand(@user_id,@settings,'USERS_ALLOWED_TO_RECEIVE_CONTAINER',@record_brand,'','','','','','')
		
			-- 	and other checks
			if isnull(@container_id,0) = 0
				select @alert_message = 'Container ID is not numeric, Container ID: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- or doesnt exist
			else if isnull(@record_brand,'') = ''
				select @alert_message = 'This container ID does not exist, Container ID: ' + isnull(dbo.fnGetPiece(@xdata, 1, '~', ''),'')
			-- must be admin access and authorised - use function, also check record brand
			else if isnull(@tmp_msg,'') <> ''
				select @alert_message = @tmp_msg

			else 
				begin
				
					-- update
					exec [dbo].[wo_receive_container] @user_id, @settings, 'X', '', '', @container_id

											
					-- If we have an error
 					if isnull(@output_message,'') <> ''
						select @alert_message = 'Error:' + @output_message
				end
			
			-- check for error
			if isnull(@alert_message,'') = ''
				begin
					select @alert_template = 'alert_message_html_success'
					-- if value blank its remove
					select @alert_message = 'Container has been received.'
					select @audit_action = 'updated'
					
				end
			else
				begin
					-- otherwise return as error message
					select @output_message = @alert_message
					select @audit_action = 'error'
				end
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'receive-container', @object_name, @audit_action, null, null, null, @alert_message
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 20000, @alert_template

	end


	--jf 2019-07-15 remove bid or offer
	else if @xproc in ('trading-bid-remove', 'trading-offer-remove')
		begin

			-- call out
			exec dm_m_proc_trading_remove  @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page

		end

	--pv 2019-07-23 used to add users to permission parameters
	else if @xproc = 'update-parameter-permissions'
		begin
			-- call out
			exec dm_m_proc_update_parameter_permissions  @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end


	-- wv 2019-07-26  Edit transfer organisation
	-- xproc=acc-transfer-bank-date&xdata=1234~date    -- 1234  = acc_transfer_id
	else if @xproc = 'acc-transfer-bank-organisation'
		begin
			-- call out
			exec dm_m_proc_transfer_organisation  @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end

	-- pv 2019-08-05  add bank details to organisation
	else if @xproc = 'add-bank-details'
		begin
			-- call out
			exec dm_m_proc_bank_details @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end


	-- pv 2019-08-07  add new address for trading preferences
	else if @xproc = 'new-delivery-address'
		begin
			-- call out
			exec dm_m_proc_new_delivery_address @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end


	-- mb 2019-08-02  Copy content to brands
	-- xproc=copy-content-to-brands&xdata=brand~content_key~user_access~brands   -- brands are comma separated
	else if @xproc = 'copy-content-to-brands'
		begin
			declare @copy_content_brand varchar(10) = dbo.fnGetPiece(@xdata, 1, '~', '')
			declare @copy_content_key varchar(10) = dbo.fnGetPiece(@xdata, 2, '~', '')
			declare @copy_content_user_access varchar(10) = dbo.fnGetPiece(@xdata, 3, '~', '')
			declare @copy_content_brands varchar(10) = dbo.fnGetPiece(@xdata, 4, '~', '')

			exec [dbo].[wo_copy_content_to_brands] @user_id, @settings, @sql_logging, @output_message output, 
				@copy_content_brand, @copy_content_key, @copy_content_user_access, @copy_content_brands

		end

	-- jf 2019-08-09  update passport details
	--xproc=passport-update&xdata=174842~OWC~pristine~5cm~good~
	else if @xproc = 'passport-update'
		begin
			-- call out
			exec dm_m_proc_passport_update @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end

	-- jf 2019-08-13  renew/discard expired bid
	--xproc=renew-bid&xdata=32655~
	else if @xproc = 'renew-bid'
		begin
			-- call out
			exec dm_m_proc_renew_bid @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end


	-- pv 2019-08-15 reorder item (add item back to basket)
	else if @xproc = 'reorder-basket-item'
		begin
			-- call out
			exec dm_m_proc_reorder_basket_item @user_id, @settings, @sql_logging, @output_message output
					,@xdata, @xproc, @user_org_id, @access
					,@user_brand, @admin_user, @options, @redirect_page
		end
				

	-- ==============================  Invalid code --------------------------------------
	else
		begin
			-- invalid process code
			select @alert_message = 'Invalid process code: ' + isnull(@xproc,'')
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message
			-- and always record in audit trail
			exec st_audit_hdr  @user_id, @settings, 'process', @object_name, 'error', null, null, null, @alert_message
		end

end try


begin catch
	-- actual SQL error trapping
	declare @error_str varchar(1000) = 'Processing: ' + isnull(@xproc,'') + ' SQL error: '+isnull(ERROR_PROCEDURE(),'') + '  Ln: '
		+ cast(isnull(ERROR_LINE(),'') as varchar(10)) +'  Msg: '+isnull(ERROR_MESSAGE(),'')
	
	select @audit_exception = @error_str
	-- add @input_fields
	begin try
		select @audit_exception = @audit_exception + '  Input: ' + @input_fields
	end try
	begin catch
		-- no action required
	end catch
	
	-- insert into audit trail
	exec st_audit @user_id, @settings, @object_name, @transaction_name, 'error', @audit_exception

	select @alert_message = 'Your request could not be processed: ' + @error_str
	-- and display
	exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message, null, 10000, 'alert_message_html_danger'

end catch

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_issues_week_prior]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_issues_week_prior]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[dm_issues_week_prior]
	
	@user_id int,					
	@settings varchar(500) ='',		
	@sql_logging varchar(1) ='X',	
	@output_message as varchar(max) OUTPUT,
	@unused_parameter int

as	
	
	
	-- Deepali 2019-03-27
	/*

	
	declare @user_id int = 34470
	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''
	declare @unused_parameter int = 1

	--exec [dm_email_high_matched_bids] @settings, @user_id , @sql_logging, null, @unused_parameter

	EXEC st_event 
	@user_id
	,@settings
	,@sql_logging
	,@output_message OUTPUT
	,'WINE_ISSUE_WEEK_PRIOR'
	, @user_id
	, 'N'
	, null
	,null
	, null
	, null
	, null
	,'unused_parameter'
	,1
	,'comments'
	,'dm_issues_week_prior'
	*/


	

Begin

	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='issues_week_prior'
	declare @object_name as varchar(50) = 'issues_week_prior'
	declare @audit_exception varchar(500) = ''

	--declare @input_fields as varchar(1000) = ''
	---- input field for logging purpose
	--select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
	--	+ ' User_id: ' + ISNULL(cast(@target_id as varchar(10)),'')

	-- optional logging
	--if @sql_logging ='Y'
	--	exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

		declare @organisation_id int = 0
		declare @username varchar(100) = ''
		declare @forename varchar(50)= ''
		declare @message varchar (max) =''
		declare @email varchar (50) =''
		declare @output_msg varchar (max) =''
		declare @user_brand varchar(20)
		declare @user_access varchar(10)
		declare @comments varchar(max)=

		'<table border="1px" style="border-color:#cccccc; border-style:solid; border-spacing: 0px !important">'
		+'<tr>'
		+'<th>Issue Date</th>'
		+'<th>Wine name</th>'
		+'<th>Comments</th>'
		+'</tr>'


		--'<table border="1" style="border-color: #cccccc;border-width: 1px;border-style: solid;"
		--rules="rows" width="100%">
		--	<col width="15%">
		--	<col width="45%">
		--	<col width="40%">
		--<tr style="background-color: #eeeeee; color: #666666; font-family: Helvetica;"> 
		--	<th>Issue Date</th>
		--	<th>Wine name</th>
		--	<th>Comments</th>
		--</tr> 
		--<tbody>'

	select /*	order of table columns: Issue date, [Vintage, Wine name] Comment	*/
		z.[Wine Issue Date]
		,'<a style=''color: #338bac;'' href=''https://www.wineowners.com/wine.aspx?wi='
		+CAST(z.wine_id AS VARCHAR(100))
		+'&v='
		+CAST(z.vintage AS VARCHAR(100))
		+'&tab=#trade''>'
		+z.[Wine] +'</a>' as 'Wine'
		,z.[Issue Comment]
		into #Comments

		from
		(
		select
		left(wi.created, 11) as 'Wine Issue Date'
		, CASE wi.vintage WHEN NULL THEN 'NV' ELSE CAST(wi.vintage as varchar(10)) END +' '
		+ dbo.fnGetDisplayShortName(@user_Id,'',@organisation_id,wi.wine_ID,'WO','') as 'Wine'
		, wi.wine_Id
		, wi.vintage
		, wi.comments as 'Issue Comment'

			from wine_issue wi
			where 
			--wi.issue_ref = 'Incorrect wine name'
			--and
			wi.disabled = 0
			and wi.comments not like '%test%'
			and wi.comments not like '%blah%'
			and left(wi.created,11) <= left(GETDATE(),11)
			and left(wi.created,11) >= left(GETDATE()-7,11)

			--order by created desc
		) z

		-- Set data, the right columns etc
		SELECT
		@comments = @comments +STUFF( 
			(
			select
			'<tr style="background-color: #f6e8e7; color: #666666; font-family: Helvetica;"><td align="left">'
			+ [Wine Issue Date]
			+ '</td><td align="center">'
				+ [Wine]
				+ '</td><td align="left">' 
					+ [Issue Comment]
					+ '</td>'
		from #comments
		FOR XML PATH(''),type).value('.', 'nvarchar(max)'),1,0,'')
						
		-- Placing the comments table in the correct space of page
		Set @comments = @comments + '</tbody></table>'

		-- Last few settings for comments
		Set @comments = 
			'<p class="p1" style="text-align: center;"><span class="s1" style="font-family: helvetica; font-size: 10pt; color: #666666;"></span></p>'
			+ @comments


		--add all variables in list data, or blank if there is not data (so it doesn't crash)
		Set @message = @comments

		Set @email = 'deepali.kerai@wineowners.com'

		select @message as 'message', @email as 'emailTo', @forename as 'forename'

end

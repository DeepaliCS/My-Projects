IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_monthly_report]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_monthly_report]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:      jp
-- Create date: 2013-10-23
-- Description: Returns a monthly report on the website activity
-- =============================================
CREATE PROCEDURE [dbo].[dm_report_monthly_report]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  
      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'name',
	  @sort_direction varchar(10) = 'asc',
	  @records int = 100
      
as   

/*
	this sp will return a list of months, and for each month the following information:
	
	Number of trades
	Amount traded
	Percentage growth of amount traded
	Amount earned by WO
	Percentage growth of amount earned by WO
	New open offers
	New open bids
	Total value of open offers
	total value of open bids
	Number of new bottles in cellars
	New value added to cellars
	New users
	Number of logins
	
	declare @out_msg as varchar(500) =''
	declare @user_id as int = 13
	declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

		exec dm_report_monthly_report @user_id,@settings,'X',@out_msg
		print @out_msg

	declare @id int 
	select @id = MAX(lookup_id) from [lookup]
	
	INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
	[display_order], [is_default_entry], [notes], 
	[lookup_field_1], [lookup_field_2], [lookup_field_3], 
	[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
	VALUES ('StoredProcedure', 'dm_report_monthly_report', 'WO', @id+1
	, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Monthly report" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
	, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
	-- select * from lookup where category = 'StoredProcedure'
	-- report documentation
	
	Filter types can be?
	
	*/
	
	/*
	drop table #tmp_table_rep 
	create table #tmp_table_rep (
		[Year] Int -- Ok
		, [Month] Int -- Ok
		, [Number of Trades] Int -- Ok
		, [Amount traded] DECIMAL(18,2) -- Ok
		, [Percentage growth of amount traded] DECIMAL(6,2) -- Ok
		, [Amount earned by WO] DECIMAL(18,2) -- Ok
		, [Percentage growth of amount earned by WO] DECIMAL(6,2) -- Ok
		, [New open offers] Int -- Ok
		, [New open bids] Int -- Ok
		, [Total value of open offers] DECIMAL(18,2) -- Ok
		, [Total value of open bids] DECIMAL(18,2) -- Ok
		, [number of new bottles in cellars] Int -- Ok
		, [New value added to cellars] DECIMAL(18,2) -- Ok
		, [Total value of cellars] DECIMAL(18,2)
		, [New users WO] Int -- Ok
		, [New users] Int -- Ok
		, [Number of logins] Int -- Ok
		, [New Trading users] Int -- Ok
		, [New Portfolio users] Int	-- Not Useful?
		, [Total Number of Trading users] int -- Ok
		, [Active Trading Users This Month] int
		, [Total Number of Active Trading users] int
		, [Average Amount per Trade] DECIMAL(18,2)
		, [Average Amount Traded per Trading User this Month] DECIMAL(18,2)
		, [Total Number of users] int
		, [Proportion of Trading Users] DECIMAL(6,3)
		, [Proportion of Active Trading Users] DECIMAL(6,3)
	)
	*/

	declare @transaction_name as varchar(50) = 'Monthly trading report'
	declare @object_name as varchar(50) = 'dm_report_monthly_report'
	declare @audit_exception varchar(500) = ''
	declare  @input_fields varchar(2000) = 'Input fields - Settings: ' + isnull(@settings,'')
	--- start
	--select @sql_logging='Y'
	--
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields


	-- get brand filter
	declare @brand_filter varchar(10) = 'WO'
	if @filter like 'brand%'
		begin
			if @filter = 'brand all'
				select @brand_filter = '',@filter=''
			else
				select @brand_filter = ltrim(rtrim(replace(@filter,'brand',''))),@filter=''
		end

	
	create table #tmp_table_rep (
		[Year] Int -- Ok
		, [Month] Int -- Ok
		, [Number of Trades] Int -- Ok
		, [Amount traded] DECIMAL(18,2) -- Ok
		, [Percentage growth of amount traded] DECIMAL(6,2) -- Ok
		, [Amount earned by WO] DECIMAL(18,2) -- Ok
		, [Percentage growth of amount earned by WO] DECIMAL(6,2) -- Ok
		, [New open offers] Int -- Ok
		, [New open bids] Int -- Ok
		, [number of new bottles in cellars] Int -- Ok
		, [New value added to cellars] DECIMAL(18,2) -- Ok
		, [Total value of cellars] DECIMAL(18,2)
		, [New users WO] Int -- Ok
		, [New users] Int -- Ok
		, [Number of logins] Int -- Ok
		, [New Trading users] Int -- Ok
		, [New Portfolio users] Int	
		, [Total Number of Trading users] int -- Ok
		, [Active Trading Users This Month] int -- Ok
		, [New Active Trading Users This Month] int -- Ok
		, [Total Number of Active Trading users] int -- Ok
		, [Average Amount per Trade] DECIMAL(18,2) -- Ok
		, [Average Amount Traded per Trading User this Month] DECIMAL(18,2) -- Ok
		, [Total Number of users] int -- Ok
		, [Proportion of Trading Users] DECIMAL(6,3)
		, [Proportion of Active Trading Users] DECIMAL(6,3)
		, [Settlement fee without VAT] DECIMAL(12,3)
		, [Settlement fee VAT only] DECIMAL(12,3)
		, [Buyer commission without VAT] DECIMAL(12,3)
		, [Buyer commission VAT only] DECIMAL(12,3)
		, [Seller commission without VAT] DECIMAL(12,3)
		, [Seller commission VAT only] DECIMAL(12,3)
		, [Inspection cost without VAT] DECIMAL(12,3)
		, [Inspection cost VAT only] DECIMAL(12,3)
		, [Delivery cost without VAT] DECIMAL(12,3)
		, [Delivery cost VAT only] DECIMAL(12,3)
		, [Total VAT] DECIMAL(12,3)
		, [Amount earned by 67] DECIMAL(18,2) -- Ok
		, [Collector Sub] Int
		, [Wine Lover Sub] Int 
		, [Value of New Traders] Decimal(18,2)
		, [Amount earned on New Traders] Decimal(18,2)
		, [Avg Bought by Privates] Decimal(18,2)
		, [Avg Bought by Businesses] Decimal(18,2)
		, [Avg Sold by Privates] Decimal(18,2)
		, [Avg Sold by Businesses] Decimal(18,2)

	)
	
	INSERT INTO #tmp_table_rep ([Year], [Month])
	Select YEAR(wo.created) 
		, MONTH(wo.created) 
	FROM wine_order wo with (nolock)
		-- where (order_status IN ('C','P')
		GROUP BY YEAR(wo.created), MONTH(wo.created)

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-table', @Input_fields

-- wv 2017-01-02 Dont understand logic of all code above
-- why have condition in 
	Update a
	SET a.[Number of Trades] = b.[Number of Trades]
		, a.[Amount traded] = b.[Amount traded]
		, a.[Amount earned by WO] = b.[Amount earned by WO]
		, a.[Amount earned by 67] = b.[Amount earned by 67]
		, a.[Settlement fee without VAT] = b.[Settlement fee without VAT]
		, a.[Settlement fee VAT only] = b.[Settlement fee VAT only]
		, a.[Buyer commission without VAT] = b.[Buyer commission without VAT]
		, a.[Buyer commission VAT only] = b.[Buyer commission VAT only]
		, a.[Seller commission without VAT] = b.[Seller commission without VAT]
		, a.[Seller commission VAT only] = b.[Seller commission VAT only]
		, a.[Inspection cost without VAT] = b.[Inspection cost without VAT]
		, a.[Inspection cost VAT only] = b.[Inspection cost VAT only]
		, a.[Delivery cost without VAT] = b.[Delivery cost without VAT]
		, a.[Delivery cost VAT only] = b.[Delivery cost VAT only]
	FROM #tmp_table_rep a
	LEFT JOIN ( 
	-- changed to tax point which is ok for C and P status
	Select YEAR(wo.tax_point) as 'Year'
		, MONTH(wo.tax_point) as 'Month'
		, count(1) as 'Number of Trades'
		, SUM(wo.case_price*wo.quantity) as 'Amount traded'
		, SUM(wo.buyer_settlement_fee) as 'Settlement fee without VAT'
		, SUM((wo.buyer_settlement_fee*wo.VAT_rate)/100.00) as 'Settlement fee VAT only'
		, SUM(wo.buyer_actual_commission_fee) as 'Buyer commission without VAT'
		, SUM((wo.buyer_actual_commission_fee*wo.VAT_rate)/100.00) as 'Buyer commission VAT only'
		, SUM(wo.seller_actual_commission_fee) as 'Seller commission without VAT'
		, SUM((wo.seller_actual_commission_fee*ISNULL(wo.VAT_rate_seller,0))/100.00) as 'Seller commission VAT only'
		, SUM(wo.buyer_inspection_cost+wo.seller_inspection_cost) as 'Inspection cost without VAT'
		, SUM((wo.buyer_inspection_cost*wo.VAT_rate)/100.00+(wo.seller_inspection_cost*ISNULL(wo.VAT_rate_seller,0))/100.00) as 'Inspection cost VAT only'
		, SUM(wo.buyer_delivery_cost+wo.seller_delivery_cost) as 'Delivery cost without VAT'
		, SUM((wo.buyer_delivery_cost*wo.VAT_rate)/100.00+(wo.seller_delivery_cost*ISNULL(wo.VAT_rate_seller,0))/100.00) as 'Delivery cost VAT only'
		, SUM(wo.seller_actual_commission_fee+wo.buyer_actual_commission_fee+wo.buyer_settlement_fee) as 'Amount earned by WO'
		-- 67 get 1 % from total trade price
		, SUM( case when (os.brand_ref='67')  then 0.01 * (wo.case_price * wo.quantity) else 0 end) as  'Amount earned by 67'
	FROM wine_order wo with (nolock)
		join organisation ob with (nolock) on ob.organisation_id = wo.buyer_id
		join organisation os with (nolock) on os.organisation_id = wo.seller_id
	WHERE wo.order_type = 'O' 
		and wo.order_status IN ('C','P')
		--and dbo.fnActualOrganisation(ISNULL(wo.seller_id,-1)) = 'Y'
		--AND dbo.fnActualOrganisation(ISNULL(wo.buyer_id,-1)) = 'Y'
		GROUP BY YEAR(wo.tax_point), MONTH(wo.tax_point)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]


	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-orders', @Input_fields

		
	update #tmp_table_rep
		set [Total VAT] = [Settlement fee VAT only]+[Buyer commission VAT only]+[Seller commission VAT only]
			+ [Inspection cost VAT only]+ [Delivery cost VAT only]
	-- New orders
	
	Update a
	SET a.[New open offers] = b.[New open offers]
		, a.[New open bids] = b.[New open bids]
	FROM #tmp_table_rep a
	LEFT JOIN (
		Select YEAR(wo.created) as 'Year'
			, MONTH(wo.created) as 'Month'
			, SUM(CASE
				WHEN (wo.order_type = 'O') THEN 1
				ELSE 0
			END) as 'New open offers'
			, SUM(CASE
				WHEN (wo.order_type = 'B') THEN 1
				ELSE 0
			END) as 'New open bids'
		FROM wine_order wo with (nolock)
		--WHERE -- dbo.fnActualOrganisation(ISNULL(wo.seller_id,-1)) = 'Y'
		--	AND dbo.fnActualOrganisation(ISNULL(wo.buyer_id,-1)) = 'Y'
		GROUP BY YEAR(wo.created), MONTH(wo.created)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-orders', @Input_fields


/*	-- New order valuations
	Update a
	SET a.[Total value of open offers] = b.[Total value of open offers]
		, a.[Total value of open bids] = b.[Total value of open bids]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select a.Year, a.Month
			, SUM(wo1.case_price*wo1.quantity) as 'Total value of open offers' 
			, SUM(wo2.case_price*wo2.quantity) as 'Total value of open bids' 
		FROM #tmp_table_rep a
		LEFT JOIN wine_order wo1 with (nolock)
			ON a.[Month]+a.[Year]*12>=Month(wo1.created)+Year(wo1.created)*12
				and wo1.order_type = 'O'
				and ( wo1.order_status = 'O'
						-- wv 2017-01-14 not sure this is correct, tries to work out open offers in the past
						OR (wo1.order_status IN ('C', 'P', 'S', 'E', 'X')
								AND MONTH(wo1.status_date)+YEAR(wo1.status_date)*12 > a.[Month]+a.[Year]*12
						)
				)
				and dbo.fnActualOrganisation(ISNULL(wo1.seller_id,-1)) = 'Y'
		LEFT JOIN wine_order wo2 with (nolock)
			ON a.[Month]+a.[Year]*12>=Month(wo2.created)+Year(wo2.created)*12
				and wo2.order_type = 'B'
				and ( wo2.order_status = 'O'
						OR (wo2.order_status IN ('C', 'P', 'S', 'E', 'M', 'X')
								AND MONTH(wo2.status_date)+YEAR(wo2.status_date)*12 
									> a.[Month]+a.[Year]*12
						)
				)
				and dbo.fnActualOrganisation(ISNULL(wo1.buyer_id,-1)) = 'Y'
		GROUP BY a.Year, a.Month
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	-- only do for the last 6 months (to speed things up a bit)
	where @filter='ALL' or (a.[Month] = MONTH(getdate()) and a.[Year] = YEAR(getdate()))

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-values', @Input_fields
*/



	-- count cellars
	Update a
	Set a.[number of new bottles in cellars] = b.[number of new bottles in cellars]
		, a.[New value added to cellars] = b.[New value added to cellars]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select YEAR(we.created) as 'Year', MONTH(we.created) as 'Month'
		-- select dbo.fnGetWinePrice(wine_id, vintage, currency, dateDiff(MM, we.created, getdate()),location_code, 'N')
			, SUM(we.no_bottles*ISNULL(wvp.current_price,we.price)*CAST(we.bottle_size_ref as decimal(18,4))/75) as 'New value added to cellars' 
			, SUM(we.no_bottles) as 'Number of new bottles in cellars' 
		FROM wine_entry we with (nolock)
		join cellar c with (nolock) on we.cellar_id = c.cellar_id
		join organisation o with (nolock) on c.owner_id = o.organisation_id
		left join wine_vintage_price wvp with (nolock)
			ON we.wine_id = wvp.wine_id and we.vintage = wvp.vintage
			and wvp.currency_ref = 'GBP' 
			AND wvp.region_ref = 'Europe' and wvp.disabled = 0
		WHERE we.disabled = 0 
			and dbo.fnActualOrganisation(ISNULL(c.owner_id,-1)) = 'Y'
			and cellar_type IN ('P', 'H', 'A','O')
			and (@brand_filter='' or (o.brand_ref = @brand_filter))

		GROUP BY MONTH(we.created), YEAR(we.created)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-cellars', @Input_fields


	-- cellar values
	Update a
	Set a.[Total value of cellars] = b.[Total value of cellars] 
	FROM #tmp_table_rep a
	LEFT JOIN (
		select a.Year, a.Month
			, SUM(we.no_bottles*ISNULL(wvp.current_price,we.price)*CAST(we.bottle_size_ref as decimal(18,4))/75) as 'Total value of cellars' 
		FROM #tmp_table_rep a
		JOIN wine_entry we with (nolock)
			ON a.[Month]+a.[Year]*12>=Month(we.created)+Year(we.created)*12	
				and isnull(we.disabled,0) = 0
				and (
					we.status = 'Active'
						OR (
							we.status IN ('Empty', 'Disposed', 'DisposedOther', 'DisposedGift', 'Consumed', 'DisposedSale') 
								AND MONTH(we.status_date)+YEAR(we.status_date)*12 
									> a.[Month]+a.[Year]*12
						)
				)
		LEFT JOIN wine_vintage_price wvp with (nolock) ON we.wine_id = wvp.wine_id and we.vintage = wvp.vintage and wvp.currency_ref = 'GBP' 
								AND wvp.region_ref = 'Europe' and isnull(wvp.disabled,0) = 0
		JOIN cellar c with (nolock) ON c.cellar_id = we.cellar_id
		join organisation o with (nolock) on o.organisation_id = c.owner_id
		WHERE dbo.fnActualOrganisation(ISNULL(c.owner_id,-1)) = 'Y'
			AND c.cellar_type IN ('P', 'H', 'A','O')
			and (@brand_filter='' or (o.brand_ref = @brand_filter))
		GROUP BY a.Year, a.Month
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-cellars-values', @Input_fields


	-- New users WO
	Update a
	Set a.[New users WO] = b.[New users WO]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select MONTH(u.created) as 'Month', YEAR(u.created) as 'Year'
			, COUNT(1) as 'New users WO' 
		from [user] u with (nolock)
			join organisation o with (nolock) on o.organisation_id = u.organisation_id
		WHERE u.created is not null 
			and u.[disabled] = 0 and user_access = 'U'
			and u.email NOT IN ('peter.robson@wineowners.com','jonathan.picchi@wineowners.com')
			and dbo.fnActualOrganisation(u.organisation_id) = 'Y'
			and ISNULL(admin_user,'N')<>'Y'
			and o.brand_ref = 'WO'
		GROUP by MONTH(u.created), YEAR(u.created)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-users', @Input_fields

	-- New users
	Update a
	Set a.[New users] = b.[New users]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select MONTH(u.created) as 'Month', YEAR(u.created) as 'Year'
			, COUNT(1) as 'New users' 
		from [user] u with (nolock)
 			join organisation o with (nolock) on o.organisation_id = u.organisation_id 
		WHERE u.created is not null 
			and isnull(u.[disabled],0) = 0 
			and user_access = 'U'
			and u.email NOT IN ('peter.robson@wineowners.com','jonathan.picchi@wineowners.com')
			and dbo.fnActualOrganisation(u.organisation_id) = 'Y'
			and ISNULL(admin_user,'N') <> 'Y'
			and (@brand_filter='' or (o.brand_ref = @brand_filter))
		GROUP by MONTH(u.created), YEAR(u.created)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-users-WO', @Input_fields

	-- JP 20141121 new traders
	/*
	select u.alias, a.created as 'registration time' from audit_hdr a 
		join [user] u on a.[object_id] = u.[user_id]
		where a.action = 'Register_Trading' 
		and a.[object_name] = 'st_register_trading'
		and a.description = 'completed'
		order by u.[user_id]
	*/
	
	-- trading registration users
	Update a
	Set a.[New Trading users] = b.[New Trading users]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select MONTH(a.created) as 'Month', YEAR(a.created) as 'Year'
			, COUNT(1) as 'New Trading users' 
		from [user] u with (nolock)
			join audit_hdr a with (nolock) on a.[object_id] = u.[user_id]
 			join organisation o with (nolock) on o.organisation_id = u.organisation_id 
		where a.action = 'Register_Trading' 
			and a.[object_name] = 'st_register_trading'
			and a.description = 'completed'
			and a.created is not null 
			and isnull(u.[disabled],0) = 0 
			and u.user_access = 'U'
			and u.email NOT IN ('peter.robson@wineowners.com','jonathan.picchi@wineowners.com')
			and dbo.fnActualOrganisation(u.organisation_id) = 'Y'
			and (@brand_filter='' or (o.brand_ref = @brand_filter))
			-- allow for all brands !
			-- and o.brand_ref='WO'
			
			and ISNULL(admin_user,'N')<>'Y'
		GROUP by MONTH(a.created), YEAR(a.created)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-new-trading-registration', @Input_fields


	-- trading user
	Update a
	Set a.[Total Number of Trading users] = b.[Number of Trading users]+158
	FROM #tmp_table_rep a
	LEFT JOIN (
		Select [Year], [Month]
			, SUM([New Trading users]) over(order by [Year], [Month] rows unbounded preceding) as 'Number of Trading users'
		From #tmp_table_rep
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-trading-users', @Input_fields


	-- logins
	Update a
	Set a.[Number of logins] = b.[Number of logins]
	FROM #tmp_table_rep a
	LEFT JOIN (
		select COUNT(1) as 'Number of logins'
			, MONTH(a.audit_date_time) as 'Month'
			, YEAR(a.audit_date_time) as 'Year' 
		from audit_hdr a with (nolock)
			join [user] u with (nolock) on a.object_id = u.user_id
			join organisation o with (nolock) on o.organisation_id = u.organisation_id 
		where a.[action] in ('UserLogin', 'logon success')
			and dbo.fnActualOrganisation(u.organisation_id) = 'Y'
			and u.email not IN ('peter.robson@wineowners.com','jonathan.picchi@wineowners.com')
			and ISNULL(admin_user,'N') <> 'Y'
			and (@brand_filter='' or (o.brand_ref = @brand_filter))

		GROUP BY MONTH(audit_date_time), YEAR(audit_date_time)
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-logins', @Input_fields


	-- amount traded totals
	Update a
		set a.[Percentage growth of amount traded] 
			= (a.[Amount traded] - b.[Amount traded])/b.[Amount traded]
			, a.[Percentage growth of amount earned by WO] 
			= (a.[Amount earned by WO] - b.[Amount earned by WO])/b.[Amount earned by WO]
	FROM #tmp_table_rep a
	JOIN #tmp_table_rep b
		ON a.[YEAR]*12+a.[Month] = b.[YEAR]*12+b.[Month] +1
		AND ISNULL(b.[Amount traded],0)<>0
		AND ISNULL(b.[Amount earned by WO],0)<>0
	
	-- [New Active Trading Users This Month]
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-amount-traded', @Input_fields

	-- total number of active trading users this month
	Update a
		Set a.[Active Trading Users This Month] = b.number
	FROM #tmp_table_rep a
	JOIN (
	select COUNT(distinct organisation_id) as 'number',  YEAR(wo.tax_point) as 'Year', MONTH(wo.tax_point) as 'Month' 
		from organisation o with (nolock) 
		join wine_order wo with (nolock) on wo.order_status IN ('C','P') and wo.order_type = 'O' and (o.organisation_id = wo.seller_Id OR o.organisation_id = wo.buyer_Id)
	GROUP BY YEAR(wo.tax_point), MONTH(wo.tax_point)
	) b on a.[Month] = b.[Month] and a.[Year] = b.[Year]

	-- running total
	Update a
		Set a.[Total Number of Active Trading users] = b.[running total]
	FROM #tmp_table_rep a
	JOIN (
		Select y.* 
			, SUM(y.number) over(order by y.Year, y.Month rows unbounded preceding) as 'running total'
		from (
			select MONTH(first) as 'Month', YEAR(first) as 'YEAR', COUNT(1) as 'number' from (
				select distinct o.organisation_id, MIN(u.[user_id]) as 'User_Id', MIN(wo1.status_date) as 'first' 
					from organisation o with (nolock)
						join [user] u with (nolock) on o.organisation_id = u.[organisation_id]
						join wine_order wo1 with (nolock) on wo1.order_status IN ('C','P') and wo1.order_type = 'O'
							and (wo1.seller_id = o.organisation_id or wo1.buyer_id = o.organisation_id)
				where dbo.fnActualOrganisation(o.organisation_id)='Y' 
					and isnull(u.disabled,0) = 0
					and ISNULL(u.admin_user,'N')<>'Y'
					and (@brand_filter='' or (o.brand_ref = @brand_filter))
				GROUP by o.organisation_id
				--ORDER by o.organisation_id
			) z
			GROUP BY YEAR(first), MONTH(first) 
			--ORDER BY YEAR(first), MONTH(first) 
		) y
		--ORDER BY y.[Year], y.[MONTH]
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]

	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-amount-traded-running-total', @Input_fields


	--	total users
	Update a
		Set a.[Total Number of users] = b.[Running total]
	FROM #tmp_table_rep a
	JOIN (
		select z.*
			, SUM(z.number) over(order by z.Year, z.Month rows unbounded preceding) as 'running total'
			from (
			select MONTH(created) as 'Month', YEAR(created) as 'Year', Count(1) as 'number'
			from organisation with (nolock) 
				where dbo.fnActualOrganisation(organisation_id)='Y'
					and isnull(disabled,0) = 0 
					and organisation_type_ref IN ('Mem', 'Merh', 'Trd')
					and (@brand_filter='' or (brand_ref = @brand_filter))
			group by YEAR(created), MONTH(created) 
		) z	
	) b
	ON a.[Month] = b.[Month] and a.[Year] = b.[Year]
	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-total-users-running-total', @Input_fields

	-- various
	update #tmp_table_rep
		set [Average Amount per Trade] = [Amount traded] / CAST([Number of Trades] as DECIMAL(18,2))
	where [Number of Trades] > 0
	
	update #tmp_table_rep
		set [Average Amount Traded per Trading User this Month] = [Amount traded] / [Active Trading Users This Month]

	update #tmp_table_rep
		set [Proportion of Trading Users] = CAST([Total Number of Trading users] as DECIMAL(18,2)) / [Total Number of users] 
	update #tmp_table_rep
		set [Proportion of Active Trading Users] = CAST([Total Number of Active Trading users] as DECIMAL(18,2)) / [Total Number of Trading users]

	-- Collector and Wine-Lover subscriptions
	Update a
		Set a.[Wine Lover Sub] = b.[Nb Wine lovers], a.[Collector Sub] = b.[Nb Collectors]
	FROM #tmp_table_rep a
	JOIN (
		select [YEAR], [MONTH], SUM(CASE invoice_amount WHEN 240 THEN 1 ELSE 0 END) as 'Nb Collectors'
			, SUM(CASE invoice_amount WHEN 90 THEN 1 ELSE 0 END) as 'Nb Wine lovers'
		from (
			select o.*, MONTH(i.created) as 'Month', YEAR(i.created) as 'Year', i.invoice_amount 
			from organisation o with (nolock)
				join organisation_invoice i with (nolock) on o.organisation_id = i.organisation_id and i.payment_received = 'Y'
			where o.subscription IN ('collector','wine-lover')
				and (@brand_filter='' or (o.brand_ref = @brand_filter))
		) z 
		GROUP BY [YEAR], [MONTH]
		-- order by [YEAR], [MONTH]
	) b on a.[Month] = b.[Month] and a.[Year] = b.[Year]

	--___________________-

	--Updating/storing data in to avg spent monthly by private and business
	update a
	set 
	  a.[Avg Bought by Privates] = b.[Avg Bought by Privates] 
	, a.[Avg Bought by Businesses] = b.[Avg Bought by Businesses] 
	, a.[Avg Sold by Privates] = b.[Avg Sold by Privates] 
	, a.[Avg Sold by Businesses] = b.[Avg Sold by Businesses]

	from #tmp_table_rep a

	join (
		select 

		month(wo.tax_point) as 'Month' 
		, year(wo.tax_point) as 'Year'
		, SUM(CASE WHEN o.trading_type = 'P' THEN wo.total_wine_price ELSE NULL END)/COUNT(distinct CASE o.trading_type WHEN 'P' THEN wo.buyer_Id ELSE NULL END) as 'Avg Bought by Privates'
		, SUM(CASE WHEN o.trading_type = 'B' THEN wo.total_wine_price ELSE NULL END)/COUNT(distinct CASE o.trading_type WHEN 'B' THEN wo.buyer_Id ELSE NULL END) as 'Avg Bought by Businesses'
		, SUM(CASE WHEN o1.trading_type = 'P' THEN wo.total_wine_price ELSE NULL END)/COUNT(distinct CASE o1.trading_type WHEN 'P' THEN wo.seller_id ELSE NULL END) as 'Avg Sold by Privates'
		, SUM(CASE WHEN o1.trading_type = 'B' THEN wo.total_wine_price ELSE NULL END)/COUNT(distinct CASE o1.trading_type WHEN 'B' THEN wo.seller_id ELSE NULL END) as 'Avg Sold by Businesses'

		from wine_order wo
		join organisation o on wo.buyer_id = o.organisation_id
		join organisation o1 on wo.seller_id = o1.organisation_id

		where o.trading_status = 'A'
		and wo.order_status in('P', 'C')

		group by month(wo.tax_point), year(wo.tax_point)

		) b on a.[Month] = b.[Month] and a.[Year] = b.[Year]


	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'completed-all-updates', @Input_fields

	-----
	/*
	select [Description] as 'Description~txtCenter~txtCenter noWrap'
		, CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO','Total Amount Offers','Total Amount Bids') 
			THEN dbo.fnDisplayInteger([Total],NULL,'n/a','en')
			ELSE CAST(CAST([Total] as INT) as varchar(50))
		END as 'Total~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO','Total Amount Offers','Total Amount Bids') 
			THEN dbo.fnDisplayInteger([Total today],NULL,'n/a','en')
			ELSE CAST(CAST([Total today] as INT) as varchar(50))
		END as 'New today~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO','Total Amount Offers','Total Amount Bids') 
			THEN dbo.fnDisplayInteger([Total last 7 days],NULL,'n/a','en') 
			ELSE CAST(CAST([Total last 7 days] as INT) as varchar(50))
		END as 'New 7 days~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO','Total Amount Offers','Total Amount Bids') 
			THEN dbo.fnDisplayInteger([Total this month],NULL,'n/a','en')
			ELSE CAST(CAST([Total this month] as INT) as varchar(50)) 
		END as 'New this month~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE [Average per trading user] 
			WHEN -1 THEN ' ' 
			ELSE CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO') 
				THEN dbo.fnDisplayInteger([Average per trading user],NULL,'n/a','en')
				ELSE CAST([Average per trading user] as varchar(50)) END
		END as 'avg / trading user~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE [Average per trading user this month] 
			WHEN -1 THEN ' ' 
			ELSE CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO') 
			THEN dbo.fnDisplayInteger([Average per trading user this month],NULL,'n/a','en')
			ELSE CAST([Average per trading user this month] as varchar(50)) END
		END as 'avg / trading user this month~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE [Average per Trade] 
			WHEN -1 THEN ' ' 
			ELSE CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO') 
			THEN dbo.fnDisplayInteger([Average per Trade],NULL,'n/a','en')
			ELSE CAST([Average per Trade] as varchar(50)) END
		END as 'avg / Trade~txtCenter nosort noWrap~txtCenter noWrap'
		, CASE [Average per Trade this month] 
			WHEN -1 THEN ' ' 
			ELSE CASE WHEN [Description] IN ('Amount traded','Market value of cellars','Amount earned by WO')
			THEN dbo.fnDisplayInteger([Average per Trade this month],NULL,'n/a','en') 
			ELSE CAST([Average per Trade this month] as varchar(50)) END
		END as 'avg / Trade this month~txtCenter nosort noWrap~txtCenter noWrap'
		
	from #tmp_table_agg
	where (
		description like '%'+@filter+'%'
	)
	
	drop table #tmp_table_agg 
	*/
	
	--print 'output data'

	---
	Select [Year]
		, [Month]
/*		, case when @filter = 'download' or isnumeric([New value added to cellars]) <> 1 then [New value added to cellars]
			else dbo.fnDisplayInteger([New value added to cellars],char(163),'','en') end as 'New value added to cellars'
		, case when @filter = 'download' or isnumeric([Total value of cellars]) <> 1 then [Total value of cellars] 
			else dbo.fnDisplayInteger([Total value of cellars],char(163),'','en') end as 'Total value of cellars'
		, [Number of Trades]
		, case when @filter = 'download' or isnumeric([Amount traded]) <> 1 then [Amount traded]
			else dbo.fnDisplayInteger([Amount traded],char(163),'','en') end as 'Amount traded'

		--, case when isnumeric([Average Amount per Trade])=1 then '' else [Average Amount per Trade] end as 'test'
		, case when @filter = 'download' or isnumeric([Average Amount per Trade]) <> 1 then [Average Amount per Trade]
			else dbo.fnDisplayInteger([Average Amount per Trade],char(163),'','en') end as 'Average Amount per Trade'
			-- wv 2017-01-03   no idea why this column gives a conversion from varchar to numeric error

		, case when @filter = 'download' or isnumeric([Average Amount Traded per Trading User this Month]) <> 1 then [Average Amount Traded per Trading User this Month]
			else dbo.fnDisplayInteger([Average Amount Traded per Trading User this Month],char(163),'','en') end as 'Avg Amount traded per Active User'
*/

		, dbo.fnDisplayInteger([New value added to cellars],' ','','en') as [New value added to cellars]
		, dbo.fnDisplayInteger([Total value of cellars],' ','','en') as [Total value of cellars] 
		, [Number of Trades]
		, dbo.fnDisplayInteger([Amount traded],' ','','en') as [Amount traded]
		, dbo.fnDisplayInteger([Average Amount per Trade],' ','','en') as [Average Amount per Trade]
		, dbo.fnDisplayInteger([Average Amount Traded per Trading User this Month],' ','','en') as [Average Amount Traded per Trading User this Month]
		
		, CAST(100*[Percentage growth of amount traded] as varchar(100))
			+ case when @filter <> 'download' then '%' else '' end as 'Percentage growth of amount traded'
		, dbo.fnDisplayInteger([Amount earned by WO],' ','','en') as [Amount earned by WO]
		, dbo.fnDisplayInteger([Amount earned by 67],' ','','en') as [Amount earned by 67]
		, CAST(100*[Percentage growth of amount earned by WO] as varchar(100))
			+ case when @filter <> 'download' then '%' else '' end as 'Percentage growth of amount earned by WO'
		, [New open offers]
		, [New open bids]
		, [number of new bottles in cellars]
		, [New users WO]
		, [New users]
		, [New Trading users]
		, [Total Number of Trading users]
		, [Active Trading Users This Month]
		, [Total Number of Active Trading users]
		--, [Proportion of Trading Users]
		--, [Proportion of Active Trading Users] as 'Proportion of Active Trading Users among Trading Users'
		, [Number of logins]
		, [Settlement fee without VAT]
		, [Settlement fee VAT only]
		, [Buyer commission without VAT]
		, [Buyer commission VAT only]
		, [Seller commission without VAT]
		, [Seller commission VAT only]
		, [Inspection cost without VAT]
		, [Inspection cost VAT only]
		, [Delivery cost without VAT]
		, [Delivery cost VAT only]
		, [Total VAT]
		, [Wine Lover Sub]
		, [Collector Sub]
		, [Avg Bought by Privates]
		, [Avg Bought by Businesses]
		, [Avg Sold by Privates] 
		, [Avg Sold by Businesses] 



	FROM #tmp_table_rep
	Order by [Year] desc, [Month] desc
	
	drop table #tmp_table_rep

	-- end	
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'end', @Input_fields

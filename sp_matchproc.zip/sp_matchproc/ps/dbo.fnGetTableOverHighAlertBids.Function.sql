IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnGetTableOverHighAlertBids]')  AND type = N'IF')
     DROP FUNCTION [dbo].[fnGetTableOverHighAlertBids]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Deepali
-- Create date: 04/06/2019
-- Description:	Get the list of bids made over the high price alert - return table/query results
-- =============================================


CREATE FUNCTION [dbo].[fnGetTableOverHighAlertBids] 
(
	@user_id int,
	@settings varchar(500),
	--@organisation_id int,
	@options varchar(50) = ''
)
	
returns table
as
return (

		select
				t.owner_id
			, wo.wine_order_id
			, wo.order_type
			, wo.valid_till
			, w.name
			, wo.vintage
			, wo.quantity
			, wo.case_size
			, wo.total_wine_price
			, wo.open_bid_tax_status
			, wo.created

		
			from wine_order wo
			join tracking t on wo.wine_ID = t.wine_id 
				and wo.vintage = t.vintage
				and isnull(t.disabled,0) = 0
				and isnull(t.is_tracked,'N') = 'Y'
				and t.high_price_alert <= wo.case_price
			join wine w on w.wine_id = wo.wine_id

			where wo.order_type = 'B' 
				and order_status = 'O'		
			
	)

	
		


				
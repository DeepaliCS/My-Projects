IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_wine_consignment_expiry]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_wine_consignment_expiry]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

	-- =============================================
	-- Author:		Deepali
	-- Create date: 06/06/2019
	-- Description:	Send email to users about wine consignment expiry
	-- =============================================


CREATE PROCEDURE [dbo].[dm_wine_consignment_expiry]

	@settings as varchar(500) ='',	
	@user_id int,						
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT,
	@organisation_id int


	/*

	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @user_id int = 34470
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''
	declare @organisation_id int = 52592


	EXEC st_event 
	  @user_id
	, @settings
	, @sql_logging
	, @output_message OUTPUT
		, 'CONSIGNMENT_EXPIRY ' 
		, @user_id
		, 'N'
		, null
		, null
		, null
		, null
		, null
		, '@organisation_id'
		, 52592
		,'wine_consignment_expiry'
		,'dm_wine_consignment_expiry'

	--exec [dm_wine_consignment_expiry] @settings, @user_id , @sql_logging, null, @organisation_id

	*/


as	
begin

	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='dm_wine_consignment_expiry'
	declare @object_name as varchar(50) = 'dm_wine_consignment_expiry'
	declare @audit_exception varchar(500) = ''

	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
		+ ' User_id: ' + ISNULL(cast(@user_id as varchar(10)),'')

	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

	declare @forename varchar(50)= ''
	declare @message varchar (max) = ''
	declare @email varchar (50) = ''
	declare @wine_consignment_expiry_table as varchar(max)

	declare @user_email_Id int = dbo.fnGetOrganisationUser(@organisation_id)
	
	declare @number_of_consignment_7_days as int
	declare @number_of_consignment_1_day as int
	----------------------------
	
	-- Get the sum of consignments made by this user (organisation ID)
	select @number_of_consignment_7_days = sum(case when wc.[expiry_date] <= cast(getdate()+7 as date) and wc.[expiry_date] > cast(getdate()+1 as date) then 1 else 0 end)
	, @number_of_consignment_1_day = sum(case when wc.[expiry_date] = cast(getdate()+1 as date) then 1 else 0 end)
	
	from wine_entry we
		join wine_consignment wc on we.wine_entry_id = wc.wine_entry_id
		join cellar c on we.cellar_id = c.cellar_id
		join organisation o on c.owner_id = o.organisation_id

	-- conditions: Active, in the last 7 days
	where consignment_status like 'A'
		and wc.[expiry_date] <= cast(getdate()+7 as date)
	and o.organisation_Id = @organisation_id



	-- main select
	select 
		'jonathan.picchi@wineowners.com' as email_to -- email
		, dbo.fnMultiple(@number_of_consignment_7_days,'offer', null, 'ADD-NUMBER') as 'expired_7_days_text'
		, dbo.fnMultiple(@number_of_consignment_1_day,'offer', null, 'ADD-NUMBER') as 'expired_1_days_text'

		,u.*

	from [user] u
	where u.[user_id] = @user_email_Id

end


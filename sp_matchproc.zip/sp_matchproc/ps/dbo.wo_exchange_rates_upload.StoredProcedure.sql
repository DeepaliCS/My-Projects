IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_exchange_rates_upload]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_exchange_rates_upload]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Jonathan PICCHI
-- Create date: 2017-12-22
-- Description:	New sp to upload exchange rates every week
-- =============================================
CREATE PROCEDURE [dbo].[wo_exchange_rates_upload] 

/*

-- This procedure is called by the job ''

necessary table:

CREATE TABLE [dbo].[index_data](
	[index_rec_id] [int] IDENTITY(1,1) NOT NULL,
	[index_id] [int] NULL,
	[data_type] [varchar](50) NULL,
	[processed] [varchar](1) NULL,
	[value] [decimal](18, 4) NULL,
	[index_date] [datetime] NULL,
	[data_description] [varchar](100) NULL,
	[disabled] [bit] NULL,
	[created] [datetime] NULL,
	[created_by] [int] NULL,
	[updated] [datetime] NULL,
	[updated_by] [int] NULL,
	[stamp] [int] NULL
)

RUN:
exec wo_exchange_rates_upload

-- Select * from dbo.index_data
-- Select * from dbo.audit_hdr order by created desc

For testing:
You can change the getdate period from getdate() -1.00/2 TO getdate() -1

Queries to check inserts into exchange_rates table and audit table:

	select 
		audit_date_time
		, action
		, description 
	from audit_hdr 
	where
		description is not null 
		and action like 'exchange_rate_checks'
		and audit_date_time >= getdate()-24
	order by audit_date_time
	
	select * from exchange_rates 
		where [date] >= getdate()-24
		order by eRate_id desc
-------------------	
-- Deleting the insertions and checks to restart

delete from audit_hdr where action like 'exchange_rate_checks'
delete from exchange_rates where [date] >= getdate()-24


*/

AS
BEGIN

--
declare @object_name varchar(255) = 'wo_exchange_rates_upload'
declare @settings varchar(255) = '192.145.12.233~session4587~WO~Europe~GBP~en'

declare @SQLQuery varchar(3000)= ''
declare @message varchar(2000) = ''

declare @row_count int

declare @codes_gbp as varchar(3000)
declare @rates_gbp as varchar(3000)
declare @codes_eur as varchar(3000)
declare @rates_eur as varchar(3000)

--------------------------------

-- First do GBP to other currencies
	
	-- code to get the index codes and values
	drop table IF EXISTS #index_codes_values_gbp
		SELECT LTRIM(RTRIM(right(data_description,3))) as code , value as rate
			into #index_codes_values_gbp
			from live1_wo_main.dbo.index_data
				where created >= getdate() - 1.00/2 
				and data_description like 'GBP to %'
	--select * from #index_codes_values

	-- code to make sure there are no same index codes
	drop table IF EXISTS #check_duplicates_gbp
		SELECT LTRIM(RTRIM(right(data_description,3))) as code_name, COUNT(*) as count
			into #check_duplicates_gbp
			from live1_wo_main.dbo.index_data
				where created >= getdate() - 1.00/2 
				and data_description like 'GBP to %'
					group by LTRIM(RTRIM(right(data_description,3)))
					having COUNT(*) > 1
	--select * from #check_duplicates

	-- binary format to whether or not there is duplication of the same index code
	declare @duplicate_indication_gbp as int = 
	(select case when exists (select 1 from #check_duplicates_gbp)
          then 1 -- there are duplicates
          else 0 -- there are no duplicates
    end)
	--print @duplicate_indication

	set @message = 'Number of Duplicates found (GBP): ' + try_cast(@duplicate_indication_gbp AS varchar(500))
	exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null


	-- Add threshold to how many new exchanges have been pulled? and then only save into exchange table?
	IF 
	(   select COUNT(1) from index_Data
		where created > getdate()-1.00/2 
		and ISNULL(processed,'N')<>'Y'
		and @duplicate_indication_gbp = 0 -- when there are no duplicates

	) < 1 

		BEGIN
	
			-- codes insert
			select @codes_gbp =
			coalesce(@codes_gbp  + ', ', '') + convert(varchar(3000),code)
			from #index_codes_values_gbp
			print @codes_gbp

			-- rates insert
			select @rates_gbp = 
			coalesce(@rates_gbp  + ', ', '') +  convert(varchar(3000),rate)
			from #index_codes_values_gbp
			print @rates_gbp

			set @message = 'GBP-to Index Code: ' + try_cast(@codes_gbp AS varchar(500))
			exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null
	
			set @message = 'GBP-to Index Rate: ' + try_cast(@rates_gbp AS varchar(500))
			exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null
				

			set @row_count = 0
			if @rates_gbp <> '' and @codes_gbp <> ''

			begin
				SET @SQLQuery = 
					'insert into exchange_rates 
						(' 
						+  @codes_gbp 
						+ ', FROM_currency
						   , date
						   , GBP
						) 
					VALUES
						(' 
						+ @rates_gbp + ', ' 
						+ '''GBP''' + ', '
						+ ''''+try_cast(try_cast(GETDATE() as [date]) as varchar(20))+''''+ ', ' 
						+ '1.00'
						+ ')'
					EXECUTE(@SQLQuery)
					set @row_count = @@ROWCOUNT
			end

				set @message = 'No of inserts (GBP): ' + try_cast(@row_count as varchar(10))
				exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null

			update index_Data set processed = 'Y', updated = getdate(), updated_by = 213 where created > getdate()-1.00/2 and ISNULL(processed,'N')<>'Y' and data_description like 'GBP to %' 	

		END
ELSE
	BEGIN

		exec st_audit 213, @settings, @object_name, 'GBP exchange rates insertion', '', 'The GBP exchange rates were not inserted as they were not pulled correctly into index_data'

	END

-- Now do EUR to other currencies
--------------------------------

--Set @values_list = ''
Set @SQLQuery = ''

	-- code to get the index codes and values
	drop table IF EXISTS #index_codes_values_eur
		SELECT LTRIM(RTRIM(right(data_description,3))) as code , value as rate
			into #index_codes_values_eur
			from live1_wo_main.dbo.index_data
				where created >= getdate() - 1.00/2
				and data_description like 'EUR to %'
	--select * from #index_codes_values

	-- code to make sure there are no same index codes
	drop table IF EXISTS #check_duplicates_eur
		SELECT LTRIM(RTRIM(right(data_description,3))) as code_name, COUNT(*) as count
			into #check_duplicates_eur
			from live1_wo_main.dbo.index_data
				where created >= getdate() - 1.00/2
				and data_description like 'EUR to %'
					group by LTRIM(RTRIM(right(data_description,3)))
					having COUNT(*) > 1
	--select * from #check_duplicates

	-- binary format to whether or not there is duplication of the same index code
	declare @duplicate_indication_eur as int = 
	(
		select case when exists
			(select 1 from #check_duplicates_eur) 
				  then 1 -- there are duplicates
				  else 0 -- there are no duplicates
		end
	)
	--print @duplicate_indication

	set @message = 'Number of Duplicates found (EUR): ' + try_cast(@duplicate_indication_eur AS varchar(500))
	exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null


	-- conditions to pass in order to insert
	IF 
	(	select COUNT(1) from index_Data
			where created > getdate() - 1.00/2
			and ISNULL(processed,'N')<>'Y'
			and @duplicate_indication_eur = 0 -- when there are no duplicates
	) < 1
	
		BEGIN

			-- codes insert
			select @codes_eur =
			coalesce(@codes_eur + ', ', '') + convert(varchar(3000),code)
			from #index_codes_values_eur
			print @codes_eur

			-- rates insert
			select @rates_eur = 
			coalesce(@rates_eur + ', ', '') + convert(varchar(3000),rate)
			from #index_codes_values_eur
			print @rates_eur

			set @message = 'EUR-to Index Codes: ' + try_cast(@codes_eur AS varchar(500))
			exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null
		
			set @message = 'EUR-to Index Rates: ' + try_cast(@rates_eur AS varchar(500))
			exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null

			set @row_count = 0
			if @rates_eur <> '' and @codes_eur <> ''

			begin
				SET @SQLQuery = 
					'insert into exchange_rates 
						(' 
						+  @codes_eur
						+ ', FROM_currency
						   , date
						   , EUR
						) 
					VALUES
						(' 
						+ @rates_eur + ', ' 
						+ '''EUR''' + ', '
						+ ''''+try_cast(try_cast(GETDATE() as [date]) as varchar(20))+''''+ ', ' 
						+ '1.00'
						+ ')'
					EXECUTE(@SQLQuery)
					set @row_count = @@ROWCOUNT
			end
				set @message = 'No of inserts (EUR): ' + try_cast(@row_count as varchar(10))
				exec st_audit_hdr  213, @settings, 'exchange_rate_checks', @object_name, @message , null, null, null

			update index_Data set processed = 'Y', updated = getdate(), updated_by = 213 where created > getdate()-1.00/2 and ISNULL(processed,'N')<>'Y' and data_description like 'EUR to %'

		END
	ELSE
		BEGIN

			exec st_audit 213, @settings, @object_name, 'EUR exchange rates insertion', '', 'The EUR exchange rates were not inserted as they were not pulled correctly into index_data'

		END

END

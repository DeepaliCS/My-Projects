IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_vintage_marketprice_difference]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_vintage_marketprice_difference]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-01-18
-- Description: Return report with major differences in market prices between vintages
-- =============================================


CREATE PROCEDURE [dbo].[dm_report_vintage_marketprice_difference]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'date',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      
as    


/*	

This stored procedure is a way to find vintages that have a price very different from other vintages of the same wine.
Selecting wine vintages where the current price is very difference from the average price of 5-6 other vintages of the same wine.
For example, when looking at Margaux 2005, compare its price to the average price of Margaux 2002-3-4-6-7-8.

Tables used: wine, wine_vintage_price
Currency and Region are the parameters, defaulted to GBP and Europe.

**Test for filters: 'rhone high=75 low=10'
**Defaults are high=75 low=25

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_vintage_marketprice_difference @user_id,@settings,'X',@out_msg, ''
	print @out_msg

declare @id int 
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_vintage_marketprice_difference', 'WO', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Big price differences according to vintages" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
-- select * from lookup where category = 'StoredProcedure'
-- report documentation


*/

	
	-- Used in the where clause
	declare @convertedLowerThreshold decimal(10,2)=0
	declare @convertedHigherThreshold decimal(10,2)=0

	--__________________________________________

	--New variables

	   -- Variable for the threshold values
	   declare @HigherThresholdRight varchar(100) = ''
	   declare @HigherThresholdLeft varchar(100) = ''

	   -- Variable for the threshold values
	   declare @LowerThresholdRight varchar(100) = ''
	   declare @LowerThresholdLeft varchar(100) = ''
	
	--__________________________________________

			--Default values set if the high and low thresholds are not set
		if (@filter not like '%high=%') and (@filter not like '%low=%')

			begin

				set @convertedHigherThreshold = 0.75
				set @convertedLowerThreshold = -0.25
					
			end 

	--__________________________________________

		--Extract the higher-end threshold value (More comments: dbo.dm_report_price_difference.storedprocedure)
	if @filter like '%high=%'

		begin

			set @HigherThresholdRight = RIGHT(@filter,LEN(@filter)-charindex('high',@filter)-len('high=')+1)+ ' '
			set @HigherThresholdLeft = LEFT(@HigherThresholdRight, charindex(' ',@HigherThresholdRight)-1)

			-- Variable used in the select
			set @convertedHigherThreshold = (try_cast(@HigherThresholdLeft as decimal(10,2))/100)

			-- Remove the minimum string and the value from the filter (so other given filters can be used - the where clause)
			set @filter = replace(@filter,'high='+@HigherThresholdLeft, '')

		end

	--Extract the lower-end threshold value (More comments: dbo.dm_report_price_difference.storedprocedure)
	if @filter like '%low=%'
		begin

			set @LowerThresholdRight = RIGHT(@filter,LEN(@filter)-charindex('low',@filter)-len('low=')+1)+ ' '
			set @LowerThresholdLeft = LEFT(@LowerThresholdRight, charindex(' ',@LowerThresholdRight)-1)

			-- Variable used in the select
			set @convertedLowerThreshold = (try_cast(@LowerThresholdLeft as decimal(10,2))/100)

			-- Remove the minimum string and the value from the filter (so other given filters can be used - the where clause)
			set @filter = replace(@filter,'low='+@LowerThresholdLeft, '')

		end

	--__________________________________________

		-- Showing the wine name, market price and vintage listings
		select top (@records)
			w.clean_name as 'Wine Name' 
		,	wvp1.vintage as 'Vintage'
		,	dbo.fnDisplay(avg(wvp2.current_price),char(163),'n/a','en') as 'Average Market Price' 
		,	dbo.fnDisplay((wvp1.current_price),char(163),'n/a','en') as 'Current Market Price'

		-- Returning the percentage difference between the average market price and the original market price 
		,	format(try_cast(((avg(wvp2.current_price)/wvp1.current_price)) - 1 as decimal(10,2)), 'P') as  'Price % Difference According To Thresholds'

		from wine w with (nolock)

		-- Joining two sets of the same table so that the rows are layeredso the average can be found
		--(top 3 and bottom 3, making sure they have the same vintage)

		join wine_vintage_price wvp1 with(nolock) on w.wine_id = wvp1.wine_id 
		join wine_vintage_price wvp2 with(nolock) on wvp2.vintage >= wvp1.vintage - 3
		and wvp2.vintage <= wvp1.vintage + 3
		and wvp2.vintage <> wvp1.vintage 

		-- Making sure the set columns/fields are equaled accordingly (region, currency, and wine ID), and the wine is not disabled
		and wvp2.wine_id = wvp1.wine_id 
		and wvp2.disabled = 0
		and wvp2.currency_ref = wvp1.currency_ref 
		and wvp2.region_ref = wvp1.region_ref 

		where 

		w.reference_type='wine' 
		and isnull(w.[disabled],0)=0
		and w.owner_id = 0
		and	wvp1.vintage > 1950 
		and wvp1.disabled = 0
		and wvp1.region_ref ='Europe' and wvp1.currency_ref = 'GBP'

		-- Applying filters
		and (
		isnull(@filter,'') = '' 
		or 
		(w.name like '%'+@filter+'%'
		or w.short_name like '%'+@filter+'%'
		or w.ws_name like '%'+@filter+'%'
		or w.country_ref like '%'+@filter+'%'
		or w.region like '%'+@filter+'%'
		or w.sub_region like '%'+@filter+'%'
		or w.wine_type like '%'+@filter+'%'
		or w.wine_sub_type like '%'+@filter+'%')
	    )

		-- A group by is setting the table to view the a single row with the averaged price given it being the same vintage
		group by wvp1.wine_id, wvp1.vintage, w.clean_name, wvp1.current_price, wvp1.region_ref, w.region
				
		-- Thresholds
		having
		 ( 
			try_cast(((avg(wvp2.current_price)/wvp1.current_price)) - 1 as decimal(10,2)) > @convertedHigherThreshold
			OR
			try_cast(((avg(wvp2.current_price)/wvp1.current_price)) - 1 as decimal(10,2)) < @convertedLowerThreshold
		 )
		order by wvp1.wine_id, wvp1.vintage


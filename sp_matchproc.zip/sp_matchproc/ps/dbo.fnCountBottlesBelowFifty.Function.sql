IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnCountBottlesBelowFifty]')  AND type = N'FN')
     DROP FUNCTION [dbo].[fnCountBottlesBelowFifty]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE FUNCTION [dbo].[fnCountBottlesBelowFifty]
(
	--@organisation_id as int,
	@user_id as int,
	@cellar_id as int,
	@mixed_case_id as int,
	@options varchar(50) = null

)
RETURNS integer
AS
BEGIN

	-- =============================================
	-- Author:		Deepali Kerai
	-- Create date: 2016-06-17
	-- Description:	Return total number of bottles left per user when stock is below 50
	-- =============================================

	/*
		declare @tmp varchar(max) = ''
		select @tmp = dbo.fnCountBottlesBelowFifty(18684,1,'')
		print @tmp

	-- dbo.fnMultiple( isnull(dbo.fnCountBottles(owner_id,cellar_id, null, ''),0),'bottle','en','ADD-NUMBER')
	-- [dbo].[fnCountBottles](@organisation_filter_id,@cellar_filter_id,@mixed_case_filter_id,'') as 'total_bottles'

	*/
	
	declare @organisation_id as int = (select organisation_id from [user] where user_id = 18684)
	declare @bottles_count int

	-- if we have a mixed case id just count this mixed case 
	if isnull(@mixed_case_id,0) > 0
		select @bottles_count = SUM(isnull(no_bottles, 0))
						from wine_entry we with (nolock) 
						left join cellar c with (nolock) on we.cellar_id = c.cellar_id
						where
						c.owner_id = @organisation_id
						and isnull(we.disabled,0)=0
						and we.mixed_case_id = @mixed_case_id
						and we.status = 'active'

	-- if we have a cellar
	else if isnull(@cellar_id,0) > 0
		select @bottles_count = SUM(isnull(no_bottles, 0))
						from wine_entry we with (nolock) 
						left join cellar c with (nolock) on we.cellar_id = c.cellar_id
						where
						c.owner_id = @organisation_id
						and isnull(we.disabled,0)=0
						and we.cellar_id = @cellar_id
						and we.status = 'active'

	-- else count all bottles
	else 
		select @bottles_count = SUM(isnull(no_bottles, 0))
						from wine_entry we with (nolock) 
						left join cellar c with (nolock) on we.cellar_id = c.cellar_id
						where
						c.owner_id = @organisation_id
						and isnull(we.disabled,0)=0
						and we.status = 'active'

	
	-- and return
	return @bottles_count 
	
END


-- pass in the user id to this script
-- get the organisation is belongs to


--declare @organisation_id as int = (select organisation_id from [user] where user_id = 18684)

--print @organisation_id




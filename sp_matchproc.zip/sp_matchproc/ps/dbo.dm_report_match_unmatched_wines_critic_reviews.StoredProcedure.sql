
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_match_unmatched_wines_critic_reviews]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_match_unmatched_wines_critic_reviews]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-04-9
-- Description: Attempt to match unmatched wines found from critic reviews
-- =============================================

CREATE PROCEDURE [dbo].[dm_report_match_unmatched_wines_critic_reviews]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'Number of rows',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      
as    

	declare @unmatched_popup varchar(max) = dbo.fnGetContentDescriptionDefault(
		@user_id
	, @settings
	,'INSERT_UNMATCHED_CRITIC_WINE_POPUP',N'')


/*	

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_match_unmatched_wines_critic_reviews @user_id,@settings,'X',@out_msg, ''
	print @out_msg

declare @id int
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_match_unmatched_wines_critic_reviews', 'WO', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Critic review unmatched wines" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)


*/

---------------------------------------
		
		select top (@records)
		--ROW_NUMBER() OVER (Order by tr.critic_wine_desc) ,
		 tr.critic_wine_desc as 'Critic Wine Name'
		, replace(replace(replace(@unmatched_popup
			, '{critic_wine_desc}',isnull(cast(tr.critic_wine_desc as varchar(800)),''))
			, '{No.}', row_number() over(order by tr.critic_wine_desc))
			, '{potential_wine}', tr.packaging)
			--, '{tasting_id}', tr.tasting_id) -- removed because we wanted to group the same names, cant do that with unique IDs
			as 'Match Wine'
		, tr.packaging as 'Potential Match (in db)'
		, count(*) as 'Number of rows'
		from tasting_note_or_review tr
		
		where tr.wine_id is null
		and tr.packaging is not null
		and (tr.critic_name = 'Robert Parker'
			or tr.critic_name = 'jancis'
			or tr.critic_name = 'vinous')
		and disabled = 0
		and isnull(owner_id,0) = 0

		and 
		(isnull(@filter,'') = '' or
		       (tr.critic_wine_desc like '%'+@filter 
			   or
			   tr.critic_wine_desc like '%'+@filter+'%' 
			   or
			   tr.critic_wine_desc like @filter+'%')
		)	   
		
		group by tr.critic_wine_desc,
		tr.packaging--, tr.tasting_id

		order by

		case @sort_direction when 'asc' then
			case @sort_by
				when 'Critic Wine Name' then tr.critic_wine_desc
				when 'Potential Match (in db)' then tr.packaging
				when 'Number of rows' then cast(1000000000 +count(1) as varchar(20))
			End

		end asc,

		case @sort_direction when 'desc' then
			case @sort_by
				when 'Critic Wine Name' then tr.critic_wine_desc
				when 'Potential Match (in db)' then tr.packaging
				when 'Number of rows' then cast(1000000000 +count(1) as varchar(20))
			end
		end	desc
		




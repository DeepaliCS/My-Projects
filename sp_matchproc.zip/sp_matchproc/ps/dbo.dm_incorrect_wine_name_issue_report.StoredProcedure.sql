IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_incorrect_wine_name_issue_report]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_incorrect_wine_name_issue_report]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[dm_incorrect_wine_name_issue_report]
	
	@user_id int,					
	@settings varchar(500) ='',		
	@sql_logging varchar(1) ='X',	
	@output_message as varchar(max) OUTPUT,

	@target_id int

as	

	/*

	-- Deepali 2019-03-25
	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @user_id int = 34470
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''

	EXEC st_event @user_id,@settings,@sql_logging,@output_message OUTPUT
		,'INCORRECT_WINE_NAME_ISSUE', @user_id, 'N', null
		,null, null, null, null
		,'target_id',@user_id,'comments','dm_incorrect_wine_name_issue_report'

	*/


Begin

	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='incorrect_wine_name_issue_report'
	declare @object_name as varchar(50) = 'dm_incorrect_wine_name_issue_report'
	declare @audit_exception varchar(500) = ''

	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
		+ ' User_id: ' + ISNULL(cast(@target_id as varchar(10)),'')

	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

		declare @organisation_id int = 0
		declare @username varchar(100) = ''
		declare @forename varchar(50)= ''
		declare @message varchar (max) =''
		declare @email varchar (50) =''
		declare @output_msg varchar (max) =''
		declare @user_brand varchar(20)
		declare @user_access varchar(10)
		declare @comments varchar(max)= 
		'<table border="1" style="border-color: #cccccc;
		border-width: 1px;
		border-style: solid; " rules="rows" width="100%"> 
			<col width="15%"> 
			<col width="45%"> 
			<col width="40%"> 
		<tr style="background-color: #eeeeee; color: #666666; font-family: Helvetica;"> 
			<th>Issue Date</th> 
			<th>Wine name</th> 
			<th>Comments</th> 
		</tr> 
		<tbody>'

	select /*	order of table columns: Issue date, [Vintage, Wine name] Comment	*/
		z.[Wine Issue Date],
		'<a style=''color: #338bac;'' href=''https://www.wineowners.com/wine.aspx?wi='
		+CAST(z.wine_id AS VARCHAR(100))
		+'&v='
		+CAST(z.vintage AS VARCHAR(100))
		+'&tab=#trade''>'
		+z.[Wine] +'</a>' as 'Wine'
		,z.[Issue Comment]
		into #Comments
 				
		from
		(
		select 
		left(wi.created, 11) as 'Wine Issue Date'
		, CASE wi.vintage WHEN NULL THEN 'NV' ELSE CAST(wi.vintage as varchar(10)) END +' '
		+ dbo.fnGetDisplayShortName(@user_Id,'',@organisation_id,wi.wine_ID,'WO','') as 'Wine'
		, wi.wine_Id
		, wi.vintage
		, wi.comments as 'Issue Comment'

			from wine_issue wi
			where wi.issue_ref = 'Incorrect wine name'
			and wi.disabled = 0
			and wi.comments not like '%test%'
			and wi.comments not like '%blah%'
		) z

		SELECT
		@comments = @comments 
		+STUFF( 
			  (
			  select
			  '<tr style="background-color: #f6e8e7; color: #666666; font-family: Helvetica;"> 
			  <td align="left">'
			  + [Wine Issue Date]
			  + '</td>
			  <td align="center">'
			  + [Wine]
			  + '</td> <td align="left">' 
			  + [Issue Comment]
			  + '</td>'
			from #comments
			FOR XML PATH(''),type).value('.', 'nvarchar(max)'),1,0,'')
						
		Set @comments = @comments + ' </tbody></table>'

		Set @comments = 
			'<p class="p2" style="text-align: center;">
			<span class="s1" style="font-family: helvetica; font-size: 10pt; color: #666666;">--</span>
			</p>
			<p>
			<br/>
			</p>'
			+ @comments
			+ '</span></p>'

		--add all variables in list data
		Set @message = isnull(@comments,'')

		Set @email = 'deepali.kerai@wineowners.com'

		select @message as 'message', @email as 'emailTo', @forename as 'forename'

end




IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_popover_review_wine]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_popover_review_wine]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-04-16
-- Description: Test dm_report_popover_review_wine
-- =============================================

CREATE PROCEDURE [dbo].dm_report_popover_review_wine

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = '',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      
as    



/*	

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_popover_review_wine @user_id,@settings,'X',@out_msg, ''
	print @out_msg

declare @id int
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_popover_review_wine', 'WO', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text=" A dm_report_popover_review_wine" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)


*/

	declare @review_popup varchar(max) = dbo.fnGetContentDescriptionDefault(
		 @user_id
	, @settings
	,'POPOVER_REVIEW_WINE',N'')

select top (@records)

wine_id as 'wine id'
, wine_entry_id as 'wine entry id'
, wine_name as 'wine name'


, (replace(replace(replace(replace(@review_popup
	, '[db wine_id]', wine_id)
	, '[db vintage]', vintage)
	, '[db wine_entry_id]', wine_entry_id)
	, '[db wine_name]', wine_name)
  ) as 'Review Wine'


, vintage as 'vintage'
, bottle_qty as 'bottle qty'
, case_size as 'case size'
, duty_status as 'duty status'
, current_value_75 as 'current value'

from search_result





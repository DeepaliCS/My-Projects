IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_price_difference]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_price_difference]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-01-16
-- Description: Return report with major differences between market and purchase price
-- =============================================


CREATE PROCEDURE [dbo].[dm_report_price_difference]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'date',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      
as    


/*	

Sometimes people enter a purchase price for a wine that is really far away (at least 100%) from our market price for it. 
We want to check these wines to see if we should correct our market price or correct the purchase price.

Tables required: wine, wine_entry, wine_vintage_price (maybe wine_price)
Conditions: pick wine_entries that are active, have a purchase price (and a purchase date?), we have a WO market price, 
Columns: Wine Name, Vintage, purchase date, purchase price, market price, link to edit the wine_entry.

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_price_difference @user_id,@settings,'X',@out_msg, 'High=50'
	print @out_msg

declare @id int 
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_price_difference', 'WO', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Big price differences" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
-- select * from lookup where category = 'StoredProcedure'
-- report documentation


*/
	
	--varchar declarations for input low and high price threshold values from filter
	declare @lowerThresholdvarchar varchar(100) = ''
	declare @HigherThresholdvarchar varchar(100) = ''

	--decimal declarations for the processing of input price threshold values from filter
	declare @HigherThresholdDec decimal(10,2) =0
	declare @LowerThresholdDec decimal(10,2) =0

	--declaring the brand filter variable which is later calls the function to extract the brand from the settings
	declare @brand varchar(50)

	--Default values set if the high and low thresholds are not set
	if (@filter not like '%High=%') and (@filter not like '%Low=%')

		begin

			set @HigherThresholdDec = 75.00
			set @LowerThresholdDec = 25.00
	
		end 

	--Extract the higher-end threshold value
	if @filter like '%High=%'
		begin

			--Extract the number after 'high'
			set @HigherThresholdvarchar = RIGHT(@filter,LEN(@filter)-charindex('high',@filter)-len('high=')+1)+ ' '

			--Higher-end threshold for extreme differences in market and purchased prices
			--Variable used for condition in the select statement (where) because the type is decimal
			set @HigherThresholdDec = LEFT(@HigherThresholdvarchar, charindex(' ',@HigherThresholdvarchar)-1)

		end

	--Extract the lower-end threshold value
	if @filter like '%Low=%'  
		begin

			--Extract the number after 'low'
			set @lowerThresholdvarchar = RIGHT(@filter,LEN(@filter)-charindex('low',@filter)-len('low=')+1)+ ' '

			--Lower-end threshold for extreme differences in market and purchased prices
			--Variable used for condition in the select statement (where) because the type is decimal
			set @LowerThresholdDec = LEFT(@lowerThresholdvarchar, charindex(' ',@lowerThresholdvarchar)-1)

		end
		

	--Set brand to 'wo' by default if the brand is not set in the filters
	if (@filter not like '&brand%')
		begin

			--Use the function extract the brand name from settings (parameter)
			set @brand = dbo.fnGetPiece(@settings,3,'~','wo')

		end


	--Selecting the fields purchase date, market price, purchase price, price difference and **threshold price
	select top (@records)
		w.clean_name as 'Wine Name' 
	,	wvp.vintage as 'Vintage' 
	,	try_cast(isnull(we.acquired_date, we.status_date)as date) as 'Acquired/ Status'
	,	try_cast((wvp.current_price) as decimal(10,2)) as 'Market Price'
	,	try_cast((we.price) as decimal(10,2)) as 'Purchased Price'
	,	format(try_cast(((wvp.current_price/we.price)) - 1 as decimal(10,2)), 'P') as  'Price % Difference According To Thresholds'
	,   o.brand_ref as 'Brand'

	--Joining tables wine, wine vintage price to wine_entry, - brand tables: cellar, organisation
	from wine_entry we with (nolock)
	join wine w on w.wine_id = we.wine_id
	join wine_vintage_price wvp on w.wine_id = wvp.wine_id and wvp.vintage = we.vintage and wvp.region_ref = 'Europe' and wvp.currency_ref = 'GBP'
	join cellar c on we.cellar_id = c.cellar_id
	join organisation o on c.owner_id = o.organisation_id

	--Conditions including active, bottle size, thresholds
	where we.disabled = 0 and we.status = 'Active'�
	and try_cast(bottle_size_ref as decimal(10,2)) = 75

	--Where the threshold price are within the threshold boundaries given from the filter
	and ( 
		((wvp.current_price/we.price)*100) < @LowerThresholdDec
		OR ((wvp.current_price/we.price)*100) > @HigherThresholdDec
	)

	--Only counting the prices dont have a purchase price of 0
	and we.price > 0

	--Only considering the brands that the user has set in the filters
	and o.brand_ref like '%'+@brand+'%'




	

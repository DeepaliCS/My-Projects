IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_email_high_matched_bids]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_email_high_matched_bids]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

	-- =============================================
	-- Author:		Deepali
	-- Create date: 22/05/2019
	-- Description:	Used to run st event to send email to owners who have bids placed over the high price alert
	-- =============================================


CREATE PROCEDURE [dbo].[dm_email_high_matched_bids]

	@settings as varchar(500) ='',	
	@user_id int,						
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT,
	@organisation_id int


	/*

	declare @settings varchar(max) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
	declare @user_id int = 34470
	declare @sql_logging varchar(1) = 'X'
	declare @output_message varchar(1000) = ''
	declare @organisation_id int = 52592


	EXEC st_event 
	  @user_id
	, @settings
	, @sql_logging
	, @output_message OUTPUT
		, 'WO_TRACKED_BIDS' 
		, @user_id
		, 'N'
		, null
		, null
		, null
		, null
		, null
		, '@organisation_id'
		, 52592
		,'tracked_bids_info'
		,'dm_email_high_matched_bids'

	--exec [dm_email_high_matched_bids] @settings, @user_id , @sql_logging, null, @organisation_id

	*/


as	
begin



	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) ='email_high_matched_bids'
	declare @object_name as varchar(50) = 'email_high_matched_bids'
	declare @audit_exception varchar(500) = ''
	
	declare @trading_currency_symbol varchar(10) = dbo.fnGetPiece(@settings,13,'~',char(163))
	
	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')
		+ ' User_id: ' + ISNULL(cast(@user_id as varchar(10)),'')

	-- optional logging
	if @sql_logging ='Y'
		exec st_audit @user_id, @settings, @object_name, @transaction_name, 'select', @input_fields

	declare @forename varchar(50)= ''
	declare @message varchar (max) = ''
	declare @email varchar (50) = ''
	declare @tracking_open_bids as varchar(max)
	declare @user_email_Id int = dbo.fnGetOrganisationUser(@organisation_id)

	IF OBJECT_ID('#display_table', 'U') IS NOT NULL
		drop table #display_table


	--declare @organisation_id int
	--set @organisation_id = 52592

	-- Getting the fields for the table to be displayed on the email
	select
		t.owner_id
		, wo.wine_order_id
		, wo.order_type
		--, wo.order_status
		, wo.valid_till
		, w.wine_Id
		, w.name
		, wo.vintage
		, wo.quantity
		, wo.case_size
		, wo.bottle_size_ref
		, wo.case_Price
		, wo.open_bid_tax_status
		, wo.created
		, 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2))) as standard_format_price
		, row_number() OVER(partition by w.name, wo.vintage, wo.bottle_size_ref, wo.case_size, wo.open_bid_tax_status order by 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2))) desc) as r
		, t.high_price_alert
	into #display_table				
		
	from wine_order wo
			
	join tracking t on wo.wine_ID = t.wine_id
		and wo.vintage = t.vintage
		and isnull(t.disabled,0) = 0
		and isnull(t.is_tracked,'N') = 'Y'
		and t.high_price_alert <= 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2)))
			
	join wine w on w.wine_id = wo.wine_id
	-- left join to select ones that are null - completely new to matched order (new bids)
	left join matched_order mo on wo.wine_Id = mo.wine_Id and wo.vintage = mo.vintage
		and 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2))) <= mo.case_price and mo.match_from = 'T'
	left join [user] u on mo.emailed_user_id = u.[user_id]
		and	t.owner_id = u.organisation_Id
					
	where (wo.order_type = 'B' and wo.order_status = 'O')
		and u.[user_Id] is null
		and t.owner_id = @organisation_id
		and wo.buyer_Id <> t.owner_Id
		-- for TWIF
		and wo.open_bid_tax_status = 'IB'

	-- Settingt the column names
	select @tracking_open_bids = 

		'<table border="1px" style="border-color:#cccccc; border-style:solid; border-spacing: 0px !important">' +
		
		 '<tr>'
		+'<th>Name</th>'
		+'<th>Vintage</th>'
		+'<th>Bid Quantity</th>'
		+'<th>Bid Case Size</th>'
		+'<th>Bid Price</th>'
		+'<th>Bid Tax Status</th>'
		+'<th>Your 12x75cl equivalent alert</th>'
		+'</tr>'

	-- Setting the data in the relevant columns 
	select
		@tracking_open_bids = @tracking_open_bids + 
			stuff(
			(select										
				
			'<tr>' +
				'<td align="left">'+isnull(dt.name, '')+'</td>' +
				'<td align="left">'+lower(isnull(dt.vintage, ''))+'</td>' +
				'<td align="left">'+lower(isnull(dt.quantity, ''))+'</td>' +
				'<td align="left">'+lower(isnull(dt.case_size, ''))+ ' x ' +lower(isnull(dt.bottle_size_ref, ''))+'</td>' +
				'<td align="left">'+dbo.fnDisplay(dt.case_price,@trading_currency_symbol,0,'en')+'</td>' +
				'<td align="left">'+isnull(dt.open_bid_tax_status, '')+'</td>' +
				'<td align="left">'+dbo.fnDisplay(dt.high_price_alert,@trading_currency_symbol,0,'en')+'</td>'
			+'</tr>'
				from #display_table dt 
				where r = 1
				order by name, vintage
				for xml path(''),type).value('.', 'nvarchar(max)')
			-- put on first position, dont truncate (0) and no replace
				,1,0,'')

	-- add end table
	select @tracking_open_bids = @tracking_open_bids + '</table>'
			
	-- Inserting current high alert bids into the matched_order table for future comparisons
	insert into matched_order(
		match_from
		, matched
		, checked
		, emailed_user_id
		, case_price
		, wine_Id
		, vintage
	)

	select 
		'T'
		, getdate()
		, getdate()
		, @user_email_Id
		, MAX(standard_format_price)
		, wine_Id
		, vintage
	from #display_table dt
	group by wine_Id
		, vintage
	
	select 'james.sowden@wineowners.com' as 'email_to' -- email
	, forename
	, surname
	, @tracking_open_bids as 'table'
	from [user]
	where [user_id] = @user_email_id

end




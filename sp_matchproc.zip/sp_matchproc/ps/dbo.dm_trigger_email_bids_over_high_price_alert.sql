
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_trigger_email_bids_over_high_price_alert]')  AND type = N'P')
     DROP PROCEDURE [dbo].[st_trigger_email_bids_over_high_price_alert]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


	-- =============================================
	-- Author:		Deepali
	-- Create date: 03/06/2019
	-- Description:	Prepare the high bid alert information before emails are sent to users
	-- =============================================


CREATE PROCEDURE [dbo].[st_trigger_email_bids_over_high_price_alert]

	 
	@user_id int,
	@settings as varchar(500) ='',	
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT
      
as    
begin



/*	

declare @user_id as int = 13
declare @settings varchar(500) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
declare @sql_logging varchar(1) ='X'
declare @output_message as varchar(500) =''

	exec st_trigger_email_bids_over_high_price_alert @user_id,@settings,@sql_logging,@output_message
	print @output_message

*/
		
	-- Loops the to run each individual owner id from #distinct_order_by_owner
		DECLARE @owner_id int
		DECLARE ITEM_CURSOR CURSOR

		FOR SELECT 
			distinct t.owner_id
			
		from wine_order wo
			
		join tracking t on wo.wine_ID = t.wine_id
			and wo.vintage = t.vintage
			and isnull(t.disabled,0) = 0
			and isnull(t.is_tracked,'N') = 'Y'
			and t.high_price_alert <= 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2)))
			
		join wine w on w.wine_id = wo.wine_id
		-- left join to select ones that are null - completely new to matched order (new bids)
		left join matched_order mo on wo.wine_order_id = mo.bid_order_id
			and wo.case_price = mo.case_price and mo.match_from = 'T'
		left join [user] u on mo.emailed_user_id = u.[user_id]
			and	t.owner_id = u.organisation_Id
					
		where (wo.order_type = 'B' and wo.order_status = 'O')
			-- only entering the ones that have a different bid price 
			and u.[user_Id] is null

		OPEN ITEM_CURSOR -- This charges the results to memory
 
			FETCH NEXT FROM ITEM_CURSOR INTO @owner_id -- We fetch the first result
 
			WHILE @@FETCH_STATUS = 0
			BEGIN	/* Start Iteration is done here */
			
				-- Show owner_ids their bid info will be sent to
				-- select owner_id from #email_list where owner_id = @owner_id

			PRINT @owner_Id

				EXEC st_event
				  @user_id
				, @settings
				, @sql_logging
				, @output_message OUTPUT
					, 'WO_TRACKED_BIDS' 
					, @user_id
					, 'N'
					, null
					, null
					, null
					, null
					, null
					, '@organisation_id'
					, @owner_id
					,'tracked_bids_info'
					,'dm_email_high_matched_bids'

				FETCH NEXT FROM ITEM_CURSOR INTO @owner_id
			END

	CLOSE ITEM_CURSOR
	DEALLOCATE ITEM_CURSOR
	---------------------

end

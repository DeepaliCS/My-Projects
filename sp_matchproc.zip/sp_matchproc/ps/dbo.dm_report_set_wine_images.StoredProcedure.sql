IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_set_wine_images]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_set_wine_images]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-01-22
-- Description: Return report with the average market price of specific wine, total number of entries in and the file images (used for the website)
-- =============================================


CREATE PROCEDURE [dbo].[dm_report_set_wine_images]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'date',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      

	 
	/*	

	This stored procedure is used to collect the total number of wines (entries) and the average market price for each wine(name)
	Also returning the html/bootstrap code to return the images of the given wine - used for the website

	Tables required: wine, wine_entry, wine_vintage_price 
	Conditions: region_ref = 'Europe', currency_ref = 'GBP'
	Columns: wine_id, clean_name, current_price, wine_entry_id, (wine image list)

	***Test for filters: 'minimum=5 spain'

	declare @out_msg as varchar(500) =''
	declare @user_id as int = 13
	declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

		exec dm_report_set_wine_images @user_id,@settings,'X',@out_msg, 'minimum=5 spain'
		print @out_msg

	declare @id int 
	select @id = MAX(lookup_id) from [lookup]
	
	INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
	[display_order], [is_default_entry], [notes], 
	[lookup_field_1], [lookup_field_2], [lookup_field_3], 
	[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
	VALUES ('StoredProcedure', 'dm_report_set_wine_images', 'WO', @id+1
	, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="Wines and their image Labels" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
	, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
	-- select * from lookup where category = 'StoredProcedure'
	-- report documentation


	*/

	as

	   -- Variables used to get the images and to be able to use them 
       declare @template_header varchar(8000) =''
       declare @template_lines varchar(4000) =''
       declare @template_upload_button varchar(4000) =''
	   declare @template_edit_label varchar(4000) =''

	   -- Variable for the threshold values
	   declare @minimum varchar(100) = ''
	   declare @minimumDec varchar(100) = ''


	   --_____________________________________________

	   	--Default value: display all, no minimum set
	if (@filter not like '%minimum=%') 

		begin

			set @minimum = 0
	
		end 


	   --Extract minimum value from the filter (More comments: dbo.dm_report_price_difference.storedprocedure)
	if @filter like '%minimum=%'
		begin

			set @minimum = RIGHT(@filter,LEN(@filter)-charindex('minimum',@filter)-len('minimum=')+1)+ ' '
			--print @minimum

			set @minimumDec = LEFT(@minimum, charindex(' ',@minimum)-1)
			--print @minimumDec

			-- Remove the minimum string and the value from the filter (so other given filters can be used - the where clause)
			set @filter = replace(@filter,'minimum='+@minimumDec, '')


			--print 'test' + @filter

		end

	   --_____________________________________________


	   -- The html/bootstrap code to be used to display the images of wine on the website

	   -- Where to get the images from and where to place them (html/bootstrap)
       select @template_header = dbo.fnGetContentDescriptionDefault(@user_id,@settings,'M_REPORT_LABELS_TEMPLATE_WINE_HEADER'
	   ,    N' <div class="row form-group">{data}</div>')

	   -- Picking up the image and the bootstrap/html code to be used on the website (correct alignment etc)
       select @template_lines = dbo.fnGetContentDescriptionDefault(@user_id,@settings,'M_REPORT_LABELS_TEMPLATE_WINE_LINE'
		,	N' <div class="col-xs-3 col-sm-2 col-md-2 col-lg-2"><a data-toggle="lightbox" data-type="image" data-title="{file_details}"
			href="/api/file.aspx?id={file_id}"><img src="/api/file-preview.aspx?id={file_id}" class="img img-responsive img-thumbnail" title="{file_name} - {created_date_time}" /></a></div>')

		---- Picking up the image and the bootstrap/html code to be used on the website (correct alignment etc)
  --     select @template_upload_button = dbo.fnGetContentDescriptionDefault(@user_id,@settings,'M_REPORT_LABELS_TEMPLATE_UPLOAD_BUTTON'
		--,	'<span title=''Upload label photo'' class=''btn btn-default btn-file-upload btn-image'' data-id=''{wine_Id}'' data-options=''&quot;type&quot;:&quot;image&quot;'' data-category=''Label'' data-type=''Wine''
  --         data-details=''Label for {wine_name}'' tabindex=''0''><span class=''icon-camera''></span></span>')

		-- Picking up the image and the bootstrap/html code to be used on the website (correct alignment etc)
       select @template_edit_label = dbo.fnGetContentDescriptionDefault(@user_id,@settings,'M_REPORT_LABELS_TEMPLATE_EDIT_LABEL', '')
	
	

			----- putting avg prices into tmp table

			select  wine_id, avg(current_price) as avg_price
				into #tmp
			from wine_vintage_price
			where isnull([disabled],0)=0 and region_ref='Europe' and currency_ref='GBP'
			group by wine_id
			
			select wine_id, COUNT(1) as nb_entries
				into #tmp2
			from wine_entry
			where isnull([disabled],0)=0 and status = 'Active'
			group by wine_id

		--_____________________________________________


	-- Aggregates: Averaging all the market prices that have the same wine name & Counting the number of entries of the same wine  

	  select top (@records)
	    w.wine_id,
		w.clean_name as 'Wine Name'
	  , dbo.fnDisplay(t.avg_price,char(163),'n/a','en') as 'Market Price'
	  , t2.nb_entries as 'Total number of Entries'

	  -- Function used to return the wine type - colour - red, white etc (used in website)
	  , dbo.fnGetWineBottle(@user_id,@settings,w.wine_type,w.wine_sub_type,'') as 'Type'

	  --Both buttons in the same column
	  , REPLACE(REPLACE(@template_edit_label,'{wine_Id}',CAST(w.wine_Id as varchar(20))),'{wine_name}',w.clean_name)
		as 'Actions'

	  -- Getting the correct images (according to wine_id) and using the function with the template header and template lines 
	  , dbo.fnWineImageList(@user_id,@settings, w.wine_id, 'Label', 'Wine', 5, '', @template_lines, @template_header)  as 'Photos'
		
	from wine w with(nolock)
	join #tmp t on w.wine_ID = t.wine_ID
	left join #tmp2 t2 on w.wine_Id = t2.wine_Id
	-- Applying filters for fields from the wine table
	where w.reference_type='wine' 
			and isnull(w.[disabled],0)=0
			and w.owner_id = 0
			and t2.nb_entries > @minimumDec
			and (
				isnull(@filter,'') = '' 
				or 
				(w.name like '%'+@filter+'%'
				or w.short_name like '%'+@filter+'%'
				or w.ws_name like '%'+@filter+'%'
				or w.country_ref like '%'+@filter+'%'
				or w.region like '%'+@filter+'%'
				or w.sub_region like '%'+@filter+'%'
				or w.wine_type like '%'+@filter+'%'
				or w.wine_sub_type like '%'+@filter+'%'))


	-- The column names are the fields that the admin user can choose to order by (ascending or descending)
	order by 
	case @sort_direction when 'asc' then
		case @sort_by
			when 'Wine Name' then w.clean_name 
			when 'Market Price' then CAST(t.avg_price as varchar(50))
			when 'Total number of Entries' then CAST(t2.nb_entries as varchar(20))
			when 'Type' then w.wine_type+' '+w.wine_sub_type
		end
	end asc,

	case @sort_direction when 'desc' then
		case @sort_by
			when 'Wine Name' then w.clean_name
			when 'Market Price' then CAST(t.avg_price as varchar(50))
			when 'Total number of Entries' then CAST(t2.nb_entries as varchar(20))
			when 'Type' then w.wine_type+' '+w.wine_sub_type
		end
	end desc

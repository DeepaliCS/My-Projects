
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[dm_report_unmatched_wines]')  AND type = N'P')
     DROP PROCEDURE [dbo].[dm_report_unmatched_wines]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- =============================================
-- Author:      Deepali
-- Create date: 2019-01-18
-- Description: Return report with distinct wines that are not matched with wines in our database
-- =============================================

CREATE PROCEDURE [dbo].[dm_report_unmatched_wines]

      @user_id Int,
      @settings varchar(500),
	  @sql_logging varchar(1) = 'X',
	  @output_message varchar(1000) ='' OUTPUT,
	  

      @filter varchar(100) = '',
	  @sort_by varchar(50) = 'date',
	  @sort_direction varchar(10) = 'desc',
	  @records int = 999
      
as    

/*	

declare @out_msg as varchar(500) =''
declare @user_id as int = 13
declare @settings varchar(100) = '192.145.12.233~session1234~WO~Europe~GBP~en'

	exec dm_report_unmatched_wines @user_id,@settings,'X',@out_msg, ''
	print @out_msg

declare @id int 
select @id = MAX(lookup_id) from [lookup]
	
INSERT INTO [dbo].[lookup] ([category], [reference], [brand_ref], [lookup_id], [description], 
[display_order], [is_default_entry], [notes], 
[lookup_field_1], [lookup_field_2], [lookup_field_3], 
[disabled], [created], [created_by], [updated], [updated_by], [stamp]) 
VALUES ('StoredProcedure', 'dm_report_unmatched_wines', 'WO', @id+1
, '<ArrayOfItem xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema"><item lang="en" text="View unmatched wines found from tasting notes" fromGoogle="false"/><item lang="fr" text="" fromGoogle="false"/></ArrayOfItem>'
, 5, 'N', NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, 1)
-- select * from lookup where category = 'StoredProcedure'
-- report documentation


*/

--	 Exploring distinct unmatched wine data, according to critics, possible matches 
-------------------------------------
	-- distinct wines between critics that have not been matched
	select count(*) as 'Wines that have not been matched'
	, critic_name  
	 from matching_db.dbo.wo_match_wines wmw
		join tasting_note_or_review tr 
		on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS
	
	where wine_id is null
	group by critic_name, provenance
---------------------------------------
	-- distinct wines between critics that have not been matched BUT have possible matches
	select count(*) as 'Wines that have possible matches'
	, critic_name as 'by Critic'
	from matching_db.dbo.wo_match_wines wmw
		join tasting_note_or_review tr
		on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS
	
	where wine_id is null and packaging is not null
	group by critic_name, provenance
---------------------------------------
	-- distinct wines between critics that have not been matched AND have no potential match
	select count(*) as 'Wines that don''t have possible matches'
	, critic_name as 'by Critic'
	from matching_db.dbo.wo_match_wines wmw
		join tasting_note_or_review tr 
		on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS
	
	where wine_id is null and packaging is null
	group by critic_name, provenance

-------------------------------------
	/*
	Wines that have the exact same critic wine desc and packaging (and their count etc.)
	*/

	select 
		tr.critic_wine_desc
		, tr.condition_notes as 'Region'
		, tr.critic_name as 'Critic'
		, tr.packaging
		, COUNT(1) as 'Count'
		
	from tasting_note_or_review tr
	where 
	tr.wine_id is null
    and tr.packaging is not null
		
	group by 
	tr.critic_wine_desc
	, tr.condition_notes 
	, tr.condition
	, tr.critic_name
	, tr.packaging
	having count(*) > 4
	order by count(*) desc
-------------------------------------






		




IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_email_new_bids_to_cellar]')  AND type = N'P')
     DROP PROCEDURE [dbo].[st_email_new_bids_to_cellar]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


	-- =============================================
	-- Author:		Deepali
	-- Create date: 03/06/2019
	-- Description:	Send email to each organisation on new bids in their cellar
	-- =============================================


CREATE PROCEDURE [dbo].[st_email_new_bids_to_cellar]

	 
	@user_id int,
	@settings as varchar(500) ='',	
	@sql_logging varchar(1) ='X',
	@output_message as varchar(max) OUTPUT

      
as    
begin

/*	

declare @user_id as int = 13
declare @settings varchar(500) = '127.0.0.1~fh22p3c32hm0jsm0upooubp4~WO~Europe~GBP~en~�~test2_wo_main~https://www.wineowners.com~Europe~GBP~�~�~GBP~M~WO'
declare @sql_logging varchar(1) ='X'
declare @output_message as varchar(500) =''

	exec st_email_new_bids_to_cellar @user_id,@settings,@sql_logging,@output_message
	print @output_message

*/
	
	-- Loops the to run each individual owner id from #distinct_order_by_owner
	DECLARE @owner_id int
	DECLARE ITEM_CURSOR CURSOR

	FOR select distinct top 3 
	c.owner_id

	from wine_entry we

		join wine w on w.wine_id = we.wine_id

		join wine_order wo on w.wine_id = wo.wine_id
			and wo.vintage = we.vintage
			and wo.case_size = we.case_size_ref
			and wo.bottle_size_ref = we.bottle_size_ref
			
		join cellar c on we.cellar_id = c.cellar_id
		and c.bonded_type like 'IB'

		left join matched_order mo on wo.wine_Id = mo.wine_Id and wo.vintage = mo.vintage
			and 12*(wo.case_price/wo.case_size)*(75.00/CAST(wo.bottle_size_ref as decimal(12,2))) <= mo.case_price
			and mo.match_from = 'K'

		left join [user] u on mo.emailed_user_id = u.[user_id]
			and	c.owner_id = u.organisation_Id

		where
			(wo.order_type = 'B' and wo.order_status = 'O')
			and u.[user_Id] is null
			--and c.owner_id = @organisation_id
			--and wo.buyer_Id <> c.owner_Id

			and c.bonded_type like 'IB' 
			and wo.open_bid_tax_status like 'IB' 
			and we.bonded_type like 'IB'

			and isnull(we.disabled,0) = 0
			and isnull(we.status,'') = 'Active'
			and isnull(wo.disabled,'') = 0

		OPEN ITEM_CURSOR -- This charges the results to memory
 
			FETCH NEXT FROM ITEM_CURSOR INTO @owner_id -- We fetch the first result
 
			WHILE @@FETCH_STATUS = 0
			BEGIN	/* Start Iteration is done here */

			PRINT @owner_Id

				EXEC st_event
				  @user_id
				, @settings
				, @sql_logging
				, @output_message OUTPUT
					, 'OPEN_BIDS_CELLAR'
					, @user_id
					, 'N'
					, null
					, null
					, null
					, null
					, null
					, '@organisation_id'
					, @owner_id
					,'open_bids_cellar_data'
					,'dm_email_new_bids_to_cellar'

				FETCH NEXT FROM ITEM_CURSOR INTO @owner_id
			END

	CLOSE ITEM_CURSOR
	DEALLOCATE ITEM_CURSOR
	---------------------

end

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnCountNumberOfUpliftsFor67]')  AND type = N'FN')
     DROP FUNCTION [dbo].[fnCountNumberOfUpliftsFor67]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


create FUNCTION [dbo].[fnCountNumberOfUpliftsFor67]
(
	@user_id int,
	@settings varchar(500),
	@more_than as decimal(10,2) =0,
	@less_than decimal(10,2) =0,
	@options varchar(100)
)
RETURNS integer
AS
BEGIN

	-- =============================================
	-- Author:		Deepali 
	-- Create date: 2019-05-09
	-- Description:	Return total number rows that have an uplift given the percentage constraints
	-- =============================================

	/* 	
	Test with ..

	  declare @more_than as decimal(10,2) =40
	  declare @less_than decimal(10,2) =49
	  select dbo.fnCountNumberOfUpliftsFor67(213, '', @more_than , @less_than, '')
	
	*/


	declare @no_of_uplift_rows int
	
		select @no_of_uplift_rows = count(1)
		from wine_entry we with (nolock)
		join wine w with (nolock) on we.wine_id = w.wine_id
		join wine_vintage_price wvp with (nolock) on we.wine_id = wvp.wine_id
			and we.vintage = wvp.vintage
			and isnull(wvp.disabled,0)=0
			and wvp.currency_ref = 'GBP'
			and wvp.region_ref = 'Europe'
		join user_defined_field udf with (nolock) on we.wine_entry_id = udf.record_id
			and udf.brand_ref = '67'
			and udf.table_name = 'wine-entry'
	
		-- This table don't include all info from 67 
		join temp_wine_list_result twlr with (nolock) on we.wine_entry_id = twlr.wine_entry_id

		where
			(try_cast(udf.value_2 as int)) <> 0
		and (try_cast(udf.value_2 as int))  <> ''
		and (try_cast(udf.value_11 as decimal(10, 4))) <> 0
		and (try_cast(udf.value_11 as decimal(10, 4)))  <> 0
		and isnull(wvp.current_price,0) > 0
		and isnull(we.disabled, 0) = 0
		and we.status = 'Active'
		and try_cast(udf.value_12 as int) > 1
		and (try_cast((((try_cast(wvp.current_price as int)) - (try_cast(udf.value_11 as decimal(10, 4)))) / (try_cast(udf.value_11 as decimal(10, 4)))) as decimal (10,2))*100 < @less_than
				and
					try_cast((((try_cast(wvp.current_price as int)) - (try_cast(udf.value_11 as decimal(10, 4)))) / (try_cast(udf.value_11 as decimal(10, 4)))) as decimal (10,2))*100 > @more_than)

	return @no_of_uplift_rows


END




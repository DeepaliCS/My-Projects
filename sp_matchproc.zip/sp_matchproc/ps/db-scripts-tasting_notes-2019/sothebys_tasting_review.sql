
-- =============================================
-- Author:      Deepali
-- Create date: 2019-07-23
-- Description: Populate Sotheby's review notes (data) into tasting review table
-- =============================================



--select * from sbys_Tasting_Notes_230719
--drop table [sbys_Tasting_Notes_230719]
--select top 100 * from test2_wo_main.dbo.tasting_note_or_review

DROP TABLE IF EXISTS #Temp
select * into #Temp from (select * from matching_db.dbo.sbys_Tasting_Notes_230719) alias
--select * from #Temp
--drop table #Temp


--select * from sbys_Tasting_Notes_230719
---------------------

print 'Begin Script'

alter table #Temp add review_type_ref varchar(500);
alter table #Temp add wine_id int;
alter table #Temp add vintage int;
alter table #Temp add critic_wine_desc varchar(500);
alter table #Temp add review_date date;
alter table #Temp add provenance varchar(500);
alter table #Temp add paraphrase_extract varchar(8000);
alter table #Temp add personal_note varchar(500);
alter table #Temp add score_type varchar(500);
alter table #Temp add score_edited int; -- careful, it has the same name as the on in the original table
alter table #Temp add score_display varchar(500);
alter table #Temp add critic_id int;
alter table #Temp add critic_name varchar(500);
alter table #Temp add main_link varchar(500);
alter table #Temp add event_note varchar(500);

---------------------
go
print 'Updating Relevant data'

update #Temp set review_type_ref = 'CR';
update #Temp set wine_id = NULL; -- has to be done after matching
update #Temp set vintage = substring(LWIN,8,4);
update #Temp set critic_wine_desc = [Product Name];
update #Temp set review_date = CONVERT(datetime, '2019-07-22', 111); -- matching date of email
update #Temp set provenance = ''; -- has to be done after matching (if not matched)
update #Temp set paraphrase_extract = [Tasting Notes];
update #Temp set personal_note = [SKU Code];
update #Temp set score_edited = case when Score like '[0-9][0-9]-[0-9][0-9]' then (cast((left(Score,2)) as int) + cast((right(Score,2)) as int)) /2
									 when Score like '[0-9][0-9]-[0-9][0-9][0-9]' then (cast((left(Score,2)) as int) + cast((right(Score,2)) as int)) /2
									 when Score like '[0-9][0-9][0-9]-[0-9][0-9][0-9]' then (cast((left(Score,2)) as int) + cast((right(Score,2)) as int)) /2
									 when Score like '[0-9][0-9]+' then cast((left(Score,2)) as int)
									 when Score like '[0-9][0-9]-' then cast((left(Score,2)) as int)
									 when Score like '[0-9][0-9]' then Score
									 when Score like '0' then 0
							    end
update #Temp set score_type = '100';
update #Temp set score_display = [Score];
update #Temp set critic_id = 55;
update #Temp set critic_name = 'sothebys';
update #Temp set main_link = [Product Web Name];
update #Temp set event_note = [LWIN];

---------------------
go
print 'Begin Matching Process'

-- RUN ON TEST2_WO_MAIN DATABASE

declare @batch_id int
select @batch_id = max(batch_id)+1 from Matching_DB.dbo.wo_match_wines
print @batch_id

update parameter set parameter_value = @batch_id , updated = getdate(), updated_by = 213
where name = 'LAST_SOTHEBYS_UPDATE_BATCH_ID';

insert
into wo_match_wines (
	batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)

select
	@batch_id, '', z.incoming_wine_name, 'N'
	, 0, getdate(), 1, 1, ''

from
(select distinct [Product Name] as incoming_wine_name from #Temp) z
print @batch_id

exec wo_match_run 'clean', @batch_id, 'nosuspect' --@batch_id instead of numberexec wo_match_run 'Match', @batch_id, 'noround4'  --|regional

print 'Matching Wine IDs'

update s
	set s.wine_id = wmw.wo_wine_ID
	from #Temp s
	join wo_match_wines wmw
	on s.[Product Name] = wmw.incoming_wine_name COLLATE SQL_Latin1_General_CP1_CI_AS
	and wmw.batch_id = @batch_id and round_matched in (1,5)
go


---------------------

update #Temp set provenance = 'wine_id is null because wine did not match' where wine_id is null

---------------------

--** NOT including duplicates - because currently there's no data

---------------------

print 'Copying into tasting_note_or_review table'

declare @t_Id int
Select @t_Id = max(tasting_id) from tasting_note_or_review

insert into tasting_note_or_review (
tasting_id 
, review_type_ref
, wine_id
, vintage
, owner_id
, critic_wine_desc
, review_date
, publication_issue
, condition
, packaging
, provenance
, condition_notes
, paraphrase_extract
, tasting_note
, personal_note
, score_type
, score
, score_display
, wo_score
, critic_id
, critic_name
, expert_name
, recommended_drinking_start_date
, optimum_drinking_date
, recommended_drinking_end_date
, published
, disabled
, created
, created_by
, updated
, updated_by
, stamp
, main_link
, review_link
, serving_portion
, event_note
, user_score
)

select 
	@t_Id+ROW_NUMBER() OVER(ORDER BY critic_wine_desc)
,	review_type_ref
,	wine_id
,	vintage
,	0
,	critic_wine_desc
,	review_date
,	null
,	null
,	null
,	provenance
,	null
,	paraphrase_extract
,	null
,	personal_note
,	score_type
,	score_edited
,	score_display
,	null
,	critic_id
,	critic_name
,	null
,	null
,	null
,	null
,	'Y'
,	0
,	getdate()
,	0
,	getdate()
,	0
,	1
,	main_link
,	0
,	null
,	event_note
,	null

from #Temp

declare @max_date date
Select @max_date = MAX(review_date) from #Temp

-- Updating parameter value for when the last update was made with vinous reviews
update parameter set parameter_value = @max_date, updated = getdate(), updated_by = 213
where name = 'LAST_SOTHEBYS_UPDATE';

declare @batch_id int
select @batch_id = CAST(parameter_value as int) from parameter where name = 'LAST_SOTHEBYS_UPDATE_BATCH_ID'

-- Update packaging column - potential wine names
update tr
set tr.packaging = wmw.wo_wine_name -- potential wine name (no wine id)
--select tr.*
from tasting_note_or_review tr
join wo_match_wines wmw on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS and wmw.batch_id = @batch_id
where 
	wmw.wo_wine_name is not null
	and tr.provenance like 'wine_id is null because wine did not match'
	and tr.wine_Id is null
	and tr.critic_name = 'sothebys'


--select * from #Temp
--select * from tasting_note_or_review order by created desc






/*

-- =============================================
-- Author:      Deepali
-- Create date: 2019-02-14
-- Description: Populate vinous review notes (data) into tasting review table
-- =============================================


Please follow instructions on: https://docs.google.com/document/d/1D72dKhGP8xZ7_kct0uOXCSC84M6YDO-wUfgxnq0BnYA/edit
Current table name: vinous_1

*/

-- If needed..
--drop table [Vinous_reviews_2018_Q4]

print 'Begin Script'

alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add score_to_int1 varchar(500);
alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add score_type1 varchar(500);
alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add score_display1 varchar(500);
alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add provenance varchar(500);
alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add wo_wine_ID int;
--alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add created varchar(500);
--alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add updated varchar(500);

alter table matching_db.dbo.[Vinous_reviews_2018_Q4] add wineNameEdited varchar(500);


--alter table [Vinous_reviews_2018_Q4] add review_date varchar(500)
GO
print 'Added empty columns'

update matching_db.dbo.[Vinous_reviews_2018_Q4] set score_to_int1 = try_cast(round([indexable score],0) as int);
update matching_db.dbo.[Vinous_reviews_2018_Q4] set score_type1 = 100 where score_to_int1 > 50;
update matching_db.dbo.[Vinous_reviews_2018_Q4] set score_display1 = CAST([indexable score] as varchar(40)) + '/' + score_type1;
--update matching_db.dbo.[Vinous_reviews_2018_Q4] set critic_wine_desc  = replace(critic_wine_desc, 'NV', '');
--update matching_db.dbo.[Vinous_reviews_2018_Q4] set created = null;
--update matching_db.dbo.[Vinous_reviews_2018_Q4] set updated = null;

update matching_db.dbo.[Vinous_reviews_2018_Q4] set wineNameEdited = ([Producer] + ' ' + [Wine Name]);

GO
print 'Copied and Updated new columns'

-----------------------------------------

print 'Begin Matching Process'
declare @batch_id int
select @batch_id = max(batch_id)+1 from Matching_DB.dbo.wo_match_wines

update parameter set parameter_value = @batch_id , updated = getdate(), updated_by = 213
where name = 'LAST_VINOUS_UPDATE_BATCH_ID';

insert
into Matching_DB.dbo.wo_match_wines (
	batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)

select 
	@batch_id, '', z.incoming_wine_name, 'N'
	, 0, getdate(), 1, 1, ''

from
(select distinct [WineNameEdited] as incoming_wine_name from matching_db.dbo.[Vinous_reviews_2018_Q4]) z
print @batch_id

exec wo_match_run 'clean', @batch_id, 'nosuspect' --@batch_id instead of numberexec wo_match_run 'Match', @batch_id, 'noround4'  --|regional

--select batch_id, count(1) from wo_match_wines where batch_id >= 541 group by batch_id 

-----------------------------------------
print 'Print Final vinous Table'

update v
	set v.wo_wine_ID = wmw.wo_wine_ID
	from matching_db.dbo.[Vinous_reviews_2018_Q4] v
	join matching_DB.dbo.wo_match_wines wmw
	on v.WineNameEdited = wmw.incoming_wine_name COLLATE SQL_Latin1_General_CP1_CI_AS
	and wmw.batch_id = @batch_id and round_matched in (1,5)

	GO

-----------------------------------------

update matching_db.dbo.[Vinous_reviews_2018_Q4] set provenance = 'wine_id is null because wine did not match' where wo_wine_ID is null

-----------------------------------------

print 'Creating and inserting data to new table'

--drop table if exists vinous_tasting_review_1

create table #vinous_tasting_review_1 (
	tasting_Id int not null
	, review_type_ref varchar(500) not null
	, wine_id int null
	, vintage int not null
	, owner_Id int not null
	, critic_wine_desc varchar(500)
	, review_date date null
	, publication_issue varchar(500)
	, condition varchar(500)
	, packaging varchar(500)
	, provenance varchar(500)
	, condition_notes varchar(500)
	, paraphrase_extract varchar(8000)
	, tasting_note varchar(8000)
	, personal_note varchar(8000)
	, score_type varchar(50)
	, score int null
	, score_display varchar(50)
	, wo_score int null
	, critic_id int null
	, critic_name varchar(255)
	, expert_name varchar(255)
	, recommended_drinking_start_date int
	, optimum_drinking_date int
	, recommended_drinking_end_date int
	, published varchar(1)
	, disabled bit null
	, created datetime
	, created_by int
	, updated datetime
	, updated_by int
	, stamp int
	, main_link varchar(200)
	, review_link varchar(200)
	, serving_portion varchar(10)
	, event_note varchar(100)
	, user_score int
);

declare @last_date date
select @last_date = CAST(parameter_value as date) from parameter where name = 'LAST_VINOUS_UPDATE'

insert into #vinous_tasting_review_1
select 
	ROW_NUMBER()OVER(ORDER BY [wo_wine_Id])
	, 'V'
	, wo_wine_ID
	, try_cast(Vintage as int)
	, 0
	, wineNameEdited
	, [created at]
	, Issue
	, [Country]
	, NULL
	, provenance
	, [Region 2]
	, LEFT([Tasting note],7999)
	, NULL
	, NULL
	, score_type1
	, score_to_int1
	, score_display1
	, null
	, null
	, null
	, [Author name]
	, [Drinking window begin]
	, null
	, [Drinking window end]
	, 'Y'
	, 0
	, null
	, 0
	, null
	, 0
	, 0
	, 'https://www.vinous.com/'
	, 0
	, null
	, null
	, null

from matching_db.dbo.[Vinous_reviews_2018_Q4]
--where [Vinous Id] is not null
where [created at] >= @last_date

---------------------------------------
--drop table if exists store_duplicates

select * into #store_duplicates from 
(select v.* from tasting_note_or_review t
join #vinous_tasting_review_1 v on 
	t.critic_wine_desc = v.critic_wine_desc COLLATE SQL_Latin1_General_CP1_CI_AS
and t.score = v.score
and t.vintage = v.vintage
and isnull(t.recommended_drinking_start_date,0) = isnull(v.recommended_drinking_start_date,0)
and isnull(t.recommended_drinking_end_date,0) = isnull(v.recommended_drinking_end_date,0)
and t.expert_name = v.expert_name COLLATE SQL_Latin1_General_CP1_CI_AS
--where v.tasting_id is not null
) as finding_duplicates

print 'Duplicates Found'

--drop table if exists final_temp

select * into #final_temp from 
(select v.* from #vinous_tasting_review_1 v where not exists (select * from #store_duplicates t where t.tasting_id = v.tasting_id)) as everything_except_duplicates

print 'All data saved EXCLUDING duplicates'

---------------

declare @t_Id int 
Select @t_Id = max(tasting_id) from tasting_note_or_review

insert into tasting_note_or_review (
tasting_id 
, review_type_ref
, wine_id
, vintage
, owner_id
, critic_wine_desc
, review_date
, publication_issue
, condition
, packaging
, provenance
, condition_notes
, paraphrase_extract
, tasting_note
, personal_note
, score_type
, score
, score_display
, wo_score
, critic_id
, critic_name
, expert_name
, recommended_drinking_start_date
, optimum_drinking_date
, recommended_drinking_end_date
, published
, disabled
, created
, created_by
, updated
, updated_by
, stamp
, main_link
, review_link
, serving_portion
, event_note
, user_score
)
select 
	@t_Id+ROW_NUMBER() OVER(ORDER BY critic_wine_desc)
,	review_type_ref
,	wine_id
,	vintage
,	owner_id
,	critic_wine_desc
,	review_date
,	publication_issue
,	condition
,	packaging
,	provenance
,	condition_notes
,	paraphrase_extract
,	tasting_note
,	personal_note
,	score_type
,	score
,	score_display
,	wo_score
,	critic_id
,	critic_name
,	expert_name
,	recommended_drinking_start_date
,	optimum_drinking_date
,	recommended_drinking_end_date
,	published
,	disabled
,	getdate()
,	created_by
,	getdate()
,	updated_by
,	stamp
,	main_link
,	review_link
,	serving_portion
,	event_note
,	user_score

from #final_temp

---------------------------------------

Declare @max_date date
Select @max_date = MAX(review_date) from #final_temp

-- Updating parameter value for when the last update was made with vinous reviews
update parameter set parameter_value = @max_date, updated = getdate(), updated_by = 213
where name = 'LAST_VINOUS_UPDATE';

Declare @batch_id int
select @batch_id = CAST(parameter_value as int) from parameter where name = 'LAST_VINOUS_UPDATE_BATCH_ID'

-- Update packaging column - potential wine names
update tr
set tr.packaging = wmw.wo_wine_name -- potential wine name (no wine id)
--select tr.*
from tasting_note_or_review tr
join matching_db.dbo.wo_match_wines wmw on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS and wmw.batch_id = @batch_id
where 
	wmw.wo_wine_name is not null
	and tr.provenance like 'wine_id is null because wine did not match'
	and tr.wine_Id is null
	and tr.critic_name = 'vinous'

-- (view results of this script)
--select * from tasting_note_or_review where created > getdate()-1

/*

-- =============================================
-- Author:      Deepali
-- Create date: 2019-01-31
-- Description: Populate jancis review notes (data) into tasting review table
-- =============================================

Please follow instructions on: https://docs.google.com/document/d/1kBQdurssTNZoECe4gUooU98DIQgHm8g11D4W7zMo0GM/edit
Current table name: jancisrobinson (14)

*/
-- If needed..
--drop table [jancisrobinson_TN_20190618]


print 'Begin Script'

alter table matching_db.dbo.[jancisrobinson_TN_20190618] add recommended_drinking_start_date varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add recommended_drinking_end_date varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add critic_name varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add expert_name varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add score int;
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add score_type int;
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add score_display varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add critic_wine_desc varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add review_type_ref varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add main_link varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add review_link varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add published varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add review_date varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add created varchar(500) ;
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add updated varchar(500) ;
--alter table [jancisrobinson_TN_20190618] add created_by varchar(500);
--alter table [jancisrobinson_TN_20190618] add updated_by varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add disabled varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add stamp varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add optimum_drinking_date varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add wo_score varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add serving_portion varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add event_note varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add user_score varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add condition varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add packaging varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add provenance varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add condition_notes varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add tasting_note varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add personal_note varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add critic_id varchar(500);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add jr_wine_id varchar(500); 
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add test_vintage varchar(100);
alter table matching_db.dbo.[jancisrobinson_TN_20190618] add vintage_to_int int;


print 'Columns added into Jancis table'

GO

update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = drink_date_from_s;
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = 0 where recommended_drinking_start_date = '??';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = 0 where recommended_drinking_start_date = '--';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = 0 where recommended_drinking_start_date = 'Now';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = 0 where recommended_drinking_start_date = 'Drink up';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_start_date = 0 where recommended_drinking_start_date is null;

update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = drink_date_to_s;
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = 0 where recommended_drinking_end_date = '--';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = 0 where recommended_drinking_end_date = '??';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = 0 where recommended_drinking_end_date = 'Now';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = 0 where recommended_drinking_end_date = 'Drink up';
update matching_db.dbo.[jancisrobinson_TN_20190618] set recommended_drinking_end_date = 0 where recommended_drinking_end_date is null;

update matching_db.dbo.[jancisrobinson_TN_20190618] set test_vintage= vintage_s;
update matching_db.dbo.[jancisrobinson_TN_20190618] set test_vintage = '0' where test_vintage LIKE '%[^0-9]%';
update matching_db.dbo.[jancisrobinson_TN_20190618] set vintage_to_int = try_cast(test_vintage as int);

update matching_db.dbo.[jancisrobinson_TN_20190618] set critic_name = 'jancis' where critic_name is null;
update matching_db.dbo.[jancisrobinson_TN_20190618] set expert_name = author_s;
update matching_db.dbo.[jancisrobinson_TN_20190618] set score = (round(LEFT(SUBSTRING(score_s, PATINDEX('%[0-9.]%', score_s), 8000), PATINDEX('%[^0-9.]%', SUBSTRING(score_s, PATINDEX('%[0-9.]%', score_s), 8000) + 'X') -1) ,0));
update matching_db.dbo.[jancisrobinson_TN_20190618] set score_type =  20 where score <= 20;
update matching_db.dbo.[jancisrobinson_TN_20190618] set score_display =  (convert(varchar(10),score)  + '/' +convert(varchar(10),score_type));
update matching_db.dbo.[jancisrobinson_TN_20190618] set critic_wine_desc =  dbo.fnCleanEncoding(title_s);
update matching_db.dbo.[jancisrobinson_TN_20190618] set critic_wine_desc  = replace(critic_wine_desc, 'NV', '');
update matching_db.dbo.[jancisrobinson_TN_20190618] set review_type_ref = 'CR';
update matching_db.dbo.[jancisrobinson_TN_20190618] set review_date = LEFT([date_tasted_tdt], 10) ;
update matching_db.dbo.[jancisrobinson_TN_20190618] set main_link = 'https://www.jancisrobinson.com/';
update matching_db.dbo.[jancisrobinson_TN_20190618] set review_link = 'https://www.jancisrobinson.com/tastings/view/';
update matching_db.dbo.[jancisrobinson_TN_20190618] set published = 'Y';
--update matching_db.dbo.[jancisrobinson_TN_20190618] set created = try_cast(getdate() as date) where created is null;
--update matching_db.dbo.[jancisrobinson_TN_20190618] set updated = try_cast(getdate() as date);
update matching_db.dbo.[jancisrobinson_TN_20190618] set disabled = 0;
update matching_db.dbo.[jancisrobinson_TN_20190618] set stamp = 1;
update matching_db.dbo.[jancisrobinson_TN_20190618] set optimum_drinking_date = null;
update matching_db.dbo.[jancisrobinson_TN_20190618] set wo_score = 0;
update matching_db.dbo.[jancisrobinson_TN_20190618] set wo_score = 0;


--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','e')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','e')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','o')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','e')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','a')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','a')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','a')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','u')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','o')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','i')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','n')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','u')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','i')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','o')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','e')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','a')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','i')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','u')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�','c')
--update [jancisrobinson_TN_20190618]set critic_wine_desc = REPLACE(critic_wine_desc,'�',' ')


update matching_db.dbo.[jancisrobinson_TN_20190618]set critic_wine_desc = replace(critic_wine_desc, test_vintage, '')
update matching_db.dbo.[jancisrobinson_TN_20190618]set critic_wine_desc = replace(critic_wine_desc, '  ', ' ')
update matching_db.dbo.[jancisrobinson_TN_20190618]set critic_wine_desc = rtrim(critic_wine_desc)
update matching_db.dbo.[jancisrobinson_TN_20190618]set critic_wine_desc = ltrim(critic_wine_desc)


print 'Relevant fields updated into columns in Jancis table'

GO

----------------------------------------- select * from parameter where name = 'LAST_JANCIS_UPDATE_BATCH_ID';

print 'Begin Matching Process'
declare @batch_id int
select @batch_id = max(batch_id)+1 from Matching_DB.dbo.wo_match_wines

update parameter set parameter_value = @batch_id 
where name = 'LAST_JANCIS_UPDATE_BATCH_ID';

insert 
into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)

Select 
	@batch_id, '', z.incoming_wine_name, 'N'
	, 0, getdate(), 1, 1, ''

from 
(select distinct [critic_wine_desc] as incoming_wine_name from matching_db.dbo.[jancisrobinson_TN_20190618]) z
print @batch_id

exec wo_match_run 'clean', @batch_id, 'nosuspect' --@batch_id instead of numberexec wo_match_run 'Match', @batch_id, 'noround4'  --|regional

--select batch_id, count(1) from wo_match_wines where batch_id >= 541 group by batch_id 

-----------------------------------------
print 'Print Final Jancis Table'

update jr
	set jr.jr_wine_id = wmw.wo_wine_ID
--	select jr.* 
	from matching_db.dbo.[jancisrobinson_TN_20190618] jr
	join matching_DB.dbo.wo_match_wines wmw 
	on jr.critic_wine_desc = wmw.incoming_wine_name COLLATE SQL_Latin1_General_CP1_CI_AS
	and wmw.batch_id = @batch_id and round_matched in (1,5)
	--wmw.Batch_id = 575

	GO

-----------------------------------------

update matching_db.dbo.[jancisrobinson_TN_20190618] set provenance = 'wine_id is null because wine did not match' where jr_wine_id is null

-----------------------------------------

print 'Creating and inserting info to new table'

--drop table if exists #jancis_tasting_review_1;

create table #jancis_tasting_review_1 (
	tasting_Id int
	, review_type_ref varchar(500)
	, wine_id varchar(500)
	, vintage varchar(500)
	, owner_Id varchar(500)
	, critic_wine_desc varchar(500)
	, review_date varchar(500)
	, publication_issue varchar(500)
	, condition varchar(500)
	, packaging varchar(500)
	, provenance varchar(500)
	, condition_notes varchar(500)
	, paraphrase_extract varchar(max)
	, tasting_note varchar(500)
	, personal_note varchar(500)
	, score_type varchar(500)
	, score varchar(500)
	, score_display varchar(500)
	, wo_score varchar(500)
	, critic_id varchar(500)
	, critic_name varchar(500)
	, expert_name varchar(500)
	, recommended_drinking_start_date varchar(500)
	, optimum_drinking_date varchar(500)
	, recommended_drinking_end_date varchar(500)
	, published varchar(500)
	, disabled varchar(500)
	, created varchar(500)
	, created_by varchar(500)
	, updated varchar(500)
	, updated_by varchar(500)
	, stamp varchar(500)
	, main_link varchar(500)
	, review_link varchar(500)
	, serving_portion varchar(500)
	, event_note varchar(500)
	, user_score varchar(500)
	);

	declare @max_date date
	select @max_date = max(review_date) from matching_db.dbo.[jancisrobinson_TN_20190618]

	declare @date_last date
	select @date_last = cast(parameter_value as date) from parameter where name = 'LAST_JANCIS_UPDATE'

	insert into #jancis_tasting_review_1
	select
		ROW_NUMBER()OVER(ORDER BY jr_wine_id)
		, review_type_ref
		, jr_wine_id
		, vintage_to_int
		, 0
		, ltrim(rtrim(critic_wine_desc))
		, review_date
		, NULL
		, NULL
		, NULL
		, provenance
		, NULL
		, ltrim(rtrim(content_t))
		, NULL
		, NULL
		, score_type
		, score
		, score_display
		, NULL
		, null
		, critic_name
		, expert_name
		, recommended_drinking_start_date
		, null
		, recommended_drinking_end_date
		, 'Y'
		, 0
		, created
		, 0
		, updated
		, 0
		, stamp
		, main_link
		, review_link
		, null
		, null
		, null

from matching_db.dbo.[jancisrobinson_TN_20190618]
--where jr_wine_id is not null
where @date_last <= review_date 

---------------------------------------

--drop table if exists #store_duplicates;

select * into #store_duplicates from (
	select j.* from tasting_note_or_review t
	join #jancis_tasting_review_1 j on 
		t.critic_wine_desc = j.critic_wine_desc COLLATE SQL_Latin1_General_CP1_CI_AS
	and t.score = j.score
	and t.vintage = j.vintage
	and isnull(t.recommended_drinking_start_date,0) = isnull(j.recommended_drinking_start_date,0)
	and isnull(t.recommended_drinking_end_date,0) = isnull(j.recommended_drinking_end_date,0)
	and t.review_date = j.review_date
	--where j.wine_id is not null
) as finding_duplicates

print 'Duplicates Found'

--drop table if exists #final_temp;

select * into #final_temp from 
(select j.* from #jancis_tasting_review_1 j where not exists (select * from #store_duplicates t where t.tasting_id = j.tasting_id)) as everything_except_duplicates

print 'All data saved EXCLUDING duplicates'

---------------------------------------

declare @t_Id int 
Select @t_Id = max(tasting_id) from tasting_note_or_review

insert into tasting_note_or_review (
tasting_id 
, review_type_ref
, wine_id
, vintage
, owner_id
, critic_wine_desc
, review_date
, publication_issue
, condition
, packaging
, provenance
, condition_notes
, paraphrase_extract
, tasting_note
, personal_note
, score_type
, score
, score_display
, wo_score
, critic_id
, critic_name
, expert_name
, recommended_drinking_start_date
, optimum_drinking_date
, recommended_drinking_end_date
, published
, disabled
, created
, created_by
, updated
, updated_by
, stamp
, main_link
, review_link
, serving_portion
, event_note
, user_score
)

select 
	@t_Id+ROW_NUMBER() OVER(ORDER BY critic_wine_desc)
,	review_type_ref
,	wine_id
,	vintage
,	owner_id
,	critic_wine_desc
,	review_date
,	publication_issue
,	condition
,	packaging
,	provenance
,	condition_notes
,	paraphrase_extract
,	tasting_note
,	personal_note
,	score_type
,	score
,	score_display
,	wo_score
,	critic_id
,	critic_name
,	expert_name
,	recommended_drinking_start_date
,	optimum_drinking_date
,	recommended_drinking_end_date
,	published
,	disabled
,	getdate()
,	created_by
,	getdate() 
,	updated_by
,	stamp
,	main_link
,	review_link
,	serving_portion
,	event_note
,	user_score

from #final_temp

---------------------------------------
	-- Updating parameter value for when the last update was made with jancis reviews
	update parameter set parameter_value = @max_date 
	where name = 'LAST_JANCIS_UPDATE';

	-- Update packaging column - potential wine names
	update tr
	set tr.packaging = wmw.wo_wine_name
	from tasting_note_or_review tr
	join matching_db.dbo.wo_match_wines wmw on wmw.incoming_wine_name = tr.critic_wine_desc collate Latin1_General_CI_AS
	where 
		wmw.wo_wine_name is not null
		and tr.provenance like 'wine_id is null because wine did not match'
		and wmw.batch_id = (select parameter_value from parameter
		where name = 'LAST_JANCIS_UPDATE_BATCH_ID')

-- (view results of this script)
-- select * from tasting_note_or_review where created > getdate()-1
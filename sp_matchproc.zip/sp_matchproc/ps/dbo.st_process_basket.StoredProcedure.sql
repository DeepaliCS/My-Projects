IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[st_process_basket]')  AND type = N'P')
     DROP PROCEDURE [dbo].[st_process_basket]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[st_process_basket] 

	@user_id	Int,
	@settings varchar(1000) ='', 
	@sql_logging varchar(1) = 'X',
	@output_message varchar(1000) ='' OUTPUT,

	@basket_type varchar(20),
	@status varchar(10), -- B, X , A or C (see below for explanation)
	@submit_notes varchar(4000)='',
	-- following 3 required for @basket_type=CALLOFF and @status='A' 
	-- where either @address_id is required OR @house_no/@postcode is required
	@address_id int=null,   
	@house_no varchar(50) =null,
	@postcode varchar(20) =null,
	@reference varchar(20) =null,

	@request_date datetime =null,
	@consignee_name varchar(50) = null,
	@carrier_name varchar(50) = null,
	@basket_option varchar(50) = null,

	@code varchar(40) = null,
	@incoming_basket_id int = null,
	@options varchar(50) = null,
	@basket_id int = null OUTPUT,

	@basket_delivery_type varchar(10) = null
	
AS

BEGIN
    -- JS 2013-05-13 enure error checking works (after raiserror statements removed)
    -- JS 2013-04-29 Updated to use new table Basket, Status definitions redefined
	
	-- =============================================
	-- Author:		J Slatter
	-- Create date: 2013-Apr-22
	-- Description:	Process the users current basket 
	-- =============================================

	/**   description:

	Status = B (its in the currentBasket)
			 X (eXcluded/ignore - deleted from basket)	         
             A (Awaiting proceessing  - so we are waiting to the account on hold flag)
             C (Completed
			 S Shipped   (used for WEC)

	We will allow re-open from status A and C   but NOT S for shipped


	-- reopen basket
	declare @output_message varchar(1000)
	exec st_process_basket 
		@user_id=171,
		@settings='192.145.12.233~session1234~WO~Europe~GBP~en',
		@sql_logging='X',
		@output_message=@output_message output, 
		@status='B',
		@basket_type='CALLOFF',
		@incoming_basket_id= 167
	print @output_message
	

	
	-- TEST 1. remove from basket
	declare @output_message varchar(1000)
	
	exec st_process_basket 
		@user_id=171,
		@settings='192.145.12.233~session1234~WO~Europe~GBP~en',
		@sql_logging='X',
		@output_message=@output_message output, 
		@status='X',
		@basket_type='CALLOFF',
		@address_id=null,
		@submit_notes='bla bla bla'
	print @output_message
	
	-- list removed items from statement above
	exec dm_basket_list 
		@user_id=171,
		@settings='192.145.12.233~session1234~WO~Europe~GBP~en',
		@sql_logging='X',
		@output_message='', 
		@basket_type='CALLOFF',
		@status='X'
	
	-- TEST 2. process basket such that are now Awaiting processed
	declare @output_message varchar(1000)
	exec st_process_basket 
		@user_id=171,
		@settings='192.145.12.233~session1234~WO~Europe~GBP~en',
		@sql_logging='X',
		@output_message=@output_message output, 
		@status='A',
		@basket_type='CALLOFF',
		@address_id=14, --this is any old address_id
		@submit_notes=''
	
	print @output_message	
	
	-- list items from statement above
	exec dm_basket_list 
		@user_id=171,
		@settings='192.145.12.233~session1234~WO~Europe~GBP~en',
		@sql_logging='X',
		@output_message='', 
		@basket_type='CALLOFF',
		@status='A'
	**/



BEGIN TRY

	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
    SET XACT_ABORT ON 

	-- get basket type
    SET @basket_type = UPPER(@basket_type)
	-- incoming_status
	declare @incoming_status varchar(20) = @status

	-- get brand
	declare @brand varchar(20) = dbo.fnGetPiece(@settings,3,'~','WO')

	set @output_message = ''
	
	-- set actions
	declare @action as varchar(20) = 'insert'
	-- If status passed use this
	if @incoming_status='A'
		select @action = 'awaiting'
	else if @incoming_status='X'
		select @action = 'removing'
	else if @incoming_status='B'
		select @action = 'reopen'
	else
		set @output_message='status should be A, B X';

		
	-- string of input fields
	declare @input_fields as varchar(1000) = ''
	-- input field for logging purpose
	select @input_fields = 'Input fields - Settings: '+isnull(@settings,'')+
	'  Action: '+isnull(@action,'')+
	'  Basket type: '+isnull(@basket_type,'')+
	'  Status : '+isnull(@incoming_status,'')+
	'  notes: '+isnull(left(@submit_notes,500),'')+
	'  basket id: ' + isnull(cast(@incoming_basket_id as varchar(10)),'')+
	'  code: ' + isnull(@code,'')

	
	-- Wine owner owner_id
	-- Transaction name, object and exception are all used by audit trail exec
	declare @transaction_name as varchar(50) = @action+'_process_basket'
	declare @object_name as varchar(50) = 'st_process_basket'
	declare @audit_exception varchar(500) = ''

	-- 1 - log start in account audit trail
	-- This is deliberately outside the SQL transaction so if there is an error we can check and run it again. 
	-- Note that the audit trail uses its own date time so we can see how long it took to create the transaction
	exec st_audit @user_id, @settings, @object_name, @transaction_name, 'start', @Input_fields
	
	-- should be 0 or 1 basket records per user having a status of 'B'
	declare @basket_count int =null
	
	-- pick up user org
	declare @user_org_id int
	declare @user_alias varchar(50)
	declare @admin_user varchar(10)
	declare @user_brand varchar(10) = ''
	select @user_org_id = u.organisation_id, @user_alias = u.alias, @admin_user = admin_user, @user_brand=o.brand_ref
	from [user] u with (nolock)
		join organisation o with (nolock) on o.organisation_id = u.organisation_id
	where user_id = @user_id

	-- 
	declare @beginning_bottle_count int = dbo.fnCountBottlesBelowFifty(@user_id, null, null,null)

	-- basket brand
	declare @basket_brand varchar(10) = ''

	-- wv 2019-05-14 if we HAVE a basket id change to pickup from there  
	if isnull(@incoming_basket_id,0) > 0
		begin
			-- get basket details
			select top 1 @user_org_id=u.organisation_id, @basket_brand = o.brand_ref
				from basket b with (nolock)
					join [user] u with (nolock) on u.user_id = b.user_id
					join organisation o with (nolock) on o.organisation_id = u.organisation_id
			where basket_id = @incoming_basket_id
		end

	-- get basket
	select @basket_count=COUNT(*) 
		from basket b with (nolock)
			join [user] u with (nolock) on u.user_id = b.user_id
	where basket_type=@basket_type and [status]='B' and u.organisation_id = @user_org_id 

	-- check 
	if @basket_count>1 
		begin
			-- set alert message
			declare @alert_message varchar(500) = dbo.fnGetContentDescriptionDefault(@user_id, @settings, 'BASKET_LIST_MAX_BASKETS_ALERT'
				, 'Warning: you have more than one active order (basket) - please contact support.' )
			exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @alert_message	
			-- wv 2017-03-20 must exit  !!
			return
		end
	

	-- get the user basket_id
	--declare @basket_id int
	declare @basket_status varchar(10)
	--order by most recent
	if isnull(@incoming_basket_id,0) > 0
		begin
			select top 1 @basket_id=basket_id, @basket_status = [status]
				from basket b with (nolock)
					join [user] u with (nolock) on u.user_id = b.user_id
			where basket_id = @incoming_basket_id
		end
	else
		begin
			-- if not > 0 pick up active basket
			select top 1 @basket_id=basket_id, @basket_status = [status]
				from basket b with (nolock)
					join [user] u with (nolock) on u.user_id = b.user_id
			where basket_type=@basket_type and [status]='B'
				and u.organisation_id = @user_org_id 
				-- get most recent basket  (but should ONLY be one)
			order by b.created desc
		end


	-- wv 2019-05-14  if we have a basket brand check it is correct
	if @output_message='' and isnull(@basket_brand,'') <> '' and isnull(@basket_brand,'') <> isnull(@user_brand,'')
		select @output_message = 'This basket is not for your brand, basket id: ' + isnull(cast(@incoming_basket_id as varchar(10)),'')

	-- wv 2019-05-14  if not insert must have valid basket
	if @output_message='' and @action = 'reopen' and isnull(@incoming_basket_id,0) <= 0 
		select @output_message = 'For action ' + isnull(@action,'') + ' you must pass in a valid basket id.'

	-- wv 2019-05-14  if not insert must have valid basket status
	if @output_message='' and @action <> 'insert' and isnull(@basket_status,'') = '' 
		select @output_message = 'For action ' + isnull(@action,'') + ' you must have a valid basket status, basket id is: ' + isnull(cast(@basket_id as varchar(10)),'')


	-- check test mode
	declare @test_mode varchar(200) = dbo.fnGetParameter(@user_id,@settings,'ORDER_TEST_ALLOWED_ORG_ID','')
	-- if NOT empty THIS user's org id must be present in the list
	if @output_message='' and isnull(@test_mode,'') <> ''
		begin
			-- if id does not exist
			if ','+replace(@test_mode,' ',',')+',' not like '%,' + cast(@user_org_id as varchar(20)) + ',%'
				select @output_message = 'The Order system is in test mode and ONLY allows a few accounts to place orders. Parameter ''ORDER_TEST_ALLOWED_ORG_ID'' must contain your organisation id (' + cast(@user_org_id as varchar(20)) + ') in order to process a basket. Please contact Wolter'
		end 

	-- for reopen check you are allowed to reopen
	if @output_message='' and @action = 'reopen'
		begin
			-- check if this user is allowed re-open
			if isnull(@user_alias,'') = '' or ((','+dbo.fnGetParameter(@user_id, @settings, 'USERS_ALLOWED_REOPEN_BASKET','')+',') not like ('%,'+@user_alias+',%'))
				select @output_message =  'You are not allowed to re-open baskets - please contact support (USERS_ALLOWED_REOPEN_BASKET).'
		end

	-- wv 2019-05-14  for reopen check there is NO open basket already
	if @output_message='' and @action = 'reopen' and isnull(@basket_count,0) > 0
		select @output_message = 'You cannot re-open a basket if there is already an open basket. Please completed the open basket first'


	-- special check for WEC for merchant order
	if @output_message='' and isnull(@code,'') <> '' and @brand='WEC' and isnull(@basket_id,0) > 0
		begin
			-- at this stage basket MUST exist otherwise we would not add a code
			-- get prefix and check prefix + code is not longer than 10
			declare @prefix varchar(20) 
			declare @max_len int = 13
			select top 1 @prefix = isnull(udf.value_2, '') 
				from basket b with (nolock)
					-- join on user of this basket
					join [user] u with (nolock) on u.user_id = b.user_id
					join [organisation] o with (nolock) on o.organisation_id = u.organisation_id
					left join user_defined_field udf with (nolock) on o.[organisation_id] = udf.record_id and udf.table_name = 'organisation' and udf.brand_ref = 'WEC'
			where b.basket_id = @basket_id
			-- always add prefix
			-- if the prefix is already in front than ok (because max length is set to 10)
			select @code = case when @code not like isnull(@prefix,'') +'%' then @prefix else '' end + isnull(@code,'')
			-- else check total length is no more than 10
			if len(@code) > @max_len
				select @output_message = 'Total length of shipper number including prefix cannot be longer than ' + cast(@max_len as varchar(10)) + ' characters'
		end



	-- check status
	-- this is checking the input status.  So basket status is B but can go to X (clear),  A await  or C process),  b reopen
	if @output_message='' and @incoming_status not in ('X','A','C','B') 
		set @output_message = 'Unknown basket status (' + isnull(@basket_status,'') + '). Status can only be set to X-cancelled, A-awaiting, C-completed, or B-reopen'
		

    -- validate
    if @output_message='' and @action <> 'removing'  and dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_ADDRESS', 'Y') = 'Y'
		begin 
			-- if its a CALLOFF then address information is required
			if @basket_type='CALLOFF' 
				begin 
					-- check we have address
					if @incoming_status='A' and (@address_id is null and (@postcode is null or @house_no is null)) and  ','+dbo.fnGetParameter(20361,'~~SBW~','M_BASKET_LIST_DELIVERY_TYPES_CHECK_ADDRESS','')+',' like '%,' + @basket_delivery_type +',%' 
						set @output_message = 'Either address_id or (postcode + house no) must be specified for Call offs with status A'

					-- if ok check if this is address check
					if @output_message='' and dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_ADDRESS_SHIP_TO', 'N') = 'Y'
						begin
							-- get address details
							if isnull((select contact_name from [address] where address_id= @address_id),'')=''
								select @output_message = 'The selected address does not have a Ship to name, please re-enter the address correctly.' 
						end
						

					-- and			    
					if @output_message='' and @incoming_status='X' and @address_id is not null
						set @output_message = 'address_id should be NULL for @basket_type=CALLOFF and @status=X'
				end

			else if @basket_type not in ('INSPECTION_REQUEST', 'BROKER_REQUEST', 'ENQUIRY')
				select @output_message = 'unknown basket_type - ' +isnull(@basket_type,'??')
		end


    -- 2019-05-15 Added date validation 
    if @output_message='' and @incoming_status='A' and @basket_type='CALLOFF' and dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_DELIVERY_DATE', '') <> ''
		begin 
			-- date MUST be after tomorrow (2 days)
			if datediff(DD,cast(getdate() as date),cast(@request_date as date)) < 2
				select @output_message = 'Delivery date must be after tomorrow' 
			else
				begin
					-- get valid days
					declare @valid_days varchar(100) = dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_DELIVERY_DATE', '')
					-- and on valid days only
					if ','+dbo.fnGetPiece(@valid_days,1,'~','')+',' not like '%,'+cast(datepart(dw,cast(@request_date as date)) as varchar(10))+',%'
						select @output_message = 'Delivery date can only by a: ' + isnull(dbo.fnGetPiece(@valid_days,2,'~',''), '') 
				end
		end


    -- validate when we close basket
    if @output_message='' and @incoming_status='A' and isnull(@address_id,0) > 0
		and @action <> 'removing'  and dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_ADDRESS_SHIP_TO', 'N') = 'Y'
		begin 
			-- if its a CALLOFF then address information is required
			if @basket_type='CALLOFF' 
				begin 
					-- check if this is address has got a contact name
					if @output_message='' and dbo.fnGetParameter(@user_id, @settings, 'M_BASKET_CHECK_ADDRESS_SHIP_TO', 'N') = 'Y'
						begin
							-- get address details
							if isnull((select contact_name from [address] where address_id= @address_id),'')=''
								select @output_message = 'The selected address does not have a Ship to name, please re-enter the address correctly.' 
						end
				end
		end


	-- wv 2017-04-10 check date is today or later
	-- in case date is null check it is after 1980
    if @output_message='' and @incoming_status='A' and cast(@request_date as date) < cast(getdate() as date)
		and  cast(@request_date as date) > cast('1980-jan-01' as date)
		begin 
			select @output_message = 'The requested date cannot be before today.' 
		end

		
	-- wv 2017-02-26  check re-open basket
	if @output_message = '' and @action = 'reopen'
		begin
			-- status must be A or C
			if @basket_status not in ('A','C','H')
				set @output_message = 'You can only re-open a basket which is not yet shipped'
		end 
	

	
	-- mb - 2016-10-24 - disable all basket items that are not active or available 
	-- mb - 2017-02-28 - do not check if we are reopening a basket
	-- and these get deleted later on
	if @output_message = '' and @action <> 'removing' and @action <> 'reopen'
		begin 

			-- update basket items to disabled if the wine entry is not enabled or active
			update bi
				set bi.[disabled] = 1
			from basket_item bi
				left join wine_entry we with (nolock) on bi.wine_entry_id = we.wine_entry_id
			where basket_id = @basket_id
				and isnull(bi.[disabled],0) = 0
				and (isnull(we.[disabled],0) = 1 or we.[status] <> 'active')
				and bi.[status] <> 'X'

			-- check if items left
			if (select count(1) from basket_item bi	where basket_id = @basket_id and isnull(bi.[disabled],0) = 0 and bi.[status] <> 'X') = 0
				select @output_message = 'No active items left in this basket. Please add active wines'

		end


	-- JS 2013-05-13 if any errors
	if @output_message <> ''
		begin
			select @audit_exception = 'Input validation failed - processing basket aborted: '+@output_message + ' ' + @input_fields
			-- insert into audit trail
			exec st_audit @user_id, @settings, @object_name, @transaction_name, 'validation-error', @audit_exception
			-- and exit
			RETURN
		end
	
	-- no errors,  so now process the basket  (insert for new, or amend if existing id)
	-- this is now using identities (because of deadlock risk doing anything else)

	-- start transaction for all main table updates
	BEGIN TRAN @transaction_name

		-- wv 2015-10-20 remove delete basket items (no longer needed)
		delete from basket_item
			where basket_id=@basket_id and ([status] ='X' or [disabled] = 1)

		declare @audit_record_id_current int
		declare @audit_record_id_new int
		-- wv 2017-02-27 save basket in audit trail
		insert into audit_basket
		select * from basket where basket_id=@basket_id
		-- and set audit_record Id
		select @audit_record_id_current = @@IDENTITY

		-- updated
		declare @updated datetime = getdate()
		declare @error varchar(1000) = ''

		-- when closing/submitted the basket
		if @incoming_status='A' 
			begin

				-- special for NOAPICALL
				declare @m_order_code varchar(50) = @code
				-- for special processing of NOAPICALL 
				if @code like '%NOAPICALL' 
					begin
						-- if we have carrier name use this as order number 
						if isnull(@carrier_name,'') <> ''
							select @m_order_code = left(@carrier_name,15)
							select @m_order_code = case when @m_order_code not like isnull(@prefix,'') +'%' then @prefix else '' end + isnull(@m_order_code,'')
							-- just set to Western
							select @carrier_name = 'Western'
						-- always record in audit trail
						select @audit_exception = 'Special order submit with NOAPICALL for: ' + isnull(@m_order_code,'')
						exec st_audit_hdr  @user_id, @settings, @transaction_name, @object_name, 'info', null, null, null, @exception = @audit_exception
					end

				--declare @order_ref varchar (20) = dbo.fnGetNextOrderRef(@user_id,'','')
				--jf 2019-05-25 added extra check to get next order ref number only if there is not one already
				if dbo.fnGetParameter(@user_id, @settings, 'AUTO_GENERATE_ORDER_REFERENCE', 'N') = 'Y' and @basket_type not like '%INSPECTION_REQUEST%'
					begin
						if (select isnull(reference,'') from basket where basket_id=@basket_id) <> '' select @reference = (select reference from basket where basket_id=@basket_id)
						else select @reference=dbo.fnGetNextOrderRef(@user_id,@settings,'')
					end


				-- and update basket with all fields
				update basket 
				   set [status]=@incoming_status,
					   submit_notes=@submit_notes, 
					   address_id=@address_id,
					   house_no = @house_no,
					   postcode = @postcode,
					   reference = @reference,
					   request_date = @request_date,
					   updated=@updated,
					   updated_by = @user_id,
					   -- new fields
					   basket_option = @basket_option,
					   consignee_name = @consignee_name,
					   carrier_name = @carrier_name,
					   merchant_order_code = @m_order_code,
					   basket_delivery_type = @basket_delivery_type
				   where basket_id=@basket_id


				--jf 2019-05-24  update parameter
				--jf 2019-05-25 update only if the order reference is greater than parameter value
					if dbo.fnGetParameter(@user_id, @settings, 'AUTO_GENERATE_ORDER_REFERENCE', 'N') = 'Y' and (select parameter_value from parameter where name='LATEST_ORDER_REF' and brand_ref = @brand) < @reference
						update parameter set parameter_value=@reference, updated = @updated, updated_by = @user_id
						where name='LATEST_ORDER_REF' and brand_ref = @brand
				


				-- and the items
				update basket_item
					set [status]=@incoming_status, 
						--status_date=GETDATE(),
						updated=@updated,
						updated_by = @user_id
				where basket_id=@basket_id
				-- wv 2015-10-20 ONLY update basket items that are NOT deleted (although those should have been deleted anyway)
					AND [status] <> 'X'


				-- JS 2013-05-13 Raise the appropriate event.
				-- Event_user_id should be the default user of organisation that owns the wine,
				-- but for now, assume its the user id - will need to revisit this later when
				-- we have mulitple uers per organisation
				-- event type matches the basket type so it is:
				--   CALLOFF,  BROKER_REQUEST,   INSPECTION_REQUEST
				if isnull(@options,'') not like '%NOEVENT%'
					EXEC st_event @user_id, @settings, @sql_logging, @output_message, @basket_type
								,@user_id, 'N', null, null, null, null, null
								,'basket_id', @basket_id, 'basket', 'dm_basket_list'
								-- added  order api  so we have the same data as we may transmit
								,'order_id', @basket_id, 'order', 'dm_m_order_api'
								-- wv 2017-11-17  added new version for basket (kept both for compatibility)
								,'basket_id', @basket_id, 'basket_v2', 'dm_basket_list_v2'
				
				-- mb - 2017-06-12 - send email to client if parameter is set and this is not an admin user
				-- done for WEC because main email goes to admin users. This ensures that a client receives a confirmation when he places an order
				if dbo.fnGetParameter(@user_id, @settings, 'M_PROCESS_BASKET_CLIENT_EMAIL', 'N') = 'Y' 
					and isnull(@admin_user,'') = ''
					-- WV 2019-03-05 ONLY for calloff
					and @basket_type='CALLOFF' 
						begin
							-- raise event to client
							exec st_event @user_id, @settings, @sql_logging, @output_message, 'CALLOFF_CLIENT_EMAIL'
								,@user_id, 'N', null, null, null, null, null
								,'basket_id', @basket_id, 'basket', 'dm_basket_list'
								,'order_id', @basket_id, 'order', 'dm_m_order_api'
								-- wv 2017-11-17  added new version for basket (kept both for compatibility)
								,'basket_id', @basket_id, 'basket_v2', 'dm_basket_list_v2'
						end
				
				-- event for processing WEC  account on hold
				if dbo.fnGetParameter(@user_id, @settings, 'M_PROCESS_BASKET_API_CALL', 'N') = 'Y'
					-- WV 2019-03-05 ONLY for calloff
					and @basket_type='CALLOFF' 
						begin
							-- if options NOAPICALL then skip
							if isnull(@options,'') not like '%NOAPICALL%' and @code not like '%NOAPICALL'
								exec st_event @user_id, @settings, @sql_logging, @output_message, 'ACCOUNT_ON_HOLD', @user_id, 'N', null, null, null, null, null, 'order_id', @basket_id, 'order', 'dm_m_order_api' 

							-- this call set status to H  BUT only if on hold, otherwise it leaves it at A

							-- so when using call st_process_basket manually 
							-- then set status manually to A  pending    (B=Open, H -process (account n hold)
							-- set order number to the correct number
							-- then we re-run the check shipped orders which should pick it up properly 
						end

				-- update wine entry lines (move to shipped) so they cannot be ordered again
				if dbo.fnGetParameter(@user_id, @settings, 'M_PROCESS_BASKET_UPDATE_WINE_QTY', 'N') = 'Y'
					-- WV 2019-03-05 ONLY for calloff
					and @basket_type='CALLOFF' 
					begin
						-- audit trail
						select @audit_exception = 'start of deducting wine entry quantities. '
						exec st_audit_hdr  @user_id, @settings, 'wine-quantity', @object_name, 'start', null, null, null, @exception = @audit_exception

						-- process
						declare @out_msg varchar(500) = ''
						declare @output_type varchar(50) = ''
						declare @shipped_cellar_id int
						-- get shipped caller id (this process will create a shipped cellar if its not there already)
						EXEC st_create_cellar @user_id,@settings, 'X', @out_msg OUTPUT
							,'S','N',@shipped_cellar_id OUTPUT, @options = 'NOALERTMESSAGE'
						-- if we have an error or no cellar id
						if isnull(@out_msg,'') <> '' or isnull(@shipped_cellar_id,0) = 0
							RAISERROR ('ERROR: Failed to create Shipped cellar id', 16, 1)

						-- now loop over all basket lines and transfer each one
						declare @basket_item_id int
						declare @wine_entry_id int
						declare @quantity int
						declare @from_cellar_id int
						declare @from_mixed_case_id int
						-- loop over all basket items
						-- retrieve basket item id, wine entry id  and the total qty in bottles.
						Declare reccursor cursor for 
								select basket_item_id, bi.wine_entry_id, cast(we.case_size_ref as int) * isnull(quantity_cases,0) + isnull(quantity_bottles,0)
									,we.cellar_id, we.mixed_case_id
								from basket_item bi
							join wine_entry we with (nolock) on we.wine_entry_id = bi.wine_entry_id
								where basket_id = @basket_id
   
						open reccursor
						Fetch next from reccursor into @basket_item_id, @wine_entry_id, @quantity, @from_cellar_id, @from_mixed_case_id
						-- loop over entries
						While (@@Fetch_Status = 0 )
							Begin
							
							-- new wine entry 
							declare @new_wine_entry_id int = @wine_entry_id
							-- set order number as additional note text
							declare @add_notes varchar(200) = 'Order: ' + isnull(@code,'')

							-- transfer each wine to the shipped cellar BUT WITH status Pending  
							EXEC st_update_wine_entry_transfer  @user_id, @settings, 'X', @out_msg OUTPUT, 
								-- type, id, stamp and options   (options is disposed type ~ price~ note)
								@output_type OUTPUT, @new_wine_entry_id OUTPUT,	0, 'OVERWRITESELFMANAGED~NOALERTMESSAGE~NOTRANSACTION'
								-- quantity to be moved
								,@quantity = @quantity
								,@transfer_date = @updated
								,@cellar_id = @shipped_cellar_id
								,@status_overwrite ='PendingOrder'
								,@additional_notes = @add_notes
								,@disposal_date=@updated
								,@disposal_notes = @code
								-- ,@mixed_case_id int = null  -- not required   although need to check what to do when we move it back
								-- ,@cellar_ref varchar(100) = null  -- not required
								-- also need to check merchant product code is moved across
							
							-- If we have an error
							if isnull(@out_msg,'') <> ''
								begin
									select @error = 'ERROR: Failed to transfer wine record: ' + @out_msg
									RAISERROR (@out_msg, 16, 1)
								end

							-- if here ok so update basket item. (so when we re-open basket we can set these back)
							-- also include previous cellar id and mixed case id
							update basket_item
								set wine_entry_id = @new_wine_entry_id,updated = @updated
								,from_mixed_case_id = @from_mixed_case_id, from_cellar_id = @from_cellar_id
							where basket_item_id = @basket_item_id

							-- and get next one
							Fetch next from reccursor into @basket_item_id, @wine_entry_id, @quantity, @from_cellar_id, @from_mixed_case_id
	
						End  --end looping through records "

						CLOSE reccursor
						Deallocate reccursor
					end

					if dbo.fnCountBottlesBelowFifty(@user_id, null, null,null) < 50 and @beginning_bottle_count >= 50
					begin
						EXEC st_event
						  @user_id
						, @settings
						, @sql_logging
						, @output_message OUTPUT
							, 'BOTTLES_OVER_FIFTY'
							, @user_id
							, 'N'
							, null
							, null
							, null
							, null
							, null
							, 'user_id2'
							, @user_id
							,'email_bottles_below_fifty'
							,'dm_email_bottles_below_fifty'
						end
	
				end
		
		-- if basket is re-open
		-- and we are updating the wine entry quantities
		else if @incoming_status = 'B'
			begin

				-- and update basket, just set status back
				update basket 
				   set [status]=@incoming_status,
					   updated=@updated,
					   updated_by = @user_id
				   where basket_id=@basket_id

				-- and the items
				update basket_item
					set [status]=@incoming_status, 
						updated=@updated,
						updated_by = @user_id
				where basket_id=@basket_id
		

				-- if we are updating quantities
				if dbo.fnGetParameter(@user_id, @settings, 'M_PROCESS_BASKET_UPDATE_WINE_QTY', 'N') = 'Y'
					-- WV 2019-03-05 ONLY for calloff
					and @basket_type='CALLOFF' 
					begin
						-- undo the updating
						-- we cannot merge back any wine entries that where split but we can set them back in the previous cellar
						-- now loop over all basket lines and transfer each one back to the from cellar in the basket

						declare @set_cellar_id int
						declare @set_mixed_case_id int

						declare @bi_id int
						declare @we_id int
						declare @qty int
						declare @from_c_id int
						declare @from_mc_id int
						-- loop over all basket items
						-- retrieve basket item id, wine entry id  and the total qty in bottles.
						Declare reccursor cursor for 
								select basket_item_id, bi.wine_entry_id, cast(we.case_size_ref as int) * isnull(quantity_cases,0) + isnull(quantity_bottles,0)
									,bi.from_cellar_id, bi.from_mixed_case_id
								from basket_item bi
							join wine_entry we with (nolock) on we.wine_entry_id = bi.wine_entry_id
								where basket_id = @basket_id
   
						open reccursor
						Fetch next from reccursor into @bi_id, @we_id, @qty, @from_c_id, @from_mc_id
						-- loop over entries
						While (@@Fetch_Status = 0 )
							Begin
							
							select @set_mixed_case_id = @from_mc_id
							-- if we have a previous mixed case set cellar to null
							select @set_cellar_id = @from_c_id
							if isnull(@from_mc_id,0) > 0
								select @set_cellar_id = null

							-- pass in 'null-date'
							declare @null_date varchar(20) = dbo.fnGetParameter(@user_id,@settings,'M_DEFAULT_DATE','1843-mar-23')

							-- transfer each wine back to the previous cellar  / and/or mixed case
							-- and clear disposal DATE and notes
							EXEC st_update_wine_entry_transfer  @user_id, @settings, 'X', @out_msg OUTPUT, 
								-- type, id, stamp and options   (options is disposed type ~ price~ note)
								@output_type OUTPUT, @we_id OUTPUT,	0, 'OVERWRITESELFMANAGED~NOALERTMESSAGE~NOTRANSACTION'
								-- quantity to be moved
								,@quantity = @qty
								,@transfer_date = @updated
								-- We should only have mixed case OR cellar id
								,@cellar_id = @set_cellar_id
								,@mixed_case_id = @set_mixed_case_id
								-- not required ,@additional_notes = @add_notes
								,@status_overwrite = 'Active'
								-- reset disposal date and note
								,@disposal_date = @null_date
								,@disposal_notes = ''

							-- If we have an error
							if isnull(@out_msg,'') <> ''
								begin
									select @error = 'ERROR: Failed to transfer wine record: ' + @out_msg
									RAISERROR (@out_msg, 16, 1)
								end

							-- Basket items should remain as is but just update in case we id was changed
							update basket_item
								set wine_entry_id = @we_id,updated = getdate()
							where basket_item_id = @bi_id

							-- and get next one
							Fetch next from reccursor into @bi_id, @we_id, @qty, @from_c_id, @from_mc_id

						End  --end looping through records "

						CLOSE reccursor
						Deallocate reccursor

					end

			end

		else if @incoming_status = 'X'
			begin
				-- just update basket
				update basket 
				   set [status]=@incoming_status,
					   updated=@updated,
					   updated_by = @user_id
				   where basket_id=@basket_id

				-- and the items
				update basket_item
					set [status]=@incoming_status, 
						updated=@updated,
						updated_by = @user_id
				where basket_id=@basket_id
				-- jf 2019-06-10 also disable invoice when submitted basket get canceled
				-- and organisation invoice
				update organisation_invoice
					set [disabled] = 1,
						updated = @updated,
						updated_by = @user_id
					where invoice_ref = @basket_id

			end


		-- wv 2017-02-27 save basket in audit trail
		insert into audit_basket
		select * from basket where basket_id=@basket_id
		-- and set audit_record Id
		select @audit_record_id_new = @@IDENTITY


		-- update audit trail
		exec st_audit_hdr  @user_id, @settings, @action, @object_name, 'completed', null, @basket_id, 0, @input_fields, null,null,null, @audit_record_id_current, @audit_record_id_new


	-- commit this transaction
	COMMIT TRAN @transaction_name
	
if @incoming_status='A' 
	begin
		-- create invoice now. If this fails we need to roll back
		-- mb 2019-04-26 create an organisation invoice for the VAT to pay
		declare @basket_payment_param varchar(40) = 'M_BASKET_LIST_VAT_PAYMENT_' + isnull(@basket_type, '')
					
		if dbo.fnGetParameter(@user_id, @settings, @basket_payment_param, 'N') = 'Y'
			begin

				declare @organisation_invoice_id int = null
				declare @invoice_date datetime = null
							
				-- mb 2019-05-15 and check if basket delivery type requires a vat payment
				declare @pay_duty_vat varchar(10) = null
				select top 1 @pay_duty_vat = lookup_field_1
				from [lookup] l with (nolock)
				where category = 'BasketDeliveryType'
					and reference = @basket_delivery_type
					and isnull([disabled],0) = 0
					and brand_ref = @brand

				-- default to payment = Y
				select @pay_duty_vat = isnull(@pay_duty_vat,'Y')
				declare @output_msg varchar(8000) = null
					
				exec [dbo].[st_m_basket_payment]
					@user_id,
					@settings,
					@sql_logging,
					@output_msg OUTPUT,

					@basket_id,
					'credit',
					@pay_duty_vat,
					@organisation_invoice_id OUTPUT,
					@invoice_date OUTPUT

					-- if there is an error in payment calculation
					if isnull(@output_msg, '') <> ''
						begin
							update basket 
							set invoice_error_message = @output_msg
							where basket_id=@basket_id

							select @output_message = @output_msg
								
							EXEC st_event @user_id, @settings, @sql_logging, null, 'BASKET_CALCULATION_ERROR'
								,@user_id, 'N', null, null, null, null, null
								,'basket_id', @basket_id, 'basket', 'dm_basket_list'
								-- added  order api  so we have the same data as we may transmit
								,'order_id', @basket_id, 'order', 'dm_m_order_api'
								-- wv 2017-11-17  added new version for basket (kept both for compatibility)
								,'basket_id', @basket_id, 'basket_v2', 'dm_basket_list_v2'

							-- just create event, do not stop call off
							--IF @@trancount > 0 ROLLBACK TRAN @transaction_name
							--return

							-- create an alert message
							exec st_alert_message @user_id, @settings, @sql_logging, @output_message, 'set', @output_msg, null, 10000

						end

					else
						begin
							update basket 
							set invoice_date = @invoice_date,
								organisation_invoice_id = @organisation_invoice_id,
								invoice_error_message = ''	-- clear error message in case this has been set previously
							where basket_id=@basket_id
						end

			end
		end



	-- if output message '' then ok
	SELECT @output_message = ''
	
END TRY

BEGIN CATCH     
	-- get transaction count (need this when loggin the error but cant do update before the rollback
	declare @tran_count as int = @@trancount

	-- Because transaction is the first statement after try we can safely rollback (I think)
	IF @@trancount > 0 ROLLBACK TRAN @transaction_name

	-- set error string, including transaction count
	declare @error_str varchar(1000) = 'SQL error: '+isnull(ERROR_PROCEDURE(),'') + '  Ln: '
		+ cast(isnull(ERROR_LINE(),'') as varchar(10)) +'  Msg: '+isnull(ERROR_MESSAGE(),'')
		+ '  Transaction count: '+ cast(@tran_count as varchar(10))
	
	-- add @input_fields
	begin try
		select @error_str = @error_str + '   Input: ' + isnull(@input_fields,'')
	end try
	begin catch
		-- no action required
	end catch
	
	-- and record
	select @audit_exception = @error_str
	-- insert into audit trail
	exec st_audit @user_id, @settings, @object_name, @transaction_name, 'error', @audit_exception

	-- and return - if output NOT null then error
    SELECT @output_message = @error_str

END CATCH 



END

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_round_3]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_round_3]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_round_3] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-16
-- Description:	This procedure is the third step of the matching process.
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_round_3 @batch_id 

*/
	
	@batch_id int

AS
BEGIN

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process'
			return 0
		
		END
		
	Create table #list_of_matching_wines_round_3 (
		wine_id int
		, clean_name varchar(255)
	)
		
	DECLARE @wine_id int
	DECLARE @wine_name varchar(255)
	DECLARE @Id int
	Declare @position int
	Declare @previous_position int
	Declare @length_word int
	Declare @word varchar(255)
	Declare @presence int
	DECLARE @presence_w int
	Declare @nb_words int = 0
	
	Declare @matched_wine_id int = 0
	Declare @list_of_ids varchar(200) = ''
	Declare @matching_rank int = 0

	Declare reccursor_match_round_3 cursor for (
		Select Id from wo_match_wines 
			Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	)
	open reccursor_match_round_3

	Fetch next from reccursor_match_round_3 into @Id

	While (@@Fetch_Status = 0)
	Begin
	
		Select @wine_name = RTRIM(LTRIM(wine_name_clean))+' '
			FROM [wo_match_wines] 
			WHERE Id = @Id
		--PRINT @wine_name
		
		Set @position = 0
		Set @previous_position = 0
		Set @length_word=1
		Set @word = ''
		Set @nb_words = 0
		Set @matching_rank = 0
		
		While (@length_word>0)
			Begin
				Set @previous_position = @position
				Set @position = Charindex(' ',@wine_name, @previous_position+1)
				Set @length_word = @position - @previous_position				
						
				SELECT @word = CASE 
					WHEN @position>@previous_position THEN REPLACE(REPLACE(REPLACE(SUBSTRING(@wine_name, @previous_position, @length_word),'   ',''),'  ',''),' ','')
					--ELSE REPLACE(REPLACE(REPLACE(SUBSTRING(@wine_name, @previous_position+1, LEN(@wine_name)-@previous_position),'   ',''),'  ',''),' ','')
					ELSE ''
				END
				
				IF @word NOT IN ('','de','d', 'le', 'l', 'la', 'des', 'les', 'du') and @word NOT IN ('AOC','DOC', 'IGT')
					BEGIN
						Set @nb_words = @nb_words + 1
					
						Insert into #list_of_matching_wines_round_3 (wine_id, clean_name)
						Select wine_id, clean_name from wine 
						where ' '+clean_name+' ' like '% '+@word+' %'
							AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
							and ISNULL(reference_type,'') = 'wine'
							and LEN(ISNULL(clean_name,''))>3
					
					END
				
			End
		/*
		Select TOP 5 @list_of_ids = CAST(wine_id as varchar(20))+'-'+@list_of_ids 
			from #list_of_matching_wines_round_3 z
		GROUP BY z.wine_id
		HAVING COUNT(1) = @nb_words
		*/
		
		select top 5 z.wine_id 
		into #step_table_wine_ids
		from #list_of_matching_wines_round_3 z
		join wine w on z.wine_id = w.wine_id 
		GROUP BY z.wine_id, w.name
		HAVING COUNT(1) = @nb_words
		ORDER BY Len(w.name) DESC
		
		Select @list_of_ids = CAST(wine_id as varchar(20))+'-'+@list_of_ids 
		FROM #step_table_wine_ids
		
		Drop table #step_table_wine_ids
		
		While LEN(ISNULL(@list_of_ids,''))>4
			BEGIN
				Set @matching_rank = @matching_rank+1
				Set @matched_wine_id = CAST(LEFT(@list_of_ids, PATINDEX('%-%',@list_of_ids)-1) as int) 
				Set @list_of_ids = RIGHT(@list_of_ids, LEN(@list_of_ids)-PATINDEX('%-%',@list_of_ids))
				
				IF @matching_rank = 1
					BEGIN
						Update [wo_match_wines] 
							set wo_wine_id = @matched_wine_id, processed = 'Y'
								, matching_score = 40, updated = getdate()
								, updated_by = 1, round_matched = 3, number_of_matches = 1 
						WHERE Id = @Id
					END
				IF @matching_rank = 2
					BEGIN	
						Update [wo_match_wines] 
							set other_match_1_id = @matched_wine_id, number_of_matches = 2 
						WHERE Id = @Id
					END
				IF @matching_rank = 3
					BEGIN
						Update [wo_match_wines] 
							set other_match_2_id = @matched_wine_id, number_of_matches = 3
						WHERE Id = @Id
					END
				IF @matching_rank = 4
					BEGIN
						Update [wo_match_wines] 
							set other_match_3_id = @matched_wine_id, number_of_matches = 4
						WHERE Id = @Id
					END
				IF @matching_rank = 5
					BEGIN
						Update [wo_match_wines] 
							set other_match_4_id = @matched_wine_id, number_of_matches = 5 
						WHERE Id = @Id
					END	
			END
		
		Delete from #list_of_matching_wines_round_3
		
		Fetch next from reccursor_match_round_3 into @Id

	End  --end looping through records "
	
	CLOSE reccursor_match_round_3
	Deallocate reccursor_match_round_3
	
	Update a
		Set a.wo_wine_name = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.wo_wine_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 3 and a.processed = 'Y' and a.wo_wine_name IS NULL
	
	Update a
		Set a.other_match_1 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_1_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 3 and a.processed = 'Y' and a.other_match_1 IS NULL
	
	Update a
		Set a.other_match_2 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_2_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 3 and a.processed = 'Y' and a.other_match_2 IS NULL
	
	Update a
		Set a.other_match_3 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_3_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 3 and a.processed = 'Y' and a.other_match_3 IS NULL
	
	Update a
		Set a.other_match_4 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_4_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 3 and a.processed = 'Y' and a.other_match_4 IS NULL
	
	Drop table #list_of_matching_wines_round_3

END
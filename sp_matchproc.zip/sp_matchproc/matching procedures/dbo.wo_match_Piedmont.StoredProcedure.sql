IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_Piedmont]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_Piedmont]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_Piedmont] 

-- =============================================
-- Author:		JP
-- Create date: 2014-10-14
-- Description:	This procedure is a special step to match Piedmont wines
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_Piedmont @batch_id 
	
	the idea is:
		For Bordeaux:
			- Remove words that do not carry information.
			- Find 1) appellation 2) classification 
				, match against only the wines in our db that match this, and remove them. 
			- Look at what's left, it should be the 'significant' bit. 
			- Try to match against the wines selected by matching classification/appellation/designation.
			
		For Burgundy and others:
			- Most important is producer.
			- appellation, classification as before.
			- Vineyard and possibly cuvee/special name are then matched.
*/
	
	@batch_id int

AS
BEGIN
	
	Declare @region_ini varchar(100) = 'Piedmont' 

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
		and ISNULL(region,'')=@region_ini
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process for region Piedmont'
			RETURN 0
		
		END
		
	-- step 0: Remove some things that are a lot of trouble
	
	update wo_match_wines
		set regional_clean_name = wine_name_clean
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(region,'')=@region_ini
	
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ', ' IGT ', ' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0 
	and ISNULL(region,'')=@region_ini
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ', ' DOC ', ' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0 
	and ISNULL(region,'')=@region_ini
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ', ' DOCG ', ' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0 
	and ISNULL(region,'')=@region_ini
	
	-- step 1: Try to find appellation and classification and producer
	
	-- classification
	Declare @classification_regional varchar(255) 
	
	Declare reccursor_class_bu cursor for 
		select classification from wine 
			where ISNULL(region,'') = @region_ini and disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(classification,'') <> ''
			GROUP BY classification
			ORDER BY LEN(classification) DESC;
		
	open reccursor_class_bu

	Fetch next from reccursor_class_bu into @classification_regional

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set classification = @classification_regional
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+regional_clean_name+' ' like '% '+@classification_regional+' %'
			and ISNULL(classification,'')='' and ISNULL(region,'')=@region_ini
		
		Fetch next from reccursor_class_bu into @classification_regional
	
	END 
	
	CLOSE reccursor_class_bu
	Deallocate reccursor_class_bu
	
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ',' '+classification+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(classification ,'') <> '' and ISNULL(region,'')=@region_ini
	
	PRINT 'classifications done'
	
	-- appellation
	Declare @appellation_regional varchar(255)
	
	Declare reccursor_app_bu cursor for
		select appellation from wine 
			where ISNULL(region,'') = @region_ini and disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(appellation,'') <> ''
			GROUP BY appellation
			ORDER BY LEN(appellation) DESC;

	open reccursor_app_bu

	Fetch next from reccursor_app_bu into @appellation_regional

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set appellation = @appellation_regional
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+regional_clean_name+' ' like '% '+@appellation_regional+' %'
			and ISNULL(appellation,'') = '' and ISNULL(region,'')=@region_ini
		
		Fetch next from reccursor_app_bu into @appellation_regional
	
	END 
	
	CLOSE reccursor_app_bu
	Deallocate reccursor_app_bu
	
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ',' '+appellation+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(appellation ,'') <> '' and ISNULL(region,'')=@region_ini
	
	PRINT 'appellations done'
	
	-- producer name
	Declare @prod_name_regional varchar(255) 
	
	Declare reccursor_prod_bu cursor for 
		select producer_name from wine 
			where ISNULL(region,'') = @region_ini and disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(producer_name,'') <> ''
			GROUP BY producer_name
			ORDER BY LEN(producer_name) DESC;
		
	open reccursor_prod_bu

	Fetch next from reccursor_prod_bu into @prod_name_regional

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set producer_name = @prod_name_regional
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+regional_clean_name+' ' like '% '+@prod_name_regional+' %'
			and ISNULL(producer_name,'')='' and ISNULL(region,'')=@region_ini
		
		Fetch next from reccursor_prod_bu into @prod_name_regional
	
	END 
	
	CLOSE reccursor_prod_bu
	Deallocate reccursor_prod_bu
	
	update wo_match_wines
		set regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ',' '+producer_name+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(producer_name ,'') <> '' and ISNULL(region,'')=@region_ini
	
	PRINT 'producer names done'
	
	-- also remove grape because it stops us from matching
	
	update a
		set a.regional_clean_name = LTRIM(RTRIM(REPLACE(' '+regional_clean_name+' ',' '+b.grape+' ',' ')))
	FROM wo_match_wines a
		JOIN (
			select distinct grape from wine where ISNULL(region,'') = @region_ini and disabled = 0 
				and owner_id = 0 and reference_type = 'wine' and ISNULL(grape,'')<>''
		) b 
			ON a.regional_clean_name like '%'+b.grape+'%'
	where a.batch_id = @batch_id and ISNULL(a.processed,'N') = 'N' and ISNULL(a.disabled,0) = 0
	and ISNULL(a.region,'')=@region_ini
	
	PRINT 'Piedmont matching starting'
	
	-- Now start the matching
	
	Create table #list_of_matching_wines_regional (
		wine_id int
		, clean_name varchar(255)
	)
	
	DECLARE @wine_id int
	DECLARE @wine_name varchar(255)
	DECLARE @Id int
	Declare @classification_match varchar(255)
	Declare @appellation_match varchar(255)
	Declare @producer_match varchar(255)
	Declare @wine_id_empty int = 0
	
	Declare @matched_wine_id int = 0
	Declare @list_of_ids varchar(200) = ''
	Declare @matching_rank int = 0

	Declare reccursor_match_regional cursor for (
		Select Id, classification, appellation, producer_name from wo_match_wines 
			Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ISNULL(region,'')=@region_ini
	)
	open reccursor_match_regional

	Fetch next from reccursor_match_regional into @Id, @classification_match, @appellation_match, @producer_match

	While (@@Fetch_Status = 0)
	Begin
	
		Set @matching_rank = 0
		Set @wine_id_empty = 0
	
		Select @wine_name = RTRIM(LTRIM(regional_clean_name))
			FROM [wo_match_wines] 
			WHERE Id = @Id
		PRINT @wine_name
		
		IF @wine_name <> ''
			BEGIN
				Insert into #list_of_matching_wines_regional (wine_id, clean_name)
					Select wine_id, piedmont_clean_name from wine 
					where LTRIM(RTRIM(piedmont_clean_name)) = LTRIM(RTRIM(@wine_name))
						AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
						AND ISNULL(reference_type,'') = 'wine' and ISNULL(region,'') = @region_ini
						AND LEN(ISNULL(piedmont_clean_name,''))>2
						AND (ISNULL(@classification_match,'') = ISNULL(classification,'') OR ISNULL(@classification_match,'')='')
						AND (ISNULL(@appellation_match,'') = ISNULL(appellation,'') OR ISNULL(@appellation_match,'')='')
						AND (ISNULL(@producer_match,'') = ISNULL(producer_name,'') OR ISNULL(@producer_match,'')='')
				
				select top 5 z.wine_id 
				into #step_table_wine_ids
				from #list_of_matching_wines_regional z
				join wine w on z.wine_id = w.wine_id 
				ORDER BY Len(w.name) DESC
				
				Select @list_of_ids = CAST(wine_id as varchar(20))+'-'+@list_of_ids 
				FROM #step_table_wine_ids
				
				Drop table #step_table_wine_ids
				
				While LEN(ISNULL(@list_of_ids,''))>4
					BEGIN
						Set @matching_rank = @matching_rank+1
						Set @matched_wine_id = CAST(LEFT(@list_of_ids, PATINDEX('%-%',@list_of_ids)-1) as int) 
						Set @list_of_ids = RIGHT(@list_of_ids, LEN(@list_of_ids)-PATINDEX('%-%',@list_of_ids))
						
						IF @matching_rank = 1
							BEGIN
								Update [wo_match_wines] 
									set wo_wine_id = @matched_wine_id, processed = 'Y'
										, matching_score = 45, updated = getdate()
										, updated_by = 1, round_matched = 7, number_of_matches = 1 
								WHERE Id = @Id
							END
						IF @matching_rank = 2
							BEGIN	
								Update [wo_match_wines] 
									set other_match_1_id = @matched_wine_id, number_of_matches = 2 
								WHERE Id = @Id
							END
						IF @matching_rank = 3
							BEGIN
								Update [wo_match_wines] 
									set other_match_2_id = @matched_wine_id, number_of_matches = 3
								WHERE Id = @Id
							END
						IF @matching_rank = 4
							BEGIN
								Update [wo_match_wines] 
									set other_match_3_id = @matched_wine_id, number_of_matches = 4
								WHERE Id = @Id
							END
						IF @matching_rank = 5
							BEGIN
								Update [wo_match_wines] 
									set other_match_4_id = @matched_wine_id, number_of_matches = 5 
								WHERE Id = @Id
							END	
					END
				
				Delete from #list_of_matching_wines_regional
			END
		ELSE
			BEGIN
				
				Select @wine_id_empty = wine_id from wine 
				where ISNULL(piedmont_clean_name,'') = ''
					AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
					AND ISNULL(reference_type,'-1') = 'wine' and ISNULL(region,'') = @region_ini
					AND ISNULL(@classification_match,'-1') = ISNULL(classification,'') 
					AND ISNULL(@appellation_match,'-1') = ISNULL(appellation,'') 
					AND ISNULL(@producer_match,'-1') = ISNULL(producer_name,'')
					
				
				IF @wine_id_empty <> 0
					BEGIN
					
						Update [wo_match_wines] 
							set wo_wine_id = @wine_id_empty, processed = 'Y'
								, matching_score = 45, updated = getdate()
								, updated_by = 1, round_matched = 7, number_of_matches = 1 
						WHERE Id = @Id
					
					END
				
						
			END
		
		Fetch next from reccursor_match_regional into @Id, @classification_match, @appellation_match, @producer_match


	End  --end looping through records "
	
	CLOSE reccursor_match_regional
	Deallocate reccursor_match_regional
	
	Update a
		Set a.wo_wine_name = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.wo_wine_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.wo_wine_name IS NULL
		and ISNULL(a.region,'')=@region_ini
	
	Update a
		Set a.other_match_1 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_1_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_1 IS NULL
		and ISNULL(a.region,'')=@region_ini
	
	Update a
		Set a.other_match_2 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_2_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_2 IS NULL
		and ISNULL(a.region,'')=@region_ini
	
	Update a
		Set a.other_match_3 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_3_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_3 IS NULL
		and ISNULL(a.region,'')=@region_ini
	
	Update a
		Set a.other_match_4 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_4_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_4 IS NULL
		and ISNULL(a.region,'')=@region_ini
	
	Drop table #list_of_matching_wines_regional

END
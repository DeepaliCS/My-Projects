IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_round_1]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_round_1]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_round_1] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-16
-- Description:	This procedure is the first step of the matching process.
-- It just looks for exact matches (between clean names)
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_round_1 @batch_id 

*/
	
	@batch_id int

AS
BEGIN

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process'
			return 0
		
		END

	Update a
		Set a.stamp = a.stamp + 1
			, a.updated = getdate()
			, a.updated_by = 35
			, a.processed = 'Y'
			, a.wo_wine_name = w.name
			, a.wo_wine_id = w.wine_id
			, a.number_of_matches = 1
			, a.round_matched = 1
			, a.matching_score = 100
	From wo_match_wines a
		Join wine w On a.wine_name_clean = w.clean_name collate Latin1_General_CI_AS
			AND ISNULL(w.disabled,0) = 0 and ISNULL(w.owner_id,0) = 0 
			and ISNULL(w.reference_type,'') = 'wine'
			and LEN(ISNULL(w.clean_name,''))>2
	Where a.batch_id = @batch_id and ISNULL(a.processed,'N') = 'N' and ISNULL(a.disabled,0) = 0

END
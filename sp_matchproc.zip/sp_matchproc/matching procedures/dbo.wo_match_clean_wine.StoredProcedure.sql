IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_clean_wine]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_clean_wine]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_clean_wine] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-15
-- Description:	This procedure cleans the wine table
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_clean_wine @batch_id

*/

	@batch_id int

AS
BEGIN
	
	Declare @word varchar(100)
	Declare @typo varchar(100)
	
	-- First clean symbols
	
	Update wine 
		Set	clean_name = ' '+REPLACE(REPLACE(REPLACE(dbo.fnMatchingCleanWineName(name),']',''),'[',''),'�',' ')+' ' COLLATE Latin1_General_CI_AS
			, appellation = ' '+REPLACE(REPLACE(REPLACE(dbo.fnMatchingCleanWineName(appellation),']',''),'[',''),'�',' ')+' ' COLLATE Latin1_General_CI_AS
			, classification = ' '+REPLACE(REPLACE(REPLACE(dbo.fnMatchingCleanWineName(classification),']',''),'[',''),'�',' ')+' ' COLLATE Latin1_General_CI_AS
			, producer_name = ' '+REPLACE(REPLACE(REPLACE(dbo.fnMatchingCleanWineName(producer_name),']',''),'[',''),'�',' ')+' ' COLLATE Latin1_General_CI_AS
	-- Then remove weird words
	
	Declare reccursor_clean_wine cursor for
			Select typo, word from typo_table
			ORDER BY LEN(typo) DESC
	open reccursor_clean_wine
	
	FETCH NEXT FROM reccursor_clean_wine INTO @typo, @word

	WHILE (@@Fetch_Status = 0)
		BEGIN
			
			Update wine
				Set	clean_name = LTRIM(RTRIM(REPLACE(' '+clean_name+' ',' '+@typo+' ',' '+@word+' ')))
					, appellation = LTRIM(RTRIM(REPLACE(' '+appellation+' ',' '+@typo+' ',' '+@word+' ')))
					, classification = LTRIM(RTRIM(REPLACE(' '+classification+' ',' '+@typo+' ',' '+@word+' ')))
					, producer_name = LTRIM(RTRIM(REPLACE(' '+producer_name+' ',' '+@typo+' ',' '+@word+' ')))
			
			FETCH NEXT FROM reccursor_clean_wine INTO @typo, @word
		
		END  --end looping through records "
	
	CLOSE reccursor_clean_wine
	DEALLOCATE reccursor_clean_wine
	-- create clean_name
	Update wine
		Set clean_name = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(clean_name,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
			, appellation = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(appellation,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
			, classification = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(classification,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
			, producer_name = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(producer_name,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
	
	-- create Bordeaux_clean_name
	Update wine 
		Set Bordeaux_clean_name = clean_name
		
	Update wine
		set Bordeaux_clean_name = LTRIM(RTRIM(REPLACE(REPLACE(' '+Bordeaux_clean_name+' ', ' AOC ', ' '),' Vin de France ',' ')))

	update wine 
		set Bordeaux_clean_name = LTRIM(RTRIM(REPLACE(' '+Bordeaux_clean_name+' ',' '+classification+' ',' ')))
	where ISNULL(classification,'') <> ''
	update wine 
		set Bordeaux_clean_name = LTRIM(RTRIM(REPLACE(' '+Bordeaux_clean_name+' ',' '+appellation+' ',' ')))
	where ISNULL(appellation,'') <> ''
	update wine
		set Bordeaux_clean_name = LTRIM(RTRIM(REPLACE(' '+Bordeaux_clean_name+' ',' '+'Rouge'+' ',' ')))
	where ISNULL(wine_type,'') = 'Red'
	
	-- create Burgundy_clean_name
	update wine 
		set Burgundy_clean_name = clean_name
	Update wine
		set Burgundy_clean_name = LTRIM(RTRIM(REPLACE(REPLACE(' '+Burgundy_clean_name+' ', ' AOC ', ' '),' Vin de France ',' ')))
	update wine 
		set Burgundy_clean_name = LTRIM(RTRIM(REPLACE(' '+Burgundy_clean_name+' ',' '+classification+' ',' ')))
	where ISNULL(classification,'') <> ''
	update wine 
		set Burgundy_clean_name = LTRIM(RTRIM(REPLACE(' '+Burgundy_clean_name+' ',' '+appellation+' ',' ')))
	where ISNULL(appellation,'') <> ''

	update wine 
		set Burgundy_clean_name = replace(Burgundy_clean_name, 'Maison ', '')
			, producer_name = REPLACE(producer_name, 'Maison ', '')
	where ISNULL(producer_name, '') <> ''
		and producer_name like 'Maison %'
	
	update wine 
		set Burgundy_clean_name = LTRIM(RTRIM(REPLACE(' '+Burgundy_clean_name+' ',' '+producer_name+' ',' ')))
	where ISNULL(producer_name, '') <> ''
	
	-- create Tuscany_clean_name
	update wine 
		set Tuscany_clean_name = clean_name
		
	Update wine
		set Tuscany_clean_name = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(' '+Tuscany_clean_name+' ', ' IGT ', ' '),' DOCG ',' '),' DOC ',' ')))
	
	update wine 
		set Tuscany_clean_name = LTRIM(RTRIM(REPLACE(' '+Tuscany_clean_name+' ',' '+producer_name+' ',' ')))
	where ISNULL(producer_name, '') <> ''
	
	-- create Piedmont_clean_name
	update wine 
		set Piedmont_clean_name = Tuscany_clean_name
		
	update wine 
		set Alsace_clean_name = Burgundy_clean_name
		
	update wine 
		set Germany_clean_name = Burgundy_clean_name
	
	update wine 
		set California_clean_name = Burgundy_clean_name
		
	update wine 
		set no_region_clean_name = Burgundy_clean_name
	update wine
		set no_region_clean_name = LTRIM(RTRIM(REPLACE(' '+no_region_clean_name+' ',' '+'Rouge'+' ',' ')))
	where ISNULL(wine_type,'') = 'Red'

END

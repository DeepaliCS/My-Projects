IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_clean_find_suspects]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_clean_find_suspects]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_clean_find_suspects] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-15
-- Description:	This procedure finds the words from the incoming table that are not already in our database
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_clean_find_suspects @batch_id, 'find'
	
	Declare @batch_id int = 1
	
	EXEC wo_match_clean_find_suspects @batch_id, 'retrieve'
	

*/

/*

	CREATE TABLE wo_match_suspect_words(
		suspect_id int identity NOT NULL PRIMARY KEY -- id
		, batch_id int -- batch id
		, suspect_word varchar(255) -- word that doesn't appear in our database
		, corrected_word varchar(255) -- corrected word
		, is_valid bit -- true if the word is actually a valid word
		, type varchar(30) -- size, vintage, or real typo?
	)

*/

	@batch_id int
	, @option varchar(50)

AS
BEGIN

	If @option = 'find'
		Begin
		
			DECLARE @wine_id int
			DECLARE @wine_name varchar(255)
			DECLARE @Id int
			Declare @position int
			Declare @previous_position int
			Declare @length_word int
			Declare @word varchar(255)
			Declare @presence int
			DECLARE @presence_w int

			Declare reccursor_suspect cursor for (
				Select Id from wo_match_wines 
					Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			)
			open reccursor_suspect

			Fetch next from reccursor_suspect into @Id

			While (@@Fetch_Status = 0)
			Begin
			
				Select @wine_name=wine_name_clean+' '
					FROM [wo_match_wines] 
					WHERE Id = @Id
				--PRINT @wine_name
				
				Set @position = 0
				Set @previous_position = 0
				Set @length_word=1
				Set @word = ''
				
				While (@length_word>0)
					Begin
						Set @previous_position = @position
						Set @position = Charindex(' ',@wine_name, @previous_position+1)
						Set @length_word = @position - @previous_position			
						
						--PRINT @wine_name
						--PRINT @previous_position
						--PRINT @position
						--PRINT @length_word
						
						SELECT @word = CASE 
							WHEN @position>@previous_position THEN REPLACE(REPLACE(REPLACE(SUBSTRING(@wine_name, @previous_position, @length_word),'   ',''),'  ',''),' ','')
							--ELSE REPLACE(REPLACE(REPLACE(SUBSTRING(@wine_name, @previous_position+1, LEN(@wine_name)-@previous_position),'   ',''),'  ',''),' ','')
							ELSE ''
						END
						
						--PRINT @word
						
						IF @word <> ''
							BEGIN
							
								IF NOT EXISTS(
								Select 1 from wine where ' '+clean_name+' ' like '% '+@word+' %'
									AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
									and ISNULL(reference_type,'') = 'wine'
									and LEN(ISNULL(clean_name,''))>3
								) AND NOT EXISTS (
									Select 1 from wo_match_suspect_words 
										where suspect_word = @word and batch_id = @batch_id
								)
									BEGIN
								
										Insert into wo_match_suspect_words (
											batch_id, suspect_word, is_valid
										)
										VALUES (
											@batch_id, @word, 0
										)
										
									END
							
							END
							
					End
				
				Fetch next from reccursor_suspect into @Id

			End  --end looping through records "
			
			CLOSE reccursor_suspect
			Deallocate reccursor_suspect
				
		End
		
		If @option = 'retrieve'
			Begin 
				
				Insert into sizes_and_vintages_table (word, typo)
				Select '', suspect_word from wo_match_suspect_words
					where batch_id = @batch_id and is_valid = 1
					and ISNULL(type,'') IN ('size','vintage')
					
				Insert into typo_table (word, typo)
				Select corrected_word, suspect_word from wo_match_suspect_words
					where batch_id = @batch_id and is_valid = 1
					and ISNULL(type,'') IN ('typo','abrev')
			
			End 
	
END
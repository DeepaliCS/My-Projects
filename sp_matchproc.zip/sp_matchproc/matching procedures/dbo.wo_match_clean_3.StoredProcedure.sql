IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_clean_3]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_clean_3]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_clean_3] 

-- =============================================
-- Author:		JP
-- Create date: 2013-02-25
-- Description:	This procedure removes country and region names form the clean names
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_clean_3 @batch_id
	
*/

	@batch_id int

AS
BEGIN
	
	Update wo_match_wines 
		Set	wine_name_clean =  ' '+wine_name_clean+' '
	Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0

	Declare @typo varchar(100)
	
	Declare reccursor_clean_3 cursor for
			Select region from [Live_server_link].live1_wo_main.dbo.region
			where region_type IN ('region','Country')
			and disabled = 0
			and region <> 'Rhone'
			ORDER BY LEN(region) DESC
	open reccursor_clean_3

	FETCH NEXT FROM reccursor_clean_3 INTO @typo

	WHILE (@@Fetch_Status = 0)
		BEGIN
			
			Update wo_match_wines 
				Set	wine_name_clean =  REPLACE(' '+wine_name_clean+' ',' '+@typo+' ',' ')
			Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			
			FETCH NEXT FROM reccursor_clean_3 INTO @typo
		
		END  --end looping through records "
	
	CLOSE reccursor_clean_3
	DEALLOCATE reccursor_clean_3
	
	Update wo_match_wines 
		Set wine_name_clean = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(wine_name_clean,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
	Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	
END
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[fnMatchingCleanWineName]')  AND type = N'FN')
     DROP FUNCTION [dbo].[fnMatchingCleanWineName]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [dbo].[fnMatchingCleanWineName]
(
	@wine_name varchar(250)
)
RETURNS varchar(250)
AS
BEGIN

	-- =============================================
	-- Author:		JP
	-- Create date: 2014-06-05
	-- Description:	Clean wine name for the matching process (adapted from dbo.fnCleanWineName)
	-- =============================================


	/* cleans a wine name
	
	-- call as
	
	declare @result varchar(100)
	print ''
	select @result = dbo.fnMatchingCleanWineName('Ch�teau d`yquem')
	print @result

	*/

	-- and all single replacements
	select @wine_name =	
				ltrim(rtrim(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(
				replace(' ' + @wine_name, '''', ' ')
				, '-', ' ')
				, 'amp;', ' ')
				, '&amp;', ' ')
				, ' & ', ' ')
				, ' and ', ' ')
				, ' et ', ' ')
				, '�', 'a')
				, '�', 'e')
				, '�', 'u')
				, '#', '')
				, '(', ' ')
				, ')', ' ')
				, '{', ' ')
				, '}', ' ')
				, ',', ' ')
				, '�', ' ')
				, '�', ' ')
				, '�', '')
				, '`', '')
				, '�', '')
				, '^', '')
				, ':', ' ')
				, ';', ' ')
				, '_', ' ')
				, '.', ' ')
				, '+', ' ')
				, '!', ' ')
				, '/', ' ')
				, '\', ' ')
				, '''', ' ')
				, '"', ' ')
				, '%', ' ')
				, '?', '_')
				, '    ', ' ')
				, '   ', ' ')
				, '  ', ' ')
				))
		
	--special for st
	--select @wine_name =ltrim(rtrim(REPLACE(' '+@wine_name+' ',' saint ',' St ')))

	-- and return
	return @wine_name

END

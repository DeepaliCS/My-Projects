IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_one]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_one]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_one] 

-- =============================================
-- Author:		JP
-- Create date: 2014-01-15
-- Description:	This procedure runs the matching process on one wine
-- =============================================

/*

Call it this way: 
	
	EXEC wo_match_one 'chateau margaux', '', '', ''
	EXEC wo_match_one 'chateau margaux', 'France', 'Bordeaux', ''
	EXEC wo_match_one 'chateau margaux', 'France', 'Burgundy', ''

Declare @wine varchar(255) = 'chateau margaux'
Declare @country varchar(255) = 'France'
Declare @region varchar(255) = 'Bordeaux'
Declare @options varchar(255) = ''
EXEC wo_match_one @wine, @country, @region, @options

*/

	@word varchar(255)
	, @country varchar(255) -- for now country doesn't do anything, because we match by regions
	, @region varchar(255) = ''
	, @option varchar(1000) = ''

AS
BEGIN

declare @batch_id int
select @batch_id = max(batch_id)+1 from Matching_DB.dbo.wo_match_wines

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
VALUES (
	@batch_id, '', @word, 'N'
	, 0, getdate(), 1, 1, @region
)

-- EXEC wo_match_run 'clean', @batch_id, 'nosuspect' 
-- Run the matching
Exec wo_match_clean_1 @batch_id
Exec wo_match_clean_2 @batch_id
Exec wo_match_run 'Match', @batch_id, 'Regional'

-- select the result
select * from wo_match_wines where batch_id = @batch_id
-- print the batch id
print @batch_id

END
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_round_5]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_round_5]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_round_5] 

-- =============================================
-- Author:		JP
-- Create date: 2014-02-25
-- Description:	This procedure is the fifth step of the matching process.
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_round_5 @batch_id 

*/
	
	@batch_id int

AS
BEGIN

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process'
			return 0
		
		END
		
	UPDATE a
	SET a.wo_wine_id = b.wine_id, a.processed = 'Y'
		, a.round_matched = 5, a.number_of_matches = 1
		, a.matching_score = 30, a.wo_wine_name = w.name
	FROM wo_match_wines a
	JOIN matches_historic b
	ON a.wine_name_clean = b.clean_name
	JOIN wine w
	ON b.wine_id = w.wine_id
	where a.batch_id = @batch_id and ISNULL(a.processed,'N') = 'N' and ISNULL(a.disabled,0) = 0
	and w.disabled = 0 and w.owner_id = 0
	and a.wine_name_clean is not null and b.clean_name is not null
	
END
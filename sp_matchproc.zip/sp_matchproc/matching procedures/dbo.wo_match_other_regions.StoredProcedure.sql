IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_other_regions]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_other_regions]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_other_regions] 

-- =============================================
-- Author:		JP
-- Create date: 2014-06-03
-- Description:	This procedure is a special step to match wines that are neither Burgundy nor Bordeaux
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_other_regions @batch_id 
	
	the idea is:
			- Remove words that do not carry information.
			- Find 1) producer 2) appellation 3) classification 
				, match against only the wines in our db that match this, and remove them. 
			- Look at what's left, it should be the 'significant' bit. 
			- Try to match against the wines selected by matching producer/classification/appellation
			
*/
	
	@batch_id int

AS
BEGIN

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process'
			RETURN 0
		
		END
		
	-- step 1: Try to find appellation and classification and producer
	
	-- classification
	Declare @classification_other varchar(255) 
	
	Declare reccursor_class_o cursor for 
		select classification from wine 
			where disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(classification,'') <> ''
			GROUP BY classification
			ORDER BY LEN(classification) DESC;
		
	open reccursor_class_o

	Fetch next from reccursor_class_o into @classification_other

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set classification = @classification_other
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+wine_name_clean+' ' like '% '+@classification_other+' %'
			and ISNULL(classification,'')=''
		
		Fetch next from reccursor_class_o into @classification_other
	
	END 
	
	CLOSE reccursor_class_o
	Deallocate reccursor_class_o
	
	PRINT 'classifications done'
	
	-- appellation
	Declare @appellation_other varchar(255)
	
	Declare reccursor_app_o cursor for
		select appellation from wine 
			where disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(appellation,'') <> ''
			GROUP BY appellation
			ORDER BY LEN(appellation) DESC;

	open reccursor_app_o

	Fetch next from reccursor_app_o into @appellation_other

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set appellation = @appellation_other
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+wine_name_clean+' ' like '% '+@appellation_other+' %'
			and ISNULL(appellation,'') = ''
		
		Fetch next from reccursor_app_o into @appellation_other
	
	END 
	
	CLOSE reccursor_app_o
	Deallocate reccursor_app_o
	
	PRINT 'appellations done'
	
	-- producer name
	Declare @prod_name_other varchar(255) 
	
	Declare reccursor_prod_o cursor for 
		select producer_name from wine 
			where disabled = 0 
				and owner_id = 0 and reference_type = 'wine'
				and ISNULL(producer_name,'') <> ''
			GROUP BY producer_name
			ORDER BY LEN(producer_name) DESC;
		
	open reccursor_prod_o

	Fetch next from reccursor_prod_o into @prod_name_other

	While (@@Fetch_Status = 0)
	Begin
		
		update wo_match_wines
			set producer_name = @prod_name_other
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			and ' '+wine_name_clean+' ' like '% '+@prod_name_other+' %'
			and ISNULL(producer_name,'')=''
		
		Fetch next from reccursor_prod_o into @prod_name_other
	
	END 
	
	CLOSE reccursor_prod_o
	Deallocate reccursor_prod_o
	
	PRINT 'producer names done'
	
	-- remove classification and appellation and producer name and useless designation from the names to match
	
	update wo_match_wines
		set wine_name_clean = LTRIM(RTRIM(REPLACE(' '+wine_name_clean+' ',' '+classification+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(classification ,'') <> ''
	update wo_match_wines
		set wine_name_clean = LTRIM(RTRIM(REPLACE(' '+wine_name_clean+' ',' '+appellation+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(appellation ,'') <> ''
	update wo_match_wines
		set wine_name_clean = LTRIM(RTRIM(REPLACE(' '+wine_name_clean+' ',' '+producer_name+' ',' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	and ISNULL(producer_name ,'') <> ''
	
	update wo_match_wines
		set wine_name_clean = LTRIM(RTRIM(REPLACE(' '+wine_name_clean+' ', ' AOC ', ' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	update wo_match_wines
		set wine_name_clean = LTRIM(RTRIM(REPLACE(' '+wine_name_clean+' ', ' Vin de France ', ' ')))
	where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	
	PRINT 'other regional matching starting'
	
	-- Now start the matching
	
	Create table #list_of_matching_wines_other (
		wine_id int
		, clean_name varchar(255)
	)
	
	DECLARE @wine_id int
	DECLARE @wine_name varchar(255)
	DECLARE @Id int
	Declare @classification_match varchar(255)
	Declare @appellation_match varchar(255)
	Declare @producer_match varchar(255)
	Declare @wine_id_empty int = 0
	
	Declare @matched_wine_id int = 0
	Declare @list_of_ids varchar(200) = ''
	Declare @matching_rank int = 0

	Declare reccursor_match_Other cursor for (
		Select Id, classification, appellation, producer_name from wo_match_wines 
			Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	)
	open reccursor_match_Other

	Fetch next from reccursor_match_Other into @Id, @classification_match, @appellation_match, @producer_match

	While (@@Fetch_Status = 0)
	Begin
	
		Set @matching_rank = 0
		Set @wine_id_empty = 0
	
		Select @wine_name = RTRIM(LTRIM(wine_name_clean))
			FROM [wo_match_wines] 
			WHERE Id = @Id
		PRINT @wine_name
		
		IF @wine_name <> ''
			BEGIN
				Insert into #list_of_matching_wines_other (wine_id, clean_name)
					Select wine_id, other_clean_name from wine 
					where LTRIM(RTRIM(other_clean_name)) = LTRIM(RTRIM(@wine_name))
						AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
						AND ISNULL(reference_type,'') = 'wine'
						AND LEN(ISNULL(other_clean_name,''))>2
						AND (ISNULL(@classification_match,'') = ISNULL(classification,'') OR ISNULL(@classification_match,'')='')
						AND (ISNULL(@appellation_match,'') = ISNULL(appellation,'') OR ISNULL(@appellation_match,'')='')
						AND (ISNULL(@producer_match,'') = ISNULL(producer_name,'') OR ISNULL(@producer_match,'')='')
				
				select top 5 z.wine_id 
				into #step_table_wine_ids
				from #list_of_matching_wines_other z
				join wine w on z.wine_id = w.wine_id 
				ORDER BY Len(w.name) DESC
				
				Select @list_of_ids = CAST(wine_id as varchar(20))+'-'+@list_of_ids 
				FROM #step_table_wine_ids
				
				Drop table #step_table_wine_ids
				
				While LEN(ISNULL(@list_of_ids,''))>4
					BEGIN
						Set @matching_rank = @matching_rank+1
						Set @matched_wine_id = CAST(LEFT(@list_of_ids, PATINDEX('%-%',@list_of_ids)-1) as int) 
						Set @list_of_ids = RIGHT(@list_of_ids, LEN(@list_of_ids)-PATINDEX('%-%',@list_of_ids))
						
						IF @matching_rank = 1
							BEGIN
								Update [wo_match_wines] 
									set wo_wine_id = @matched_wine_id, processed = 'Y'
										, matching_score = 45, updated = getdate()
										, updated_by = 1, round_matched = 7, number_of_matches = 1 
								WHERE Id = @Id
							END
						IF @matching_rank = 2
							BEGIN	
								Update [wo_match_wines] 
									set other_match_1_id = @matched_wine_id, number_of_matches = 2 
								WHERE Id = @Id
							END
						IF @matching_rank = 3
							BEGIN
								Update [wo_match_wines] 
									set other_match_2_id = @matched_wine_id, number_of_matches = 3
								WHERE Id = @Id
							END
						IF @matching_rank = 4
							BEGIN
								Update [wo_match_wines] 
									set other_match_3_id = @matched_wine_id, number_of_matches = 4
								WHERE Id = @Id
							END
						IF @matching_rank = 5
							BEGIN
								Update [wo_match_wines] 
									set other_match_4_id = @matched_wine_id, number_of_matches = 5 
								WHERE Id = @Id
							END	
					END
				
				Delete from #list_of_matching_wines_other
			END
		ELSE
			BEGIN
				
				Select @wine_id_empty = wine_id from wine 
				where other_clean_name = ''
					AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0 
					AND ISNULL(reference_type,'-1') = 'wine'
					AND ISNULL(@classification_match,'-1') = ISNULL(classification,'') 
					AND ISNULL(@appellation_match,'-1') = ISNULL(appellation,'') 
					AND ISNULL(@producer_match,'-1') = ISNULL(producer_name,'')
					
				
				IF @wine_id_empty <> 0
					BEGIN
					
						Update [wo_match_wines] 
							set wo_wine_id = @wine_id_empty, processed = 'Y'
								, matching_score = 45, updated = getdate()
								, updated_by = 1, round_matched = 7, number_of_matches = 1 
						WHERE Id = @Id
					
					END
				
						
			END
		
		Fetch next from reccursor_match_Other into @Id, @classification_match, @appellation_match, @producer_match


	End  --end looping through records "
	
	CLOSE reccursor_match_Other
	Deallocate reccursor_match_Other
	
	Update a
		Set a.wo_wine_name = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.wo_wine_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.wo_wine_name IS NULL
	
	Update a
		Set a.other_match_1 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_1_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_1 IS NULL
	
	Update a
		Set a.other_match_2 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_2_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_2 IS NULL
	
	Update a
		Set a.other_match_3 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_3_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_3 IS NULL
	
	Update a
		Set a.other_match_4 = w.name
	FROM wo_match_wines a
	JOIN wine w
		ON a.other_match_4_id = w.wine_id
	WHERE a.batch_id = @batch_id and a.round_matched = 7 and a.processed = 'Y' and a.other_match_4 IS NULL
	
	Drop table #list_of_matching_wines_other

END
SET NOCOUNT ON;

-- =============================================
-- Author:		Deepali
-- Create date: 09/08/2019
-- Description: SCRIPT matching algorithm (SQL version)
-- =============================================

DROP TABLE IF exists #Temp
--DROP TABLE IF exists #combined_clean_wine_names


select * into #Temp from 
	(select BrandName
		, ProductDescription
		, Year
		, incoming_wine_name
		, wo_id
		, t_id
		, not_matching
		, not_matching_reason
		, clean_name
		, ROW_NUMBER() OVER (ORDER BY BrandName) as RowID from Matching_DB.dbo.[OCtavian_data_customers_20190617_v3]  
	) tbl

--select RowID, * from #Temp
----------------


DECLARE @cnt_no_particles INT = 0;
DECLARE @cnt_approved_particles INT = 0;
declare @no_of_particles int;
declare @selected_particle varchar(100);
declare @clean_wine_name_for_match varchar(100);
declare @sql_random_clean_name varchar(1000);
declare @local_fitness_function as int = 0;
--decimal for percentages
declare @global_fitness_function as decimal
declare @cnt_global_fitness_function as decimal

declare @inc_wine_name varchar(100)
declare @cnt INT
declare @cnt_total INT = 0;
declare @inner_cnt_total INT = 0;
declare @innerCnt int = 0;
declare @Item as varchar(500)
declare @Items_in_List INT = 0;
declare @total_number_of_searches int = 0;

drop table IF exists #save_temp_table_names
create table #save_temp_table_names (temp_table_name varchar(10))

declare @sql varchar(max) -- for dynamic sql action



--set @cnt_total = (select max(RowId) from #Temp)  -- REAL COUNT TOTAL
set @cnt_total = 2 -- E.g - to see 2 lists, you have to input 3
set @cnt = 1;


--select top (@cnt_total) * from #Temp order by RowID

-- Loop for all incoming wine names (inner_cnt_total)
-- BEGIN LOOP
WHILE @cnt < @cnt_total
BEGIN
	
	drop table IF exists #temp_split
	drop table IF exists #combined_clean_wine_names
	drop table IF exists #copyTempSplit
	drop table IF exists #accepted_particles
	drop table IF exists #particles_randomly_matched
	drop table IF exists #particles_temp
	drop table IF exists #copy_accepted_particles
	DROP TABLE IF exists #combined_wine_names_row
	drop table if exists #save_fitness_history
	drop table if exists #distinct_save_fitness_history_row
	drop table if exists #finale_table
	drop table if exists #distinct_gff
	drop table if exists #row_distinct_gff
	drop table if exists #distinct_count_itemGFF
	drop table if exists #twenty_percent_final
	drop table if exists #eighty_percent_final
	
	
	-- Collecting the incoming wine name to be matched
	--set @inc_wine_name = (
						--select top 1 wine_name_clean from #Temp where RowID = @cnt 
						--and
						--(incoming_wine_name like 'LAVILLE HAUT BRION BLANC (-)') 
						----(incoming_wine_name not like 'CASE 15 CH FILHOT 12x75 (-)'  
						--and incoming_wine_name not like 'CDP HOMMAGE J PERRIN (-)'
						--and incoming_wine_name not like 'CH MOUTON (-)'  
						--)
						--)

	set @inc_wine_name =  'LAVILLE HAUT BRION BLANC (-)'
	--'MEURSAULT PERRIERS PC (LUCIEN LE MOINE)'


	-- split the words of the incoming wine name and save it as a list in to this table
	select * into #temp_split from fnSplitStringNew(@inc_wine_name, ' ')
	select @inner_cnt_total = COUNT(*) from #temp_split

	select @inc_wine_name as incoming_wine_name


	create table #save_fitness_history (wine_id int, clean_name varchar(500), globalFF int)
	create table #combined_clean_wine_names (id int, clean_name varchar(1000));
	create table #accepted_particles(accepted_particles varchar(500));
	create table #particles_randomly_matched( particles varchar(500)
											, clean_wine_name varchar(500)
											, local_fitness_function int
											, global_fitness_function int
											);
	create table #finale_table (wine_id int, matching_wine_name varchar(500), weights decimal(10,2), itemGFF int, fitness_measure decimal(10,2))
	create table #distinct_count_itemGFF (item_gff int, count_of_item_gff int)


		-- MAIN LOOP
		WHILE @innerCnt < @inner_cnt_total
			BEGIN

			-- iterate through one item (word) of the item list (that is the incoming wine name)
			select top 1 @Item = Item from #temp_split ORDER BY Len(Item) desc

			DROP TABLE IF exists #individual_items_list
		
			-- getting potential wine name matches from wine_matching
			select * into #individual_items_list from
				(
				select wine_id, clean_name from wine_matching -- wine
				where ' '+clean_name+' ' like '% '+@Item+' %'
					AND ISNULL(disabled,0) = 0 and ISNULL(owner_id,0) = 0
					and ISNULL(reference_type,'') = 'wine'
					and LEN(ISNULL(clean_name,'')) > 2
				
				) as list

			select @total_number_of_searches = count(*) from #individual_items_list

--select '#individual_items_list' as individual_items_list	
--select * from #individual_items_list

				-- Save names and the particles where there are no numbers or clean_wine_name searches is > 0
				-- Saving the approved items (little cleaning process)
				if (@total_number_of_searches > 0) --and (@Item not like '%[0-9]%')
					BEGIN
						insert into #combined_clean_wine_names (id, clean_name)
						(select * from #individual_items_list);

						-- save words to be used in pso
						insert into #accepted_particles (accepted_particles)
						(select @Item)
					END

--select '#combined_clean_wine_names' as combined_clean_wine_names	
--select * from #combined_clean_wine_names
		
				
				-- copy of items for further analysis (on the first instance before deletions occur)
				if @innerCnt = 0
					select * into #copyTempSplit from #temp_split
					--select * into #copyTempSplit from (select * from #temp_split) alias


				-- remove as the search is made for main item list to keep iterating
				delete from #temp_split where Item like @Item

				--set @Items_in_List  = (select COUNT(*) from #temp_split)
				select @Items_in_List = COUNT(*) from #temp_split


				
--select '#accepted_particles' as accepted_particles	
--select * from #accepted_particles



				-- Begin this process once the item list is emptied
				if (@Items_in_List = 0)
				BEGIN

					-- copied because it might be needed for the next loops
					drop table if exists #copy_accepted_particles
					select * into #copy_accepted_particles from #accepted_particles
					select @cnt_approved_particles = COUNT(*) from #accepted_particles

					-- Adding a row number for better iteration process
					drop table if exists #particles_temp
					select * into #particles_temp from (select ROW_NUMBER() OVER(ORDER BY accepted_particles ASC) AS Row, * from #copy_accepted_particles) alias

					-- Adding a row number for better iteration process
					drop table if exists #combined_wine_names_row
					select * into #combined_wine_names_row from (select ROW_NUMBER() OVER(ORDER BY clean_name ASC) AS Row, * from #combined_clean_wine_names) alias
				
					-- Count ..
					declare @combined_wine_names_row_count as int
					select @combined_wine_names_row_count = COUNT(*) from #combined_wine_names_row

					declare @particles_temp_count as int 
					select @particles_temp_count = COUNT(*) from #particles_temp

					declare @wine_name_row_no  as int = 1
					declare @particles_temp_no as int = 1

					declare @selected_name as varchar(500)
					declare @wine_id as varchar(500) = 0
				
					-- Getting a potential wine name and its the wine id
						WHILE @wine_name_row_no < @combined_wine_names_row_count+1
						BEGIN

						select top 1 @selected_name = clean_name from #combined_wine_names_row where Row like @wine_name_row_no
						select top 1 @wine_id = id from #combined_wine_names_row where Row like @wine_name_row_no

						set @global_fitness_function = 0
						set @particles_temp_no = 1
	
							WHILE @particles_temp_no < @particles_temp_count+1
							BEGIN

							select top 1 @selected_particle = accepted_particles from #particles_temp where Row like @particles_temp_no
						
								if @selected_name like '%' + @selected_particle + '%'
								BEGIN 
									set @global_fitness_function = @global_fitness_function + 1
								END

							set @particles_temp_no = @particles_temp_no +1

							END

						set @wine_name_row_no = @wine_name_row_no +1

						insert into #save_fitness_history
						(wine_id, clean_name, globalFF)
						values(@wine_id, @selected_name, @global_fitness_function)
	
						END

--select 'save_fitness_history' as #save_fitness_history	
--select * from #save_fitness_history

						-- Getting a list of how many approved items/ particles actually are included in a potential wine name
						-- hence global fitness
						drop table if exists #save_fitness_history_row
						drop table if exists #save_fitness_history_gff
						drop table if exists #distinct_save_fitness_history_gff
						drop table if exists #distinct_save_fitness_history
						drop table if exists #distinct_save_fitness_history_row
						drop table if exists #check_distict_globalFF

						
						declare @global_max as int
						select top 1 @global_max = max(globalFF) from #save_fitness_history


--select 'save_fitness_history_COUNT' as save_fitness_history_COUNT
--select count (*) as save_fitness_history_COUNT from #save_fitness_history
		
						select * into #distinct_save_fitness_history from
							(select distinct clean_name from #save_fitness_history
							where @global_max = globalFF) alias

						select * into #distinct_save_fitness_history_row from
							(select ROW_NUMBER() OVER(ORDER BY clean_name ASC) AS Row, * from #distinct_save_fitness_history) alias

						declare @row_wine_name as varchar(500)


--select * from #distinct_save_fitness_history_row
						
						-------------------------------------


						select * into #check_distict_globalFF from (select distinct globalFF from #save_fitness_history) alias

--select '#check_distict_globalFF' as check_distict_globalFF
--select * from #check_distict_globalFF

						declare @count_of_check_distict_globalFF as int = (select count(*) from #check_distict_globalFF)
						select * into #save_fitness_history_gff from #save_fitness_history --where globalFF > 1

						
--select globalFF from #save_fitness_history_gff

--select 'before this' as before_this

--select '#save_fitness_history_gff' as save_fitness_history_gff
--select * from #save_fitness_history_gff

						-- Getting the distinct wine names (since there are alot of repetitive wines)
						select * into #distinct_save_fitness_history_gff from (select distinct clean_name from #save_fitness_history_gff) alias
						
--select '#distinct_save_fitness_history_gff' as distinct_save_fitness_history_gff
--select * from #distinct_save_fitness_history_gff

				
						-- row number..
						select * into #save_fitness_history_row from (select ROW_NUMBER() OVER(ORDER BY clean_name ASC) AS row, * from #distinct_save_fitness_history_gff) alias
						--select * from #save_fitness_history_row

--select 'save_fitness_history_row_COUNT' as save_fitness_history_row
--select count (*) as save_fitness_history_row_COUNT from #save_fitness_history_row

						declare @count_distinct_name as int = (select count(*) from #save_fitness_history_row)			
						declare @row_id as int = 1
						declare @split_potential_wine_match as varchar(500)
						declare @new_fitness_score decimal(10,2) = 0
						declare @fitness_wine_name varchar(500) = ''

--select 'before loop' --as before_loop


--select @count_distinct_name as count_distinct_name


						-- This part compares the weight for each potential wine name
						-- The weight is found by colleceting the number of occurence the item is included in the database
						-- with wine
						while @row_id < @count_distinct_name+1
						BEGIN

						--select 'inside count_distinct_name loop' as inside_count_distinct_name_loop

							drop table if exists #new_split
							drop table if exists #new_split_row
							drop table if exists #new_particles_list

							-- splitting all the words from the POTENTIAL wine name
							select top 1 @split_potential_wine_match = clean_name from #save_fitness_history_row where Row = @row_id
							select * into #new_split from fnSplitStringNew(@split_potential_wine_match, ' ')
			
select @split_potential_wine_match as split_potential_wine_match

							-- comparing it with the item list of approved particles/words AND
							-- Getting only the words that are not matched
							drop table if exists #new_split_items
								select * into #new_split_items from (select tiw.Item from #new_split tiw 
								left join #particles_temp tp on tiw.Item = tp.accepted_particles collate Latin1_General_CI_AS
									where tp.accepted_particles is null) alias

							-- row number ..
							drop table if exists #new_split_items_row
							select * into #new_split_items_row from
								(select ROW_NUMBER() OVER(ORDER BY item ASC) AS row, * from #new_split_items) alias

select 'new_split_items_row' as new_split_items_row
select * from #new_split_items_row

							-- count ..
							declare @count_of_item as int = (select count(tiw.Item) from #new_split tiw 
								left join #particles_temp tp on tiw.Item = tp.accepted_particles collate Latin1_General_CI_AS
								where tp.accepted_particles is null)

--select @count_of_item as count_of_item
												
							declare @count_of_item_start as int = 1
							declare @count_of_weights as decimal(10,2) = 0


select * from #new_split_items_row

								-- Getting a count of each item that was found in the list above of how many occurences
								-- there are in the wine_matching 
								WHILE @count_of_item_start < @count_of_item+1
								BEGIN

								--select 'inside @count_of_item loop' as inside_@count_of_item_loop


									declare @current_item as varchar(500)
									select top 1 @current_item = Item from #new_split_items_row where row like @count_of_item_start
									
									declare @current_item_count as int
									select @current_item_count = count(clean_name) from wine_matching where ' '+clean_name+' ' like '% ' +@current_item+ ' %'

									-- adding up the number of weights for each item (as iteration goes along)
									set @count_of_weights = @count_of_weights + @current_item_count

									set @count_of_item_start = @count_of_item_start +1
									SET @current_item_count = 0
									
									--select 'count of item starttt' as count_of_item_start

								END
									
								-- Setting an initial state (minimization problem)
								if (@row_id = 1)
								begin
									set @new_fitness_score = @count_of_weights
									set @fitness_wine_name = @split_potential_wine_match
								end

								
								-- if the fitness (weight) is lesser than before, then update the wine name and fitness
								if (@count_of_weights < @new_fitness_score)
								begin
									set @new_fitness_score = @count_of_weights
									set @fitness_wine_name = @split_potential_wine_match
								end

						-- getting the number of approved words/ particles that are in the potential wine name 
						declare @itemGFF as varchar(500) = (select top 1 globalFF from #save_fitness_history where clean_name like @split_potential_wine_match)

						declare @wine_idd as varchar(500)
						select top 1 @wine_idd = wine_id from wine_matching where clean_name like @split_potential_wine_match
				
						--select @split_potential_wine_match as iter_wine_name, @itemGFF as itemGFF, @count_of_weights as iter_count_of_weights, (@count_of_weights/@itemGFF) as fitness_measure
						--select @fitness_wine_name as fitness_wine_name, @new_fitness_score as new_fitness_score#

						
						insert into #finale_table(wine_id, matching_wine_name, weights, itemGFF, fitness_measure)
						values(@wine_idd, @split_potential_wine_match, @count_of_weights, @itemGFF, (@count_of_weights/@itemGFF))
						
							 set @row_id = @row_id + 1
							
						END
						-------------------------------------

					END			

			SET @innerCnt = @innerCnt + 1;
		END;

		--select * from #finale_table order by itemGFF desc
		declare @total_no_row_finale_table as decimal(10,2) = (select count(*) from #finale_table)
		
		--select @total_no_row_finale_table as total_no_row_finale_table

		-------------------------

		DECLARE @gffcnt INT = 1;
		DECLARE @gffcnt_total INT

		drop table if exists #distinct_gff
		drop table if exists #row_distinct_gff
		
		select * into #distinct_gff from (select distinct itemGFF from #finale_table) alias
		select * into #row_distinct_gff from (select ROW_NUMBER() OVER(ORDER BY itemGFF ASC) AS Row, * from #distinct_gff) alias
--select * from #row_distinct_gff
		
		set @gffcnt_total  = (select count(*) from #row_distinct_gff) --select @gffcnt_total as gffcnt_total
		
			-- getting the total number of itemGFF occurences from the itemGFF in the #finaletable
			WHILE @gffcnt < @gffcnt_total+1
			BEGIN
				
				declare @item_gff_value as int = (select ItemGFF from #row_distinct_gff where row like @gffcnt)
				declare @specific_item_gff as int = (select top 1 itemGFF from #row_distinct_gff where row like @gffcnt)

				declare @item_gff_count as int = (select count(*) from #finale_table where itemGFF like @specific_item_gff)
				
				--select @specific_item_gff as specific_item_gff, @item_gff_count as item_gff_count

				insert into #distinct_count_itemGFF(item_gff,count_of_item_gff)
				values(@item_gff_value, @item_gff_count)
  
			   SET @gffcnt = @gffcnt + 1;
			 END;


			select * from #finale_table order by itemGFF desc, weights asc

		
		---------------------------

						
		select '-----' as new_iter

		drop table #distinct_gff
		
		if (@Items_in_List = 0)
		BEGIN

			-- drop tables for reuse in next iteration
			drop table if exists #copyTempSplit
			drop table if exists #accepted_particles
			drop table if exists #particles_randomly_matched
			drop table if exists #finale_table
			drop table if exists #distinct_count_itemGFF
			drop table if exists #twenty_percent_final
			drop table if exists #eighty_percent_final
			
			-- restart inner loop variables
			set @innerCnt = 0 -- restart main inner loop
			set @cnt_approved_particles = 0
			set @new_fitness_score = 0
			set @fitness_wine_name = ''
			set @count_of_weights = 0
			set @gffcnt_total = 0
		END
			

   SET @cnt = @cnt + 1;

END;

/*

Steps for matching algorithm:

- Select all fields and populate data into a temp table
- loop through each incoming wine name
	- split the given incoming wine name into words/particles
	- collect all wine names from the matching database that includes a word from the incoming wine name 
	  (loop for each word for the specific incoming wine name)
		- do a process that inserts into a new temp table if there are no numbers that there is infact
		  searches found when searching for wines have have that particle/word - match wine toword
		  words/particles
	- once the search processes are complete then start interating with each particle/word and collecting a wine
	  name that has atleast 1 (approved) particle/word in that winen name - set the local fitness to 1: match 		  wine toword words/particles (kind of irrelevant now)
	
		- split the word/particles of each potential wine match - save it in another list
		- collect the weights (number of occurences with other wines from the wine_matching table)
		
		- calculate fitnesses ..
	- get a list of number of items matched from the incoming wine name matched with a potential wine name and
	  their weights
	- finalise the list of potential wine names by selecting the most items matched and the lowest weights

*/


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_clean_1]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_clean_1]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_clean_1] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-15
-- Description:	This procedure cleans bottle sizes and vintages
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_clean_1 @batch_id

*/

	@batch_id int

AS
BEGIN

	Declare @word varchar(100)
	Declare @typo varchar(100)
	
	-- First clean symbols
	
	Update wo_match_wines 
		Set	wine_name_clean = ' '+REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(dbo.fnMatchingCleanWineName(incoming_wine_name),']',''),'[',''),'�',' '),'�',' '),CHAR(9),' '),'� ',' ')+' ' COLLATE SQL_Latin1_General_Cp1251_CS_AS
	Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	
	-- Then remove bottle sizes
	
	Declare reccursor_clean_1 cursor for
			Select typo, word from sizes_and_vintages_table
			ORDER BY LEN(typo) DESC
	open reccursor_clean_1

	FETCH NEXT FROM reccursor_clean_1 INTO @typo, @word

	WHILE (@@Fetch_Status = 0)
		BEGIN
			
			Update wo_match_wines 
				Set	wine_name_clean =  REPLACE(LTRIM(RTRIM(REPLACE('    '+REPLACE(wine_name_clean,' ','  ')+'    ',' '+@typo+' ',' '+@word+' '))),'  ',' ')
			Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
			
			FETCH NEXT FROM reccursor_clean_1 INTO @typo, @word
		
		END  --end looping through records "
	
	CLOSE reccursor_clean_1
	DEALLOCATE reccursor_clean_1
	
	Update wo_match_wines 
		Set wine_name_clean = LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(wine_name_clean,'     ',' '),'    ',' '),'   ',' '),'  ',' ')))
	Where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	
END
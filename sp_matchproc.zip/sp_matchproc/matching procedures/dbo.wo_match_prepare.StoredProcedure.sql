IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_prepare]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_prepare]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_prepare] 

-- =============================================
-- Author:		JP
-- Create date: 2013-01-15
-- Description:	This procedure prepares the data for matching.
-- =============================================

/*

This procedure doesn't really do anything.

Call it this way: 
	
	EXEC wo_match_prepare @batch_id

*/

@batch_id int

AS
BEGIN

update wo_match_wines
	set region = 'Bordeaux'
where batch_id = @batch_id and ISNULL(region,'') = ''
	and (
		incoming_wine_name like '%bordeaux%'
		OR incoming_wine_name like '%medoc%'
		OR incoming_wine_name like '%M�doc%'
		OR incoming_wine_name like '%Emilion%'
		OR incoming_wine_name like '%BORDELAIS%'
		OR incoming_wine_name like '%Castillon%'
		OR incoming_wine_name like '%Graves%'
		OR incoming_wine_name like '%saint%Julien%'
		 
	)
--OR ISNULL(region,'') IN (
--	'C�tes de Blaye','Entre-deux-Mers','Medoc','M�doc','Canon Fronsac'
--	, 'Haut Medoc', 'Premi�res C�tes de Blaye', 'Bordeaux Superieur'
--	, 'Bordeaux Sup�rieur', 'BORDELAIS', 'Saint Emilion', 'Saint Georges Saint Emilion'
--	, 'Bordeaux Sauternais', 'Castillon C�tes de Bordeaux', 'C�tes de Castillon', 'Graves'
--	, 'Saint-Emilion', 'Saint Julien'
--)

-- some code to insert into wo_match_wines the incoming table

END

/*
-- drop table wo_match_wines
CREATE TABLE wo_match_wines (
	Id int identity NOT NULL PRIMARY KEY -- Unique key
	, Batch_id int -- Id for a batch of wines to match
	, wine_ref varchar(50) -- Some unique Id or product code to link with the original file
	, incoming_wine_name varchar(255) -- Incoming wine name (to match, not processed by anything)
	, wine_name_clean varchar(255) -- Cleaned version of incoming_wine_name
	, round_matched int -- round in which the wine was matched
	, processed varchar(1) -- 'N' when not processed, 'Y' once the wine has been processed (matched)
	, number_of_matches int -- Number of possible matches for this wine
	, wo_wine_name varchar(255) -- Name of the WO wine that is the most probable match
	, wo_wine_id int -- id of the WO wine
	, matching_score DECIMAL(18,4) -- score indicating the strength of the matching
	, other_match_1 varchar(255) -- possible other match
	, other_match_1_id int -- possible other match id
	, other_match_2 varchar(255) -- possible other match
	, other_match_2_id int -- possible other match id
	, other_match_3 varchar(255) -- possible other match
	, other_match_3_id int -- possible other match id
	, other_match_4 varchar(255) -- possible other match
	, other_match_4_id int -- possible other match id
	, disabled bit -- set to 1 for records that we do not wish to look at
	, created datetime -- time of creation of the entry
	, created_by int -- user_id of the user who inserted the entry
	, updated datetime -- time at which the entry was last updated (probably the time of the matching)
	, updated_by int -- user_id of the user who worked last on the entry
	, stamp int -- stamp
	, right_match bit -- says if the matching is right
	, classification varchar(255) -- possible classification, if it was found
	, appellation varchar(255) -- possible appellation, if it was found
	, producer_name varchar(255) -- possible producer name, if it was found
	, grape varchar(255) -- possible grape, if it was found
	, region varchar(255) -- region used for the regional matching
	, regional_clean_name varchar(255) -- clean_name used for the regional matching
) 
-- select * from wo_match_wines
*/

/*

-- region specific stuff

-- Burgundy data
select distinct wineName, region, country into scoreFull_Wine_Region from scoreFull_20141007

select * from scoreFull_Wine_Region

Declare @batch_id int
Select @batch_id = ISNULL(MAX(batch_id),0)+1 from Matching_DB.dbo.wo_match_wines

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Burgundy'
FROM scoreFull_Wine_Region
where ISNULL(region,'') like '%burgundy%'
or ISNULL(region,'') like '%bourgogne%' or ISNULL(region,'') like '%chambertin%'
or ISNULL(region,'') like '%corton%' or ISNULL(region,'') like '%savigny%'
or ISNULL(region,'') like '%nuits%' or ISNULL(region,'') like '%vosne%'
or ISNULL(region,'') like '%pernand%' or ISNULL(region,'') like '%corgolin%'
or ISNULL(region,'') like '%beaune%' or ISNULL(region,'') like '%maranges%'
or ISNULL(region,'') like '%monthelie%' or ISNULL(region,'') like '%chassagne%'
or ISNULL(region,'') like '%puligny%' or ISNULL(region,'') like '%meursault%'
or ISNULL(region,'') like '%pommard%' or ISNULL(region,'') like '%volnay%'
or ISNULL(region,'') like '%vougeot%' or ISNULL(region,'') like '%chambolle%'
or ISNULL(region,'') like '%morey%' or ISNULL(region,'') like '%gevrey%'
or ISNULL(region,'') like '%brochon%' or ISNULL(region,'') like '%fixin%'
or ISNULL(region,'') like '%marsannay%'
or ISNULL(region,'') like '%chablis%' or ISNULL(region,'') like '%ladoix%'
or ISNULL(region,'') like '%santenay%' or ISNULL(region,'') like '%rully%'
or ISNULL(region,'') like '%givrey%' or ISNULL(region,'') like '%mercurey%'
or ISNULL(region,'') like '%bonnes mares%' or ISNULL(region,'') like '%echezeaux%' 
or wineName like '%burgundy%'
or wineName like '%bourgogne%' or wineName like '%chambertin%'
or wineName like '%corton%' or wineName like '%savigny%'
or wineName like '%nuits%' or wineName like '%vosne%'
or wineName like '%pernand%' or wineName like '%corgolin%'
or wineName like '%beaune%' or wineName like '%maranges%'
or wineName like '%monthelie%' or wineName like '%chassagne%'
or wineName like '%puligny%' or wineName like '%meursault%'
or wineName like '%pommard%' or wineName like '%volnay%'
or wineName like '%vougeot%' or wineName like '%chambolle%'
or wineName like '%morey%' or wineName like '%gevrey%'
or wineName like '%brochon%' or wineName like '%fixin%'
or wineName like '%marsannay%' or wineName like '%chablis%'
or wineName like '%ladoix%' or wineName like '%santenay%'
or wineName like '%rully%' or wineName like '%givrey%'
or wineName like '%mercurey%' or wineName like '%bonnes mares%'

-- Bordeaux data

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Bordeaux'
FROM scoreFull_Wine_Region
where ISNULL(region,'') like '%bordeaux%'
OR ISNULL(region,'') IN (
	'C�tes de Blaye','Entre-deux-Mers','Medoc','M�doc','Canon Fronsac'
	, 'Haut Medoc', 'Premi�res C�tes de Blaye', 'Bordeaux Superieur'
	, 'Bordeaux Sup�rieur', 'BORDELAIS', 'Saint Emilion', 'Saint Georges Saint Emilion'
	, 'Bordeaux Sauternais', 'Castillon C�tes de Bordeaux', 'C�tes de Castillon', 'Graves'
	, 'Saint-Emilion', 'Saint Julien'
)
OR wineName like '%bordeaux%'

-- Germany data 

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Germany'
FROM scoreFull_Wine_Region
where ISNULL(country,'') = 'Germany'
or ISNULL(region,'') IN ('Germany','Mosel', 'Pfalz', 'Mosel-Saar-Ruwer', 'Nahe', 'Rheingau', 'Rheinhessen', 'Other Germany')
OR ISNULL(wineName,'') like '%Rheingau%'
or ISNULL(wineName,'') like '%kabinett%'
or ISNULL(wineName,'') like '%spatlese%'
or ISNULL(wineName,'') like '%eiswein%'
or ISNULL(wineName,'') like '%auslese%'

-- Tuscany data 

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Tuscany'
FROM scoreFull_Wine_Region
where ISNULL(region,'') IN ('Tuscany', 'Toscana','Brunello di Montalcino')
or wineName like '%brunello%' or wineName like '%tuscany%'

-- Piedmont data 

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Piedmont'
FROM scoreFull_Wine_Region
where ISNULL(region,'') IN ('Piedmont','Piemonte','Barolo')
or wineName like '%barolo%'

-- California data 

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp, region
)
Select @batch_id, '', wineName, 'N'
	, 0, getdate(), 35, 1, 'Piedmont'
FROM scoreFull_Wine_Region
where ISNULL(region,'') IN ('Napa','Beringer','Sonoma','Carneros','Kistler','Howell')
or wineName like '%Napa%'
or wineName like '%Beringer%'
or wineName like '%Sonoma%'
or wineName like '%Carneros%'
or wineName like '%Kistler%'
or wineName like '%Howell%'

*/


/*

drop table Matching_DB.dbo.wine
select * into Matching_DB.dbo.wine from live1_wo_main.dbo.wine

-- France
alter table Matching_DB.dbo.wine
add bordeaux_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add burgundy_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add champagne_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add alsace_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add rhone_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add loire_clean_name varchar(255)
-- Italy
alter table Matching_DB.dbo.wine
add tuscany_clean_name varchar(255)
alter table Matching_DB.dbo.wine
add piedmont_clean_name varchar(255)
-- Germany
alter table Matching_DB.dbo.wine
add germany_clean_name varchar(255)
-- Spain
alter table Matching_DB.dbo.wine
add spain_clean_name varchar(255)
-- USA
alter table Matching_DB.dbo.wine
add usa_clean_name varchar(255)
-- California
alter table Matching_DB.dbo.wine
add california_clean_name varchar(255)
-- Australia
alter table Matching_DB.dbo.wine
add australia_clean_name varchar(255)
-- Portugal
alter table Matching_DB.dbo.wine
add portugal_clean_name varchar(255)
-- Generic regional matching for lines with no region
alter table Matching_DB.dbo.wine
add no_region_clean_name varchar(255)

ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN name
            varchar(255) COLLATE Latin1_General_CI_AS;
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN clean_name
            varchar(255) COLLATE Latin1_General_CI_AS;		
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN producer_name
            varchar(255) COLLATE Latin1_General_CI_AS;
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN classification
            varchar(255) COLLATE Latin1_General_CI_AS;
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN appellation
            varchar(255) COLLATE Latin1_General_CI_AS;
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN designation
            varchar(255) COLLATE Latin1_General_CI_AS;
ALTER TABLE Matching_DB.dbo.wine 
ALTER COLUMN grape
            varchar(255) COLLATE Latin1_General_CI_AS;

Declare @batch_id int
Select @batch_id = ISNULL(MAX(batch_id),0)+1 from Matching_DB.dbo.wo_match_wines

insert into Matching_DB.dbo.wo_match_wines (
	Batch_id, wine_ref, incoming_wine_name, processed
	, disabled, created, created_by, stamp
)
Select @batch_id, product_code, wine_name, 'N'
	, 0, getdate(), 35, 1
FROM incoming_table_test

Print @batch_id

EXEC wo_match_run 'clean', @batch_id, 'nosuspect' 
Exec wo_match_run 'Match', @batch_id, ''

-- add to wine :

-- regional_producer
-- regional_grape
-- regional_appellation
-- regional_classification

-- at the beginning of a region-specific matching :

-- regional_producer = producer, then region-specific cleaning.

*/

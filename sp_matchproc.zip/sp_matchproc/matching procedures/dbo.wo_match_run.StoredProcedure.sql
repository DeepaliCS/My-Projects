IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[wo_match_run]')  AND type = N'P')
     DROP PROCEDURE [dbo].[wo_match_run]
GO

SET ANSI_NULLS ON 
GO 
SET QUOTED_IDENTIFIER ON 
GO 
create PROCEDURE [dbo].[wo_match_run] 

-- =============================================
-- Author:		JP
-- Create date: 2014-01-15
-- Description:	This procedure is the main procedure used for matching.
-- =============================================

/*

Call it this way: 
	
	Declare @batch_id int = 1
	
	EXEC wo_match_run 'clean', @batch_id, ''
	EXEC wo_match_run 'match', @batch_id, ''
	EXEC wo_match_run 'learn', @batch_id, ''

*/

	@action varchar(50)
	, @batch_id int
	, @option varchar(1000) = ''

AS
BEGIN

	IF ISNULL(@action,'') NOT IN ('clean', 'match', 'learn')
		BEGIN
		
			PRINT 'incorrect action'
			return 0
		
		END

	IF NOT EXISTS(
		Select 1 FROM wo_match_wines 
		where batch_id = @batch_id and ISNULL(processed,'N') = 'N' and ISNULL(disabled,0) = 0
	) 
		BEGIN
		
			PRINT 'incorrect batch_id or nothing to process'
			return 0
		
		END
	
	IF ISNULL(@action,'') ='clean'
		BEGIN
			
			Exec wo_match_clean_wine @batch_id
			Print 'cleaning wine done'
			Exec wo_match_clean_1 @batch_id
			Print 'cleaning 1 done'
			Exec wo_match_clean_2 @batch_id
			Print 'cleaning 2 done'
			--Exec wo_match_clean_3 @batch_id
			--Print 'cleaning 3 done'
				IF ISNULL(@option,'') NOT like '%nosuspect%'
					BEGIN
						Exec wo_match_clean_find_suspects @batch_id, 'find'
					END
					
		END
	
	IF ISNULL(@action,'') ='match'
		BEGIN
			
			Print 'Start matching'
			
			IF ISNULL(@option,'') like '%Burgundy%'
				BEGIN
					EXEC wo_match_Burgundy @batch_id
					RETURN 0
				END
			IF ISNULL(@option,'') like '%Bordeaux%'
				BEGIN
					EXEC wo_match_Bordeaux @batch_id
					RETURN 0
				END
			IF ISNULL(@option,'') like '%Rhone%'
				BEGIN
					EXEC wo_match_Rhone @batch_id
					RETURN 0
				END
			IF ISNULL(@option,'') like '%Italy%'
				BEGIN
					EXEC wo_match_Italy @batch_id
					Print 'Italian matching done'
					RETURN 0
				END
			IF ISNULL(@option,'') like '%Other French%'
				BEGIN
					EXEC wo_match_other_French_regions @batch_id
					Print 'Other French regions matching done'
					RETURN 0
				END
			
			EXEC wo_match_round_1 @batch_id 
			Print 'round 1 done'
			-- JP 2014-02-25 Step 5 is now running after step 1
			EXEC wo_match_round_5 @batch_id 
			Print 'round 5 done'
			IF ISNULL(@option,'') like '%Regional%'
				BEGIN
					EXEC wo_match_Burgundy @batch_id
					EXEC wo_match_Bordeaux @batch_id
					EXEC wo_match_Rhone @batch_id
					EXEC wo_match_Germany @batch_id
					EXEC wo_match_Tuscany @batch_id
					EXEC wo_match_Piedmont @batch_id
					--EXEC wo_match_California @batch_id
					--EXEC wo_match_Champagne @batch_id
					EXEC wo_match_no_region @batch_id
					--RETURN 0
				END
			IF ISNULL(@option,'') like '%basic%'
				RETURN 0
			EXEC wo_match_round_2 @batch_id 
			Print 'round 2 done'
			EXEC wo_match_round_3 @batch_id 
			Print 'round 3 done'
			IF ISNULL(@option,'') Not like '%noRound4%'
				BEGIN
					EXEC wo_match_round_4 @batch_id 
					Print 'round 4 done'
				END
			--EXEC wo_match_round_6 @batch_id 
			--Print 'round 6 done'
	
		END
		
	IF ISNULL(@action,'') ='learn'
		BEGIN
					
			insert into matches_historic (wine_id, clean_name)
			select wo_wine_id, wine_name_clean from wo_match_wines
			where ISNULL(processed,'N') = 'Y'
				and ISNULL(right_match,0) = 1
				and batch_id = @batch_id and wine_name_clean NOT IN (
					select clean_name from matches_historic
				)
		
		END

END